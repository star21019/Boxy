"use client"

import { useState } from "react"
import { MainMenu } from "@/components/main-menu"
import { AppLoadingScreen } from "@/components/app-loading-screen"
import { Sidebar } from "@/components/sidebar"
import { GameDashboard } from "@/components/game-dashboard"
import { MovieCreator } from "@/components/movie-creator"
import { ActorCasting } from "@/components/actor-casting"
import { MarketingCampaigns } from "@/components/marketing-campaigns"
import { BoxOfficeSimulation } from "@/components/box-office-simulation"
import { AwardsSystem } from "@/components/awards-system"
import { RivalStudios } from "@/components/rival-studios"
import { TvShowCreator } from "@/components/tv-show-creator"
import { MusicCreator } from "@/components/music-creator"
import { StaffManagement } from "@/components/staff-management"
import { AnalyticsDashboard } from "@/components/analytics-dashboard"
import { FinancesDashboard } from "@/components/finances-dashboard"
import { SocialMediaDashboard } from "@/components/social-media-dashboard"
import { AdvancedInfluencerDashboard } from "@/components/advanced-influencer-dashboard"
import { HallOfFame } from "@/components/hall-of-fame"
import { StudioProfile } from "@/components/studio-profile"
import { Toaster } from "@/components/ui/sonner"

export default function Home() {
  const [gameState, setGameState] = useState<"menu" | "loading" | "playing">("menu")
  const [currentView, setCurrentView] = useState("dashboard")
  const [studioData, setStudioData] = useState({
    name: "Your Studio",
    money: 50000000,
    reputation: 50,
    level: 1,
    experience: 0,
    projects: [],
    staff: [],
    awards: [],
    achievements: [],
    activeCampaigns: [],
    alliances: [],
    weeklyRevenue: 0,
  })

  const [selectedMovie, setSelectedMovie] = useState<any>(null)

  const handleStartGame = (studioName: string) => {
    setStudioData((prev) => ({ ...prev, name: studioName }))
    setGameState("loading")

    setTimeout(() => {
      setGameState("playing")
    }, 3000)
  }

  const handleLoadGame = () => {
    const savedGame = localStorage.getItem("boxOfficeLegendsGame")
    if (savedGame) {
      try {
        const gameData = JSON.parse(savedGame)
        setStudioData(gameData)
        setGameState("playing")
      } catch (error) {
        console.error("Failed to load game:", error)
      }
    }
  }

  const handleUpdateStudio = (updates: any) => {
    setStudioData((prev) => {
      const newData = { ...prev, ...updates }
      localStorage.setItem("boxOfficeLegendsGame", JSON.stringify(newData))
      return newData
    })
  }

  const handleUpdateMovie = (updates: any) => {
    if (selectedMovie) {
      const updatedMovie = { ...selectedMovie, ...updates }
      setSelectedMovie(updatedMovie)

      const updatedProjects = studioData.projects.map((p: any) => (p.id === selectedMovie.id ? updatedMovie : p))

      handleUpdateStudio({ projects: updatedProjects })
    }
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case "dashboard":
        return <GameDashboard studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "create-movie":
        return <MovieCreator studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "actor-casting":
        if (!selectedMovie) {
          return (
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold text-white mb-4">No Movie Selected</h2>
              <p className="text-gray-400">Please select a movie from your projects to cast actors.</p>
            </div>
          )
        }
        return (
          <ActorCasting
            movie={selectedMovie}
            onUpdateMovie={handleUpdateMovie}
            studioData={studioData}
            onUpdateStudio={handleUpdateStudio}
          />
        )

      case "marketing":
        return <MarketingCampaigns studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "box-office":
        return <BoxOfficeSimulation studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "awards":
        return <AwardsSystem studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "rivals":
        return <RivalStudios studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "create-tv":
        return <TvShowCreator studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "create-music":
        return <MusicCreator studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "staff":
        return <StaffManagement studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "analytics":
        return <AnalyticsDashboard studioData={studioData} />

      case "finances":
        return <FinancesDashboard studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "social-media":
        return <SocialMediaDashboard studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "influencers":
        return <AdvancedInfluencerDashboard studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      case "hall-of-fame":
        return <HallOfFame studioData={studioData} />

      case "studio-profile":
        return <StudioProfile studioData={studioData} onUpdateStudio={handleUpdateStudio} />

      default:
        return <GameDashboard studioData={studioData} onUpdateStudio={handleUpdateStudio} />
    }
  }

  if (gameState === "menu") {
    return (
      <>
        <MainMenu onStartGame={handleStartGame} onLoadGame={handleLoadGame} />
        <Toaster />
      </>
    )
  }

  if (gameState === "loading") {
    return (
      <>
        <AppLoadingScreen studioName={studioData.name} />
        <Toaster />
      </>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900">
      <div className="flex">
        <Sidebar
          currentView={currentView}
          onViewChange={setCurrentView}
          studioData={studioData}
          onMovieSelect={setSelectedMovie}
        />
        <main className="flex-1 ml-64 p-6">{renderCurrentView()}</main>
      </div>
      <Toaster />
    </div>
  )
}
