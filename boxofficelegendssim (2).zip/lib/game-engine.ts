import { awardShows, marketingCampaigns } from "./movie-data"

export interface GameState {
  currentWeek: number
  currentYear: number
  playerStudio: {
    name: string
    money: number
    reputation: number
    level: number
    experience: number
    projects: any[]
    staff: any[]
    awards: any[]
    achievements: any[]
  }
  rivalStudios: any[]
  marketConditions: {
    genreTrends: Record<string, number>
    seasonalFactors: Record<string, number>
    economicConditions: number
  }
  boxOfficeResults: any[]
  upcomingAwards: any[]
  activeMarketing: any[]
}

export class GameEngine {
  private gameState: GameState

  constructor(initialState: GameState) {
    this.gameState = initialState
  }

  advanceWeek(): GameState {
    this.gameState.currentWeek += 1
    if (this.gameState.currentWeek > 52) {
      this.gameState.currentWeek = 1
      this.gameState.currentYear += 1
    }

    // Update rival studios
    this.updateRivalStudios()

    // Process box office
    this.processBoxOffice()

    // Update market conditions
    this.updateMarketConditions()

    // Process awards
    this.processAwards()

    // Update marketing campaigns
    this.updateMarketing()

    return this.gameState
  }

  private updateRivalStudios() {
    this.gameState.rivalStudios.forEach((rival) => {
      // Rival AI decision making
      if (Math.random() < 0.1) {
        // 10% chance per week to start new project
        const newProject = this.generateRivalProject(rival)
        if (newProject) {
          rival.currentProjects = rival.currentProjects || []
          rival.currentProjects.push(newProject)
          rival.money -= newProject.budget
        }
      }

      // Update reputation based on recent releases
      if (rival.recentReleases) {
        const avgSuccess =
          rival.recentReleases.reduce((sum: number, movie: any) => sum + movie.success, 0) / rival.recentReleases.length
        rival.reputation += (avgSuccess - 50) * 0.1
        rival.reputation = Math.max(0, Math.min(100, rival.reputation))
      }
    })
  }

  private generateRivalProject(rival: any) {
    const genres = rival.specialties || ["Drama", "Action", "Comedy"]
    const selectedGenre = genres[Math.floor(Math.random() * genres.length)]

    const budgetRange =
      rival.type === "Major"
        ? [20000000, 200000000]
        : rival.type === "Streaming"
          ? [5000000, 100000000]
          : [500000, 20000000]

    const budget = budgetRange[0] + Math.random() * (budgetRange[1] - budgetRange[0])

    if (rival.money < budget) return null

    return {
      id: `rival_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      title: this.generateMovieTitle(selectedGenre),
      genre: selectedGenre,
      budget,
      studio: rival.name,
      releaseWeek: this.gameState.currentWeek + Math.floor(Math.random() * 20) + 8, // 8-28 weeks from now
      releaseYear: this.gameState.currentYear,
      status: "Development",
    }
  }

  private generateMovieTitle(genre: string): string {
    const titlePrefixes = ["The", "Dark", "Last", "Secret", "Hidden", "Lost", "Final", "Ultimate"]
    const titleSuffixes = ["Legacy", "Rising", "Chronicles", "Awakening", "Revolution", "Destiny", "Origins"]

    return `${titlePrefixes[Math.floor(Math.random() * titlePrefixes.length)]} ${titleSuffixes[Math.floor(Math.random() * titleSuffixes.length)]}`
  }

  private processBoxOffice() {
    // Process movies that are currently in theaters
    this.gameState.playerStudio.projects.forEach((project) => {
      if (project.status === "Released" && project.weeksSinceRelease < 12) {
        const weeklyRevenue = this.calculateWeeklyBoxOffice(project)
        project.totalBoxOffice = (project.totalBoxOffice || 0) + weeklyRevenue
        project.weeksSinceRelease = (project.weeksSinceRelease || 0) + 1

        // Add to player money (studio gets percentage)
        this.gameState.playerStudio.money += weeklyRevenue * 0.5
      }
    })

    // Process rival movies
    this.gameState.rivalStudios.forEach((rival) => {
      if (rival.currentProjects) {
        rival.currentProjects.forEach((project: any) => {
          if (project.releaseWeek <= this.gameState.currentWeek && project.releaseYear <= this.gameState.currentYear) {
            if (!project.released) {
              project.released = true
              project.weeksSinceRelease = 0
              project.totalBoxOffice = 0
            }

            if (project.weeksSinceRelease < 12) {
              const weeklyRevenue = this.calculateWeeklyBoxOffice(project)
              project.totalBoxOffice += weeklyRevenue
              project.weeksSinceRelease += 1
              rival.money += weeklyRevenue * 0.5
            }
          }
        })
      }
    })
  }

  private calculateWeeklyBoxOffice(movie: any): number {
    const baseRevenue = movie.budget * 0.1 // Base 10% of budget per week
    const weekMultiplier = Math.max(0.1, 1 - (movie.weeksSinceRelease || 0) * 0.15) // Decay over time
    const genreMultiplier = this.gameState.marketConditions.genreTrends[movie.genre] / 100 || 0.5
    const seasonalMultiplier = this.gameState.marketConditions.seasonalFactors[this.getCurrentSeason()] || 1
    const economicMultiplier = this.gameState.marketConditions.economicConditions / 100

    return baseRevenue * weekMultiplier * genreMultiplier * seasonalMultiplier * economicMultiplier
  }

  private getCurrentSeason(): string {
    const week = this.gameState.currentWeek
    if (week >= 1 && week <= 13) return "Winter"
    if (week >= 14 && week <= 26) return "Spring"
    if (week >= 27 && week <= 39) return "Summer"
    return "Fall"
  }

  private updateMarketConditions() {
    // Slowly evolve genre trends
    Object.keys(this.gameState.marketConditions.genreTrends).forEach((genre) => {
      const change = (Math.random() - 0.5) * 10 // ±5 points per week
      this.gameState.marketConditions.genreTrends[genre] += change
      this.gameState.marketConditions.genreTrends[genre] = Math.max(
        20,
        Math.min(100, this.gameState.marketConditions.genreTrends[genre]),
      )
    })

    // Update seasonal factors
    const season = this.getCurrentSeason()
    this.gameState.marketConditions.seasonalFactors = {
      Winter: season === "Winter" ? 1.1 : 0.9,
      Spring: season === "Spring" ? 1.1 : 0.9,
      Summer: season === "Summer" ? 1.3 : 0.8,
      Fall: season === "Fall" ? 1.0 : 0.9,
    }

    // Update economic conditions
    const economicChange = (Math.random() - 0.5) * 5
    this.gameState.marketConditions.economicConditions += economicChange
    this.gameState.marketConditions.economicConditions = Math.max(
      50,
      Math.min(150, this.gameState.marketConditions.economicConditions),
    )
  }

  private processAwards() {
    // Check if any movies are eligible for awards
    awardShows.forEach((awardShow) => {
      if (this.gameState.currentWeek % 26 === 0) {
        // Awards every 6 months
        const eligibleMovies = this.getEligibleMovies(awardShow)
        if (eligibleMovies.length > 0) {
          const winners = this.selectAwardWinners(eligibleMovies, awardShow)
          this.gameState.upcomingAwards.push({
            show: awardShow.name,
            winners,
            week: this.gameState.currentWeek + 4, // Awards ceremony in 4 weeks
          })
        }
      }
    })
  }

  private getEligibleMovies(awardShow: any) {
    return this.gameState.playerStudio.projects.filter((movie) => {
      const weeksSinceRelease = this.gameState.currentWeek - (movie.releaseWeek || 0)
      return (
        movie.status === "Released" &&
        movie.budget >= awardShow.requirements.minBudget &&
        (movie.rating || 50) >= awardShow.requirements.minRating &&
        weeksSinceRelease <= awardShow.requirements.releaseWindow &&
        weeksSinceRelease >= 0
      )
    })
  }

  private selectAwardWinners(eligibleMovies: any[], awardShow: any) {
    const winners: any = {}

    awardShow.categories.forEach((category: string) => {
      const candidates = eligibleMovies.sort((a, b) => (b.rating || 50) - (a.rating || 50))
      if (candidates.length > 0) {
        // Higher rated movies have better chance, but there's still randomness
        const winner = candidates[Math.floor(Math.random() * Math.min(3, candidates.length))]
        winners[category] = winner.title

        // Award benefits
        winner.awards = (winner.awards || 0) + 1
        this.gameState.playerStudio.reputation += awardShow.prestige / 10
        this.gameState.playerStudio.money += 1000000 // Award bonus
      }
    })

    return winners
  }

  private updateMarketing() {
    this.gameState.activeMarketing = this.gameState.activeMarketing.filter((campaign) => {
      campaign.weeksRemaining -= 1

      if (campaign.weeksRemaining <= 0) {
        // Campaign finished, apply final effects
        const targetMovie = this.gameState.playerStudio.projects.find((p) => p.id === campaign.movieId)
        if (targetMovie) {
          targetMovie.marketingBoost = (targetMovie.marketingBoost || 0) + campaign.effectiveness
        }
        return false
      }

      return true
    })
  }

  getGameState(): GameState {
    return this.gameState
  }

  startMarketingCampaign(movieId: string, campaignId: string) {
    const campaign = marketingCampaigns.find((c) => c.id === campaignId)
    const movie = this.gameState.playerStudio.projects.find((p) => p.id === movieId)

    if (campaign && movie && this.gameState.playerStudio.money >= campaign.cost) {
      this.gameState.playerStudio.money -= campaign.cost
      this.gameState.activeMarketing.push({
        movieId,
        campaignId,
        name: campaign.name,
        effectiveness: campaign.effectiveness,
        weeksRemaining: campaign.duration,
        startWeek: this.gameState.currentWeek,
      })
      return true
    }

    return false
  }

  releaseMovie(movieId: string) {
    const movie = this.gameState.playerStudio.projects.find((p) => p.id === movieId)
    if (movie && movie.status === "Post-Production") {
      movie.status = "Released"
      movie.releaseWeek = this.gameState.currentWeek
      movie.releaseYear = this.gameState.currentYear
      movie.weeksSinceRelease = 0
      movie.totalBoxOffice = 0

      // Calculate initial success rating
      movie.rating = this.calculateMovieRating(movie)

      return true
    }
    return false
  }

  private calculateMovieRating(movie: any): number {
    let rating = 50 // Base rating

    // Budget efficiency
    const budgetEfficiency = Math.min(100, movie.budget / 1000000) // $1M = 1 point
    rating += budgetEfficiency * 0.2

    // Marketing boost
    rating += (movie.marketingBoost || 0) * 0.3

    // Genre trends
    rating += (this.gameState.marketConditions.genreTrends[movie.genre] - 50) * 0.4

    // Cast quality (if actors are assigned)
    if (movie.cast && movie.cast.length > 0) {
      const avgAppeal =
        movie.cast.reduce((sum: number, actorId: string) => {
          const actor = movie.castDetails?.find((a: any) => a.id === actorId)
          return sum + (actor?.appeal || 50)
        }, 0) / movie.cast.length
      rating += (avgAppeal - 50) * 0.5
    }

    // Random factor
    rating += (Math.random() - 0.5) * 20

    return Math.max(10, Math.min(100, rating))
  }
}
