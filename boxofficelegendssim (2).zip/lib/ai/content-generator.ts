export interface ContentTemplate {
  id: string
  platform: string
  type: "text" | "image" | "video" | "story" | "reel" | "thread"
  template: string
  variables: string[]
  sentiment: "positive" | "negative" | "neutral" | "controversial"
  viralPotential: number
  engagementPattern: {
    likes: { min: number; max: number; multiplier: number }
    comments: { min: number; max: number; multiplier: number }
    shares: { min: number; max: number; multiplier: number }
  }
}

export interface AIPersonality {
  id: string
  name: string
  type: "fan" | "critic" | "influencer" | "celebrity" | "journalist" | "troll" | "bot"
  followers: number
  credibility: number
  sentiment_bias: number // -1 to 1
  topics: string[]
  posting_frequency: number
  engagement_style: "aggressive" | "supportive" | "analytical" | "humorous" | "dramatic"
}

export class ContentGenerator {
  private templates: ContentTemplate[] = [
    // Twitter/X Templates
    {
      id: "twitter_hype",
      platform: "twitter",
      type: "text",
      template:
        "Just watched {movie} and I'm SPEECHLESS! {actor} absolutely killed it! This is why we go to the movies! 🔥🎬 #{hashtag}",
      variables: ["movie", "actor", "hashtag"],
      sentiment: "positive",
      viralPotential: 85,
      engagementPattern: {
        likes: { min: 100, max: 50000, multiplier: 1.2 },
        comments: { min: 20, max: 5000, multiplier: 0.8 },
        shares: { min: 10, max: 2000, multiplier: 0.6 },
      },
    },
    {
      id: "twitter_criticism",
      platform: "twitter",
      type: "text",
      template:
        "Unpopular opinion: {movie} was overhyped. {actor} felt miscast and the plot had more holes than Swiss cheese. Sorry not sorry 🤷‍♀️ #{hashtag}",
      variables: ["movie", "actor", "hashtag"],
      sentiment: "negative",
      viralPotential: 75,
      engagementPattern: {
        likes: { min: 50, max: 25000, multiplier: 1.0 },
        comments: { min: 100, max: 8000, multiplier: 1.5 },
        shares: { min: 5, max: 1000, multiplier: 0.4 },
      },
    },
    {
      id: "twitter_theory",
      platform: "twitter",
      type: "thread",
      template:
        "🧵 THREAD: Why {movie} is actually a masterpiece of {genre} cinema (and why critics got it wrong) 1/12",
      variables: ["movie", "genre"],
      sentiment: "analytical",
      viralPotential: 60,
      engagementPattern: {
        likes: { min: 200, max: 15000, multiplier: 0.9 },
        comments: { min: 50, max: 3000, multiplier: 1.1 },
        shares: { min: 30, max: 1500, multiplier: 0.8 },
      },
    },

    // TikTok Templates
    {
      id: "tiktok_reaction",
      platform: "tiktok",
      type: "video",
      template:
        "POV: You just watched {movie} and now you're questioning everything you thought you knew about {genre} movies 😭 #{hashtag} #MovieTok #Reaction",
      variables: ["movie", "genre", "hashtag"],
      sentiment: "positive",
      viralPotential: 90,
      engagementPattern: {
        likes: { min: 1000, max: 500000, multiplier: 2.0 },
        comments: { min: 100, max: 25000, multiplier: 1.3 },
        shares: { min: 50, max: 10000, multiplier: 1.5 },
      },
    },
    {
      id: "tiktok_dance",
      platform: "tiktok",
      type: "video",
      template:
        "Teaching my mom the {movie} dance because this soundtrack is EVERYTHING! 💃 #{hashtag}Challenge #MovieDance #Viral",
      variables: ["movie", "hashtag"],
      sentiment: "positive",
      viralPotential: 95,
      engagementPattern: {
        likes: { min: 5000, max: 1000000, multiplier: 2.5 },
        comments: { min: 200, max: 50000, multiplier: 1.4 },
        shares: { min: 100, max: 20000, multiplier: 2.0 },
      },
    },
    {
      id: "tiktok_behind_scenes",
      platform: "tiktok",
      type: "video",
      template:
        "Behind the scenes of {movie}: Things you didn't know about {actor}'s preparation for this role 🎬✨ #BehindTheScenes #{hashtag}",
      variables: ["movie", "actor", "hashtag"],
      sentiment: "neutral",
      viralPotential: 70,
      engagementPattern: {
        likes: { min: 2000, max: 200000, multiplier: 1.6 },
        comments: { min: 150, max: 15000, multiplier: 1.1 },
        shares: { min: 75, max: 8000, multiplier: 1.2 },
      },
    },

    // Instagram Templates
    {
      id: "instagram_aesthetic",
      platform: "instagram",
      type: "image",
      template:
        "The cinematography in {movie} is pure art 📸✨ Every frame could be a painting. {actor} in that {scene_description} scene? *Chef's kiss* 💋 #{hashtag} #Cinematography #ArtOfFilm",
      variables: ["movie", "actor", "scene_description", "hashtag"],
      sentiment: "positive",
      viralPotential: 65,
      engagementPattern: {
        likes: { min: 500, max: 100000, multiplier: 1.4 },
        comments: { min: 30, max: 5000, multiplier: 0.9 },
        shares: { min: 20, max: 2000, multiplier: 0.7 },
      },
    },
    {
      id: "instagram_outfit",
      platform: "instagram",
      type: "image",
      template:
        "Recreating {actor}'s iconic look from {movie} because this outfit is ICONIC 👗✨ Swipe for the movie reference! #{hashtag} #MovieFashion #OOTD",
      variables: ["actor", "movie", "hashtag"],
      sentiment: "positive",
      viralPotential: 80,
      engagementPattern: {
        likes: { min: 1000, max: 150000, multiplier: 1.5 },
        comments: { min: 50, max: 8000, multiplier: 1.0 },
        shares: { min: 25, max: 3000, multiplier: 0.8 },
      },
    },

    // YouTube Templates
    {
      id: "youtube_review",
      platform: "youtube",
      type: "video",
      template:
        "{movie} REVIEW: Is it worth the hype? | Deep dive analysis of {actor}'s performance and {director}'s direction",
      variables: ["movie", "actor", "director"],
      sentiment: "analytical",
      viralPotential: 55,
      engagementPattern: {
        likes: { min: 200, max: 50000, multiplier: 1.0 },
        comments: { min: 100, max: 10000, multiplier: 1.2 },
        shares: { min: 10, max: 1000, multiplier: 0.5 },
      },
    },
    {
      id: "youtube_theory",
      platform: "youtube",
      type: "video",
      template:
        "The HIDDEN meaning behind {movie} that everyone missed | {genre} film analysis and Easter eggs explained",
      variables: ["movie", "genre"],
      sentiment: "analytical",
      viralPotential: 70,
      engagementPattern: {
        likes: { min: 500, max: 75000, multiplier: 1.1 },
        comments: { min: 200, max: 15000, multiplier: 1.4 },
        shares: { min: 50, max: 2000, multiplier: 0.8 },
      },
    },

    // Reddit-style Templates
    {
      id: "reddit_discussion",
      platform: "reddit",
      type: "text",
      template:
        "[SPOILERS] Can we talk about THAT scene in {movie}? {actor}'s performance gave me chills. What did you think about the {plot_element}?",
      variables: ["movie", "actor", "plot_element"],
      sentiment: "neutral",
      viralPotential: 45,
      engagementPattern: {
        likes: { min: 50, max: 10000, multiplier: 0.8 },
        comments: { min: 20, max: 2000, multiplier: 2.0 },
        shares: { min: 5, max: 500, multiplier: 0.3 },
      },
    },
  ]

  private personalities: AIPersonality[] = [
    {
      id: "movie_buff_mike",
      name: "MovieBuffMike",
      type: "fan",
      followers: 15000,
      credibility: 75,
      sentiment_bias: 0.3,
      topics: ["movies", "actors", "directors", "cinematography"],
      posting_frequency: 0.8,
      engagement_style: "analytical",
    },
    {
      id: "cinema_critic_sarah",
      name: "CinemaCriticSarah",
      type: "critic",
      followers: 85000,
      credibility: 90,
      sentiment_bias: -0.1,
      topics: ["film_analysis", "reviews", "industry_news"],
      posting_frequency: 0.6,
      engagement_style: "analytical",
    },
    {
      id: "pop_culture_queen",
      name: "PopCultureQueen",
      type: "influencer",
      followers: 250000,
      credibility: 60,
      sentiment_bias: 0.5,
      topics: ["celebrities", "fashion", "trends", "gossip"],
      posting_frequency: 0.9,
      engagement_style: "dramatic",
    },
    {
      id: "film_student_alex",
      name: "FilmStudentAlex",
      type: "fan",
      followers: 3500,
      credibility: 70,
      sentiment_bias: 0.2,
      topics: ["film_theory", "cinematography", "directing"],
      posting_frequency: 0.4,
      engagement_style: "analytical",
    },
    {
      id: "movie_troll_2000",
      name: "MovieTroll2000",
      type: "troll",
      followers: 500,
      credibility: 20,
      sentiment_bias: -0.8,
      topics: ["controversy", "hot_takes", "drama"],
      posting_frequency: 1.0,
      engagement_style: "aggressive",
    },
    {
      id: "hype_bot_network",
      name: "HypeBotNetwork",
      type: "bot",
      followers: 1000,
      credibility: 10,
      sentiment_bias: 0.9,
      topics: ["promotion", "hype", "marketing"],
      posting_frequency: 2.0,
      engagement_style: "supportive",
    },
  ]

  generateContent(
    movie: string,
    actor: string,
    genre: string,
    platform: string,
    contextData: {
      boxOffice?: number
      rating?: number
      awards?: number
      scandals?: number
      weeksSinceRelease?: number
      marketingBudget?: number
    },
  ): {
    posts: Array<{
      id: string
      platform: string
      author: AIPersonality
      content: string
      type: string
      timestamp: Date
      engagement: {
        likes: number
        comments: number
        shares: number
        views?: number
      }
      sentiment: string
      viralityScore: number
      hashtags: string[]
      mentions: string[]
    }>
  } {
    const posts = []
    const platformTemplates = this.templates.filter((t) => t.platform === platform)

    // Generate 3-8 posts per platform
    const postCount = Math.floor(Math.random() * 6) + 3

    for (let i = 0; i < postCount; i++) {
      const template = this.selectTemplate(platformTemplates, contextData)
      const personality = this.selectPersonality(template, contextData)

      if (Math.random() < personality.posting_frequency) {
        const post = this.createPost(template, personality, movie, actor, genre, contextData)
        posts.push(post)
      }
    }

    return { posts: posts.sort((a, b) => b.viralityScore - a.viralityScore) }
  }

  private selectTemplate(templates: ContentTemplate[], contextData: any): ContentTemplate {
    const weightedTemplates = templates.map((template) => {
      let weight = template.viralPotential

      // Adjust weight based on context
      if (contextData.boxOffice > 100000000 && template.sentiment === "positive") weight += 20
      if (contextData.rating < 40 && template.sentiment === "negative") weight += 15
      if (contextData.scandals > 0 && template.sentiment === "controversial") weight += 25
      if (contextData.awards > 0 && template.sentiment === "positive") weight += 10
      if (contextData.weeksSinceRelease > 8 && template.type === "thread") weight += 15

      return { template, weight }
    })

    const totalWeight = weightedTemplates.reduce((sum, item) => sum + item.weight, 0)
    let random = Math.random() * totalWeight

    for (const item of weightedTemplates) {
      random -= item.weight
      if (random <= 0) return item.template
    }

    return templates[0]
  }

  private selectPersonality(template: ContentTemplate, contextData: any): AIPersonality {
    const weightedPersonalities = this.personalities.map((personality) => {
      let weight = 50

      // Match personality type to template sentiment
      if (template.sentiment === "positive" && personality.sentiment_bias > 0) weight += 30
      if (template.sentiment === "negative" && personality.sentiment_bias < 0) weight += 30
      if (template.sentiment === "analytical" && personality.type === "critic") weight += 40
      if (template.platform === "tiktok" && personality.type === "influencer") weight += 25
      if (template.platform === "youtube" && personality.engagement_style === "analytical") weight += 20

      // Adjust for context
      if (contextData.scandals > 0 && personality.type === "troll") weight += 50
      if (contextData.awards > 0 && personality.type === "critic") weight += 30
      if (contextData.boxOffice > 200000000 && personality.type === "fan") weight += 20

      return { personality, weight }
    })

    const totalWeight = weightedPersonalities.reduce((sum, item) => sum + item.weight, 0)
    let random = Math.random() * totalWeight

    for (const item of weightedPersonalities) {
      random -= item.weight
      if (random <= 0) return item.personality
    }

    return this.personalities[0]
  }

  private createPost(
    template: ContentTemplate,
    personality: AIPersonality,
    movie: string,
    actor: string,
    genre: string,
    contextData: any,
  ) {
    // Generate content
    let content = template.template
    const hashtags = this.generateHashtags(movie, actor, genre, template.platform)
    const mentions = this.generateMentions(personality, template.platform)

    // Replace variables
    content = content.replace(/{movie}/g, movie)
    content = content.replace(/{actor}/g, actor)
    content = content.replace(/{genre}/g, genre)
    content = content.replace(/{hashtag}/g, hashtags[0]?.replace("#", "") || movie.replace(/\s+/g, ""))
    content = content.replace(/{director}/g, this.generateDirectorName())
    content = content.replace(/{scene_description}/g, this.generateSceneDescription())
    content = content.replace(/{plot_element}/g, this.generatePlotElement())

    // Apply personality modifications
    content = this.applyPersonalityModifications(content, personality)

    // Calculate engagement
    const engagement = this.calculateEngagement(template, personality, contextData)

    // Calculate virality score
    const viralityScore = this.calculateViralityScore(template, personality, contextData, engagement)

    return {
      id: Math.random().toString(36).substr(2, 9),
      platform: template.platform,
      author: personality,
      content,
      type: template.type,
      timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
      engagement,
      sentiment: template.sentiment,
      viralityScore,
      hashtags,
      mentions,
    }
  }

  private generateHashtags(movie: string, actor: string, genre: string, platform: string): string[] {
    const baseHashtags = [
      `#${movie.replace(/\s+/g, "")}`,
      `#${actor.replace(/\s+/g, "")}`,
      `#${genre.replace(/\s+/g, "")}Movie`,
    ]

    const platformSpecific = {
      twitter: ["#MovieTwitter", "#FilmTwitter", "#CinemaTwitter"],
      tiktok: ["#MovieTok", "#FilmTok", "#CinemaTok", "#Viral", "#FYP"],
      instagram: ["#MovieGram", "#Cinema", "#Film", "#Movies"],
      youtube: ["#MovieReview", "#FilmAnalysis", "#Cinema"],
      reddit: ["#movies", "#film", "#cinema"],
    }

    const trending = ["#BoxOffice", "#Hollywood", "#Entertainment", "#MustWatch"]

    return [
      ...baseHashtags,
      ...(platformSpecific[platform as keyof typeof platformSpecific]?.slice(0, 2) || []),
      ...trending.slice(0, 1),
    ]
  }

  private generateMentions(personality: AIPersonality, platform: string): string[] {
    const mentions = []

    if (personality.type === "influencer" && Math.random() < 0.3) {
      mentions.push("@OfficialStudio", "@MovieOfficial")
    }

    if (personality.type === "critic" && Math.random() < 0.4) {
      mentions.push("@RottenTomatoes", "@IMDb")
    }

    return mentions
  }

  private generateDirectorName(): string {
    const directors = [
      "Christopher Nolan",
      "Greta Gerwig",
      "Denis Villeneuve",
      "Jordan Peele",
      "Chloé Zhao",
      "Ryan Coogler",
      "Ari Aster",
      "Lulu Wang",
    ]
    return directors[Math.floor(Math.random() * directors.length)]
  }

  private generateSceneDescription(): string {
    const descriptions = [
      "rooftop chase",
      "emotional breakdown",
      "final confrontation",
      "plot twist reveal",
      "action sequence",
      "romantic moment",
      "dramatic monologue",
      "climactic battle",
    ]
    return descriptions[Math.floor(Math.random() * descriptions.length)]
  }

  private generatePlotElement(): string {
    const elements = [
      "ending",
      "plot twist",
      "character development",
      "pacing",
      "dialogue",
      "cinematography",
      "soundtrack",
      "special effects",
      "themes",
      "symbolism",
    ]
    return elements[Math.floor(Math.random() * elements.length)]
  }

  private applyPersonalityModifications(content: string, personality: AIPersonality): string {
    let modified = content

    switch (personality.engagement_style) {
      case "aggressive":
        modified = modified.replace(/!/g, "!!!")
        modified = modified.replace(/\?/g, "???")
        if (Math.random() < 0.3) modified += " FIGHT ME!"
        break

      case "dramatic":
        modified = modified.replace(/\./g, "...")
        if (Math.random() < 0.4) modified += " I'M LITERALLY CRYING 😭"
        break

      case "humorous":
        if (Math.random() < 0.3) modified += " (but make it funny 😂)"
        break

      case "analytical":
        if (Math.random() < 0.2) modified += " Let me explain why in a thread 🧵"
        break
    }

    // Add personality-specific emojis
    if (personality.type === "fan" && Math.random() < 0.5) {
      modified += " ❤️"
    }

    if (personality.type === "troll" && Math.random() < 0.4) {
      modified += " 🤡"
    }

    return modified
  }

  private calculateEngagement(template: ContentTemplate, personality: AIPersonality, contextData: any) {
    const base = template.engagementPattern
    const followerMultiplier = Math.log10(personality.followers + 1) / 6 // Logarithmic scaling
    const credibilityMultiplier = personality.credibility / 100

    // Context multipliers
    let contextMultiplier = 1
    if (contextData.boxOffice > 100000000) contextMultiplier += 0.5
    if (contextData.awards > 0) contextMultiplier += 0.3
    if (contextData.scandals > 0) contextMultiplier += 0.4
    if (contextData.weeksSinceRelease < 2) contextMultiplier += 0.6 // Opening week boost

    const finalMultiplier = followerMultiplier * credibilityMultiplier * contextMultiplier

    const likes = Math.floor(
      (base.likes.min + Math.random() * (base.likes.max - base.likes.min)) * base.likes.multiplier * finalMultiplier,
    )

    const comments = Math.floor(
      (base.comments.min + Math.random() * (base.comments.max - base.comments.min)) *
        base.comments.multiplier *
        finalMultiplier,
    )

    const shares = Math.floor(
      (base.shares.min + Math.random() * (base.shares.max - base.shares.min)) *
        base.shares.multiplier *
        finalMultiplier,
    )

    const engagement: any = { likes, comments, shares }

    // Add views for video platforms
    if (template.platform === "tiktok" || template.platform === "youtube") {
      engagement.views = Math.floor(likes * (5 + Math.random() * 15)) // 5-20x likes
    }

    return engagement
  }

  private calculateViralityScore(
    template: ContentTemplate,
    personality: AIPersonality,
    contextData: any,
    engagement: any,
  ): number {
    let score = template.viralPotential

    // Engagement boost
    const engagementScore = (engagement.likes + engagement.comments * 2 + engagement.shares * 3) / 1000
    score += Math.min(30, engagementScore)

    // Personality influence
    score += personality.credibility * 0.2
    score += personality.followers / 10000

    // Context boost
    if (contextData.scandals > 0) score += 15
    if (contextData.boxOffice > 200000000) score += 10
    if (contextData.awards > 0) score += 8

    // Platform-specific boosts
    if (template.platform === "tiktok" && template.type === "video") score += 10
    if (template.platform === "twitter" && template.type === "thread") score += 5

    return Math.max(0, Math.min(100, score))
  }

  // Generate trending topics and challenges
  generateTrendingContent(movies: Array<{ title: string; genre: string; boxOffice: number; socialBuzz: number }>) {
    const trends = []

    movies.forEach((movie) => {
      if (movie.socialBuzz > 70) {
        // Generate hashtag challenges
        if (Math.random() < 0.3) {
          trends.push({
            type: "challenge",
            hashtag: `#${movie.title.replace(/\s+/g, "")}Challenge`,
            platform: "tiktok",
            description: `Recreate iconic scenes from ${movie.title}`,
            participation: Math.floor(movie.socialBuzz * 1000),
          })
        }

        // Generate meme trends
        if (Math.random() < 0.4) {
          trends.push({
            type: "meme",
            hashtag: `#${movie.title.replace(/\s+/g, "")}Memes`,
            platform: "twitter",
            description: `Memes inspired by ${movie.title}`,
            participation: Math.floor(movie.socialBuzz * 500),
          })
        }
      }
    })

    return trends
  }
}
