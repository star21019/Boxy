import { ContentGenerator } from "./content-generator"

export interface SocialMediaPost {
  id: string
  platform: "twitter" | "tiktok" | "instagram" | "youtube" | "reddit"
  author: {
    id: string
    name: string
    handle: string
    verified: boolean
    followers: number
    avatar: string
    type: "fan" | "critic" | "influencer" | "celebrity" | "journalist" | "troll" | "bot"
  }
  content: string
  type: "text" | "image" | "video" | "story" | "reel" | "thread"
  timestamp: Date
  engagement: {
    likes: number
    comments: number
    shares: number
    views?: number
    saves?: number
  }
  sentiment: "positive" | "negative" | "neutral" | "controversial"
  viralityScore: number
  hashtags: string[]
  mentions: string[]
  replies?: SocialMediaPost[]
  isSponsored: boolean
  isVerified: boolean
}

export interface TrendingTopic {
  id: string
  hashtag: string
  platform: string
  posts: number
  engagement: number
  sentiment: number
  growth: number
  category: "movie" | "actor" | "director" | "genre" | "controversy" | "meme"
}

export interface SocialMediaMetrics {
  totalMentions: number
  sentimentScore: number
  viralityIndex: number
  platformBreakdown: Record<string, number>
  topHashtags: string[]
  influencerReach: number
  organicReach: number
  controversyLevel: number
}

export class SocialMediaEngine {
  private contentGenerator = new ContentGenerator()
  private posts: SocialMediaPost[] = []
  private trendingTopics: TrendingTopic[] = []

  generateMovieBuzz(movieData: {
    title: string
    actor: string
    director: string
    genre: string
    budget: number
    boxOffice: number
    rating: number
    awards: number
    scandals: number
    weeksSinceRelease: number
    marketingBudget: number
  }): {
    posts: SocialMediaPost[]
    metrics: SocialMediaMetrics
    trending: TrendingTopic[]
  } {
    const platforms = ["twitter", "tiktok", "instagram", "youtube", "reddit"]
    const allPosts: SocialMediaPost[] = []

    // Generate content for each platform
    platforms.forEach((platform) => {
      const { posts } = this.contentGenerator.generateContent(
        movieData.title,
        movieData.actor,
        movieData.genre,
        platform,
        {
          boxOffice: movieData.boxOffice,
          rating: movieData.rating,
          awards: movieData.awards,
          scandals: movieData.scandals,
          weeksSinceRelease: movieData.weeksSinceRelease,
          marketingBudget: movieData.marketingBudget,
        },
      )

      // Convert to SocialMediaPost format
      const platformPosts = posts.map((post) => this.convertToSocialMediaPost(post, platform))
      allPosts.push(...platformPosts)
    })

    // Generate replies and interactions
    this.generateInteractions(allPosts)

    // Calculate metrics
    const metrics = this.calculateMetrics(allPosts, movieData)

    // Generate trending topics
    const trending = this.generateTrendingTopics(allPosts, movieData)

    // Store posts
    this.posts.push(...allPosts)

    return { posts: allPosts, metrics, trending }
  }

  private convertToSocialMediaPost(post: any, platform: string): SocialMediaPost {
    return {
      id: post.id,
      platform: platform as any,
      author: {
        id: post.author.id,
        name: post.author.name,
        handle: `@${post.author.name.toLowerCase().replace(/\s+/g, "")}`,
        verified: post.author.credibility > 80,
        followers: post.author.followers,
        avatar: `/placeholder.svg?height=40&width=40`,
        type: post.author.type,
      },
      content: post.content,
      type: post.type,
      timestamp: post.timestamp,
      engagement: post.engagement,
      sentiment: post.sentiment,
      viralityScore: post.viralityScore,
      hashtags: post.hashtags,
      mentions: post.mentions,
      replies: [],
      isSponsored: Math.random() < 0.1, // 10% chance of sponsored content
      isVerified: post.author.credibility > 70,
    }
  }

  private generateInteractions(posts: SocialMediaPost[]): void {
    posts.forEach((post) => {
      // Generate replies based on engagement
      const replyCount = Math.min(5, Math.floor(post.engagement.comments / 100))

      for (let i = 0; i < replyCount; i++) {
        const reply = this.generateReply(post)
        if (reply) {
          post.replies = post.replies || []
          post.replies.push(reply)
        }
      }
    })
  }

  private generateReply(originalPost: SocialMediaPost): SocialMediaPost | null {
    const replyTemplates = {
      positive: [
        "This! Absolutely loved it too! 🔥",
        "Finally someone said it! Best movie of the year!",
        "I'm seeing it again this weekend because of this post!",
        "The cinematography was INSANE! 📸",
      ],
      negative: [
        "Hard disagree but respect your opinion",
        "Really? I thought it was amazing!",
        "Maybe you missed the point? 🤔",
        "Different strokes for different folks I guess",
      ],
      neutral: [
        "Interesting take! What did you think about the ending?",
        "I need to see it again to form a proper opinion",
        "The soundtrack was definitely the highlight for me",
        "Fair points, though I enjoyed it more than you did",
      ],
    }

    const templates = replyTemplates[originalPost.sentiment] || replyTemplates.neutral
    const template = templates[Math.floor(Math.random() * templates.length)]

    return {
      id: Math.random().toString(36).substr(2, 9),
      platform: originalPost.platform,
      author: {
        id: `reply_user_${Math.random().toString(36).substr(2, 6)}`,
        name: `User${Math.floor(Math.random() * 9999)}`,
        handle: `@user${Math.floor(Math.random() * 9999)}`,
        verified: false,
        followers: Math.floor(Math.random() * 10000),
        avatar: `/placeholder.svg?height=32&width=32`,
        type: "fan",
      },
      content: template,
      type: "text",
      timestamp: new Date(originalPost.timestamp.getTime() + Math.random() * 24 * 60 * 60 * 1000),
      engagement: {
        likes: Math.floor(Math.random() * 100),
        comments: Math.floor(Math.random() * 10),
        shares: Math.floor(Math.random() * 5),
      },
      sentiment: originalPost.sentiment === "negative" ? "positive" : originalPost.sentiment,
      viralityScore: Math.random() * 30,
      hashtags: [],
      mentions: [originalPost.author.handle],
      isSponsored: false,
      isVerified: false,
    }
  }

  private calculateMetrics(posts: SocialMediaPost[], movieData: any): SocialMediaMetrics {
    const totalMentions = posts.length
    const totalEngagement = posts.reduce(
      (sum, post) => sum + post.engagement.likes + post.engagement.comments + post.engagement.shares,
      0,
    )

    // Calculate sentiment score (-100 to 100)
    const sentimentScores = posts.map((post) => {
      switch (post.sentiment) {
        case "positive":
          return 1
        case "negative":
          return -1
        case "controversial":
          return -0.5
        default:
          return 0
      }
    })
    const sentimentScore = (sentimentScores.reduce((sum, score) => sum + score, 0) / posts.length) * 100

    // Calculate virality index
    const viralityIndex = posts.reduce((sum, post) => sum + post.viralityScore, 0) / posts.length

    // Platform breakdown
    const platformBreakdown: Record<string, number> = {}
    posts.forEach((post) => {
      platformBreakdown[post.platform] = (platformBreakdown[post.platform] || 0) + 1
    })

    // Top hashtags
    const hashtagCounts: Record<string, number> = {}
    posts.forEach((post) => {
      post.hashtags.forEach((hashtag) => {
        hashtagCounts[hashtag] = (hashtagCounts[hashtag] || 0) + 1
      })
    })
    const topHashtags = Object.entries(hashtagCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([hashtag]) => hashtag)

    // Influencer vs organic reach
    const influencerPosts = posts.filter((post) => post.author.type === "influencer" || post.author.followers > 50000)
    const influencerReach = influencerPosts.reduce((sum, post) => sum + post.author.followers, 0)
    const organicReach = totalEngagement - influencerReach

    // Controversy level
    const controversyLevel =
      (posts.filter((post) => post.sentiment === "controversial" || post.sentiment === "negative").length /
        posts.length) *
      100

    return {
      totalMentions,
      sentimentScore,
      viralityIndex,
      platformBreakdown,
      topHashtags,
      influencerReach,
      organicReach,
      controversyLevel,
    }
  }

  private generateTrendingTopics(posts: SocialMediaPost[], movieData: any): TrendingTopic[] {
    const topics: TrendingTopic[] = []

    // Movie-specific trending
    if (posts.length > 20) {
      topics.push({
        id: `trending_${movieData.title.replace(/\s+/g, "_").toLowerCase()}`,
        hashtag: `#${movieData.title.replace(/\s+/g, "")}`,
        platform: "twitter",
        posts: posts.filter((p) => p.platform === "twitter").length,
        engagement: posts.reduce((sum, p) => sum + p.engagement.likes, 0),
        sentiment: posts.reduce(
          (sum, p) => sum + (p.sentiment === "positive" ? 1 : p.sentiment === "negative" ? -1 : 0),
          0,
        ),
        growth: Math.random() * 200 - 50, // -50% to +150% growth
        category: "movie",
      })
    }

    // Actor trending
    const actorPosts = posts.filter((p) => p.content.includes(movieData.actor))
    if (actorPosts.length > 10) {
      topics.push({
        id: `trending_${movieData.actor.replace(/\s+/g, "_").toLowerCase()}`,
        hashtag: `#${movieData.actor.replace(/\s+/g, "")}`,
        platform: "instagram",
        posts: actorPosts.length,
        engagement: actorPosts.reduce((sum, p) => sum + p.engagement.likes, 0),
        sentiment: actorPosts.reduce(
          (sum, p) => sum + (p.sentiment === "positive" ? 1 : p.sentiment === "negative" ? -1 : 0),
          0,
        ),
        growth: Math.random() * 150,
        category: "actor",
      })
    }

    // Controversy trending
    if (movieData.scandals > 0) {
      topics.push({
        id: `controversy_${movieData.title.replace(/\s+/g, "_").toLowerCase()}`,
        hashtag: `#${movieData.title.replace(/\s+/g, "")}Controversy`,
        platform: "twitter",
        posts: posts.filter((p) => p.sentiment === "controversial" || p.sentiment === "negative").length,
        engagement: posts
          .filter((p) => p.sentiment === "controversial")
          .reduce((sum, p) => sum + p.engagement.comments, 0),
        sentiment: -50,
        growth: Math.random() * 300,
        category: "controversy",
      })
    }

    // Meme trending (TikTok)
    const memePosts = posts.filter((p) => p.platform === "tiktok" && p.viralityScore > 70)
    if (memePosts.length > 5) {
      topics.push({
        id: `meme_${movieData.title.replace(/\s+/g, "_").toLowerCase()}`,
        hashtag: `#${movieData.title.replace(/\s+/g, "")}Memes`,
        platform: "tiktok",
        posts: memePosts.length,
        engagement: memePosts.reduce((sum, p) => sum + (p.engagement.views || 0), 0),
        sentiment: 75,
        growth: Math.random() * 500,
        category: "meme",
      })
    }

    return topics.sort((a, b) => b.engagement - a.engagement)
  }

  // Get posts for specific platform
  getPostsByPlatform(platform: string, limit = 10): SocialMediaPost[] {
    return this.posts
      .filter((post) => post.platform === platform)
      .sort((a, b) => b.viralityScore - a.viralityScore)
      .slice(0, limit)
  }

  // Get trending topics
  getTrendingTopics(platform?: string): TrendingTopic[] {
    let topics = this.trendingTopics
    if (platform) {
      topics = topics.filter((topic) => topic.platform === platform)
    }
    return topics.sort((a, b) => b.growth - a.growth)
  }

  // Simulate viral moment
  simulateViralMoment(movieTitle: string): {
    trigger: string
    platform: string
    impact: {
      newPosts: number
      engagementBoost: number
      sentimentShift: number
    }
  } {
    const triggers = [
      "Celebrity endorsement goes viral",
      "Behind-the-scenes footage leaked",
      "Fan theory gains massive traction",
      "Meme template becomes popular",
      "Controversy sparks debate",
      "Award nomination announced",
      "Director responds to criticism",
    ]

    const platforms = ["twitter", "tiktok", "instagram", "youtube"]

    const trigger = triggers[Math.floor(Math.random() * triggers.length)]
    const platform = platforms[Math.floor(Math.random() * platforms.length)]

    return {
      trigger,
      platform,
      impact: {
        newPosts: Math.floor(Math.random() * 1000) + 500,
        engagementBoost: Math.random() * 200 + 50, // 50-250% boost
        sentimentShift: (Math.random() - 0.5) * 40, // -20 to +20 sentiment shift
      },
    }
  }

  // Generate crisis management scenario
  generateCrisisScenario(movieData: any): {
    type: "scandal" | "backlash" | "controversy" | "leak"
    description: string
    severity: number
    platforms: string[]
    suggestedResponse: string[]
  } {
    const scenarios = [
      {
        type: "scandal" as const,
        description: "Lead actor involved in public controversy",
        severity: 85,
        platforms: ["twitter", "instagram", "tiktok"],
        suggestedResponse: [
          "Issue official statement",
          "Increase positive content promotion",
          "Engage with supportive fans",
          "Consider damage control campaign",
        ],
      },
      {
        type: "backlash" as const,
        description: "Negative reviews spark fan outrage",
        severity: 60,
        platforms: ["twitter", "reddit", "youtube"],
        suggestedResponse: [
          "Highlight positive reviews",
          "Share behind-the-scenes content",
          "Engage with constructive criticism",
          "Focus on fan testimonials",
        ],
      },
      {
        type: "leak" as const,
        description: "Major plot points leaked online",
        severity: 70,
        platforms: ["reddit", "twitter", "youtube"],
        suggestedResponse: [
          "Request takedown of leaked content",
          "Create spoiler-free promotional content",
          "Engage with fans about spoiler etiquette",
          "Release official teasers to control narrative",
        ],
      },
    ]

    return scenarios[Math.floor(Math.random() * scenarios.length)]
  }
}
