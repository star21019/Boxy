import type { Influencer } from "./influencer-database"

export interface CampaignProposal {
  id: string
  influencer_id: string
  campaign_type: "sponsored_post" | "review" | "challenge" | "takeover" | "series" | "premiere_attendance"
  content_requirements: {
    post_count: number
    content_types: ("image" | "video" | "story" | "reel" | "thread")[]
    hashtags_required: string[]
    mentions_required: string[]
    creative_freedom: number // 0-100
  }
  timeline: {
    start_date: Date
    end_date: Date
    key_milestones: { date: Date; description: string }[]
  }
  compensation: {
    base_payment: number
    performance_bonuses: { metric: string; threshold: number; bonus: number }[]
    additional_perks: string[]
  }
  deliverables: {
    description: string
    due_date: Date
    approval_required: boolean
  }[]
  exclusivity: {
    competitor_blackout: number // days
    genre_exclusivity: boolean
    platform_exclusivity: boolean
  }
  success_metrics: {
    primary_kpi: "reach" | "engagement" | "conversions" | "sentiment"
    target_values: Record<string, number>
  }
}

export interface CampaignResponse {
  proposal_id: string
  status: "accepted" | "rejected" | "counter_offer"
  counter_terms?: Partial<CampaignProposal>
  negotiation_points: string[]
  influencer_concerns: string[]
  acceptance_probability: number
}

export interface ActiveCampaign {
  id: string
  proposal: CampaignProposal
  influencer: Influencer
  status: "planning" | "active" | "completed" | "cancelled"
  progress: {
    posts_delivered: number
    engagement_generated: number
    reach_achieved: number
    sentiment_score: number
  }
  performance_metrics: {
    impressions: number
    clicks: number
    conversions: number
    cost_per_engagement: number
    roi: number
  }
  timeline_adherence: number // 0-100
  content_quality_score: number // 0-100
}

export class CampaignManager {
  private activeCampaigns: ActiveCampaign[] = []
  private campaignHistory: ActiveCampaign[] = []

  createCampaignProposal(
    influencer: Influencer,
    movieData: {
      title: string
      genre: string
      budget: number
      target_audience: { age: string; gender: string; location: string }
      release_date: Date
    },
    campaignObjectives: {
      primary_goal: "awareness" | "engagement" | "conversion" | "sentiment"
      budget: number
      duration_days: number
      urgency: "low" | "medium" | "high"
    },
  ): CampaignProposal {
    const campaignType = this.selectOptimalCampaignType(influencer, campaignObjectives)
    const compensation = this.calculateCompensation(influencer, campaignObjectives, campaignType)

    return {
      id: `campaign_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      influencer_id: influencer.id,
      campaign_type: campaignType,
      content_requirements: this.generateContentRequirements(influencer, movieData, campaignType),
      timeline: this.generateTimeline(movieData.release_date, campaignObjectives.duration_days),
      compensation,
      deliverables: this.generateDeliverables(campaignType, influencer.platform),
      exclusivity: this.generateExclusivityTerms(influencer, campaignObjectives),
      success_metrics: this.generateSuccessMetrics(campaignObjectives, influencer),
    }
  }

  private selectOptimalCampaignType(
    influencer: Influencer,
    objectives: { primary_goal: string; urgency: string },
  ): CampaignProposal["campaign_type"] {
    // Celebrity tier gets premiere attendance and takeovers
    if (influencer.tier === "celebrity") {
      return Math.random() < 0.4 ? "premiere_attendance" : "takeover"
    }

    // High engagement micro/nano influencers get challenges
    if ((influencer.tier === "micro" || influencer.tier === "nano") && influencer.engagement_rate > 20) {
      return "challenge"
    }

    // YouTube influencers get review opportunities
    if (influencer.platform === "youtube") {
      return "review"
    }

    // TikTok influencers get challenges and series
    if (influencer.platform === "tiktok") {
      return Math.random() < 0.6 ? "challenge" : "series"
    }

    // Default to sponsored posts
    return "sponsored_post"
  }

  private calculateCompensation(
    influencer: Influencer,
    objectives: { budget: number; primary_goal: string },
    campaignType: CampaignProposal["campaign_type"],
  ): CampaignProposal["compensation"] {
    let basePayment = influencer.pricing.base_rate

    // Campaign type multipliers
    const typeMultipliers = {
      sponsored_post: 1.0,
      review: 1.2,
      challenge: 0.8,
      takeover: 1.5,
      series: 1.8,
      premiere_attendance: 2.0,
    }

    basePayment *= typeMultipliers[campaignType]

    // Adjust for budget constraints
    if (basePayment > objectives.budget * 0.8) {
      basePayment = objectives.budget * 0.8
    }

    // Performance bonuses
    const performanceBonuses = [
      { metric: "engagement_rate", threshold: influencer.engagement_rate * 1.2, bonus: basePayment * 0.1 },
      { metric: "reach", threshold: influencer.followers * 0.8, bonus: basePayment * 0.05 },
      { metric: "sentiment_score", threshold: 75, bonus: basePayment * 0.15 },
    ]

    // Additional perks based on tier
    const additionalPerks = []
    if (influencer.tier === "celebrity" || influencer.tier === "mega") {
      additionalPerks.push("Red carpet access", "Exclusive interview opportunity", "Behind-the-scenes content")
    }
    if (influencer.tier === "macro" || influencer.tier === "micro") {
      additionalPerks.push("Early screening access", "Merchandise package", "Director meet-and-greet")
    }

    return {
      base_payment: Math.round(basePayment),
      performance_bonuses: performanceBonuses,
      additional_perks: additionalPerks,
    }
  }

  private generateContentRequirements(
    influencer: Influencer,
    movieData: { title: string; genre: string },
    campaignType: CampaignProposal["campaign_type"],
  ): CampaignProposal["content_requirements"] {
    const platformContentTypes = {
      instagram: ["image", "video", "story", "reel"],
      tiktok: ["video", "story"],
      youtube: ["video"],
      twitter: ["image", "video", "thread"],
      twitch: ["video"],
    }

    const campaignPostCounts = {
      sponsored_post: 1,
      review: 1,
      challenge: 3,
      takeover: 5,
      series: 7,
      premiere_attendance: 2,
    }

    return {
      post_count: campaignPostCounts[campaignType],
      content_types: platformContentTypes[influencer.platform] as any[],
      hashtags_required: [`#${movieData.title.replace(/\s+/g, "")}`, `#${movieData.genre}Movie`, "#Sponsored"],
      mentions_required: ["@OfficialStudio"],
      creative_freedom: influencer.content_style.professionalism > 80 ? 80 : 60,
    }
  }

  private generateTimeline(releaseDate: Date, durationDays: number): CampaignProposal["timeline"] {
    const startDate = new Date(releaseDate.getTime() - durationDays * 24 * 60 * 60 * 1000)
    const endDate = new Date(releaseDate.getTime() + 7 * 24 * 60 * 60 * 1000) // Week after release

    const milestones = [
      { date: startDate, description: "Campaign kickoff and content briefing" },
      {
        date: new Date(startDate.getTime() + (durationDays * 24 * 60 * 60 * 1000) / 2),
        description: "Mid-campaign check-in and content review",
      },
      { date: releaseDate, description: "Movie release day - peak posting" },
      { date: endDate, description: "Campaign wrap-up and performance review" },
    ]

    return { start_date: startDate, end_date: endDate, key_milestones: milestones }
  }

  private generateDeliverables(
    campaignType: CampaignProposal["campaign_type"],
    platform: string,
  ): CampaignProposal["deliverables"] {
    const baseDeliverables = [
      {
        description: "Content calendar and posting schedule",
        due_date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        approval_required: true,
      },
      {
        description: "Draft content for approval",
        due_date: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
        approval_required: true,
      },
    ]

    if (campaignType === "review") {
      baseDeliverables.push({
        description: "Detailed review video/post",
        due_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        approval_required: false,
      })
    }

    if (campaignType === "challenge") {
      baseDeliverables.push({
        description: "Challenge creation and participation",
        due_date: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
        approval_required: false,
      })
    }

    return baseDeliverables
  }

  private generateExclusivityTerms(
    influencer: Influencer,
    objectives: { urgency: string },
  ): CampaignProposal["exclusivity"] {
    return {
      competitor_blackout: influencer.tier === "celebrity" ? 90 : influencer.tier === "mega" ? 60 : 30,
      genre_exclusivity: objectives.urgency === "high",
      platform_exclusivity: influencer.tier === "celebrity" || influencer.tier === "mega",
    }
  }

  private generateSuccessMetrics(
    objectives: { primary_goal: string },
    influencer: Influencer,
  ): CampaignProposal["success_metrics"] {
    const targetValues: Record<string, number> = {}

    switch (objectives.primary_goal) {
      case "awareness":
        targetValues.reach = influencer.followers * 0.6
        targetValues.impressions = influencer.followers * 1.5
        break
      case "engagement":
        targetValues.engagement_rate = influencer.engagement_rate * 1.1
        targetValues.comments = influencer.followers * (influencer.engagement_rate / 100) * 0.3
        break
      case "conversion":
        targetValues.click_through_rate = 2.5
        targetValues.conversions = influencer.followers * 0.01
        break
      case "sentiment":
        targetValues.sentiment_score = 75
        targetValues.positive_mentions = influencer.followers * 0.05
        break
    }

    return {
      primary_kpi: objectives.primary_goal as any,
      target_values: targetValues,
    }
  }

  simulateNegotiation(proposal: CampaignProposal, influencer: Influencer): CampaignResponse {
    let acceptanceProbability = 50

    // Base acceptance factors
    acceptanceProbability += influencer.pricing.negotiation_flexibility * 0.3
    acceptanceProbability += influencer.past_performance.reliability_score * 0.2

    // Payment satisfaction
    const paymentSatisfaction = proposal.compensation.base_payment / influencer.pricing.base_rate
    if (paymentSatisfaction >= 1.0) acceptanceProbability += 20
    else if (paymentSatisfaction >= 0.8) acceptanceProbability += 10
    else acceptanceProbability -= 20

    // Creative freedom
    if (proposal.content_requirements.creative_freedom >= 70) acceptanceProbability += 15
    else if (proposal.content_requirements.creative_freedom < 50) acceptanceProbability -= 10

    // Timeline pressure
    const daysUntilStart = Math.floor((proposal.timeline.start_date.getTime() - Date.now()) / (24 * 60 * 60 * 1000))
    if (daysUntilStart < 3) acceptanceProbability -= 25
    else if (daysUntilStart > 14) acceptanceProbability += 10

    // Brand safety concerns
    if (influencer.content_style.brand_safety > 80 && proposal.campaign_type === "challenge") {
      acceptanceProbability -= 15
    }

    // Clamp probability
    acceptanceProbability = Math.max(0, Math.min(100, acceptanceProbability))

    // Determine response
    if (acceptanceProbability >= 70) {
      return {
        proposal_id: proposal.id,
        status: "accepted",
        negotiation_points: ["Excited to work together!", "Timeline looks perfect"],
        influencer_concerns: [],
        acceptance_probability: acceptanceProbability,
      }
    } else if (acceptanceProbability >= 40) {
      return {
        proposal_id: proposal.id,
        status: "counter_offer",
        counter_terms: this.generateCounterOffer(proposal, influencer),
        negotiation_points: ["Would love to work together with some adjustments", "Open to discussion"],
        influencer_concerns: this.generateConcerns(proposal, influencer),
        acceptance_probability: acceptanceProbability,
      }
    } else {
      return {
        proposal_id: proposal.id,
        status: "rejected",
        negotiation_points: ["Not the right fit at this time", "Perhaps we can work together in the future"],
        influencer_concerns: this.generateConcerns(proposal, influencer),
        acceptance_probability: acceptanceProbability,
      }
    }
  }

  private generateCounterOffer(proposal: CampaignProposal, influencer: Influencer): Partial<CampaignProposal> {
    const counterOffer: Partial<CampaignProposal> = {}

    // Payment adjustment
    if (proposal.compensation.base_payment < influencer.pricing.base_rate * 0.9) {
      counterOffer.compensation = {
        ...proposal.compensation,
        base_payment: Math.round(influencer.pricing.base_rate * 0.95),
      }
    }

    // Creative freedom adjustment
    if (proposal.content_requirements.creative_freedom < 60) {
      counterOffer.content_requirements = {
        ...proposal.content_requirements,
        creative_freedom: 75,
      }
    }

    // Timeline adjustment
    const daysUntilStart = Math.floor((proposal.timeline.start_date.getTime() - Date.now()) / (24 * 60 * 60 * 1000))
    if (daysUntilStart < 5) {
      const newStartDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      counterOffer.timeline = {
        ...proposal.timeline,
        start_date: newStartDate,
      }
    }

    return counterOffer
  }

  private generateConcerns(proposal: CampaignProposal, influencer: Influencer): string[] {
    const concerns = []

    if (proposal.compensation.base_payment < influencer.pricing.base_rate * 0.8) {
      concerns.push("Compensation below market rate")
    }

    if (proposal.content_requirements.creative_freedom < 50) {
      concerns.push("Limited creative freedom")
    }

    const daysUntilStart = Math.floor((proposal.timeline.start_date.getTime() - Date.now()) / (24 * 60 * 60 * 1000))
    if (daysUntilStart < 3) {
      concerns.push("Very tight timeline")
    }

    if (proposal.exclusivity.competitor_blackout > 60 && influencer.tier !== "celebrity") {
      concerns.push("Exclusivity period too long")
    }

    return concerns
  }

  launchCampaign(proposal: CampaignProposal, influencer: Influencer): ActiveCampaign {
    const campaign: ActiveCampaign = {
      id: `active_${proposal.id}`,
      proposal,
      influencer,
      status: "planning",
      progress: {
        posts_delivered: 0,
        engagement_generated: 0,
        reach_achieved: 0,
        sentiment_score: 50,
      },
      performance_metrics: {
        impressions: 0,
        clicks: 0,
        conversions: 0,
        cost_per_engagement: 0,
        roi: 0,
      },
      timeline_adherence: 100,
      content_quality_score: 75,
    }

    this.activeCampaigns.push(campaign)
    return campaign
  }

  simulateCampaignProgress(campaignId: string, daysElapsed: number): void {
    const campaign = this.activeCampaigns.find((c) => c.id === campaignId)
    if (!campaign) return

    const totalDays = Math.floor(
      (campaign.proposal.timeline.end_date.getTime() - campaign.proposal.timeline.start_date.getTime()) /
        (24 * 60 * 60 * 1000),
    )
    const progressPercentage = Math.min(100, (daysElapsed / totalDays) * 100)

    // Update status
    if (progressPercentage < 10) campaign.status = "planning"
    else if (progressPercentage < 90) campaign.status = "active"
    else campaign.status = "completed"

    // Simulate progress
    const expectedPosts = Math.floor((campaign.proposal.content_requirements.post_count * progressPercentage) / 100)
    campaign.progress.posts_delivered = Math.min(expectedPosts, campaign.proposal.content_requirements.post_count)

    // Calculate performance based on influencer stats and random factors
    const baseReach = campaign.influencer.followers * (campaign.influencer.engagement_rate / 100)
    const reachMultiplier = 0.8 + Math.random() * 0.4 // 0.8 to 1.2
    campaign.progress.reach_achieved = Math.floor(baseReach * reachMultiplier * (progressPercentage / 100))

    const baseEngagement = campaign.progress.reach_achieved * (campaign.influencer.engagement_rate / 100)
    campaign.progress.engagement_generated = Math.floor(baseEngagement)

    // Sentiment based on content quality and audience match
    const sentimentBase = 50 + campaign.influencer.content_style.brand_safety * 0.3
    campaign.progress.sentiment_score = Math.max(0, Math.min(100, sentimentBase + (Math.random() - 0.5) * 20))

    // Performance metrics
    campaign.performance_metrics.impressions = Math.floor(campaign.progress.reach_achieved * 1.5)
    campaign.performance_metrics.clicks = Math.floor(campaign.progress.engagement_generated * 0.1)
    campaign.performance_metrics.conversions = Math.floor(campaign.performance_metrics.clicks * 0.05)

    if (campaign.progress.engagement_generated > 0) {
      campaign.performance_metrics.cost_per_engagement =
        campaign.proposal.compensation.base_payment / campaign.progress.engagement_generated
    }

    if (campaign.performance_metrics.conversions > 0) {
      const revenue = campaign.performance_metrics.conversions * 15 // Assume $15 per conversion
      campaign.performance_metrics.roi = (revenue / campaign.proposal.compensation.base_payment) * 100
    }

    // Timeline adherence (decreases if behind schedule)
    const expectedProgress = (daysElapsed / totalDays) * 100
    const actualProgress = (campaign.progress.posts_delivered / campaign.proposal.content_requirements.post_count) * 100
    if (actualProgress < expectedProgress) {
      campaign.timeline_adherence = Math.max(0, campaign.timeline_adherence - 5)
    }

    // Content quality (varies based on influencer professionalism)
    const qualityBase = campaign.influencer.content_style.professionalism
    campaign.content_quality_score = Math.max(0, Math.min(100, qualityBase + (Math.random() - 0.5) * 20))
  }

  getActiveCampaigns(): ActiveCampaign[] {
    return this.activeCampaigns
  }

  getCampaignById(id: string): ActiveCampaign | undefined {
    return this.activeCampaigns.find((c) => c.id === id)
  }

  calculateCampaignROI(campaign: ActiveCampaign): {
    financial_roi: number
    engagement_roi: number
    brand_awareness_lift: number
    sentiment_impact: number
  } {
    const totalCost = campaign.proposal.compensation.base_payment
    const revenue = campaign.performance_metrics.conversions * 15 // Assume $15 per conversion

    return {
      financial_roi: totalCost > 0 ? ((revenue - totalCost) / totalCost) * 100 : 0,
      engagement_roi: totalCost > 0 ? (campaign.progress.engagement_generated / totalCost) * 100 : 0,
      brand_awareness_lift: (campaign.progress.reach_achieved / campaign.influencer.followers) * 100,
      sentiment_impact: campaign.progress.sentiment_score - 50, // Baseline is 50
    }
  }
}
