export interface Influencer {
  id: string
  name: string
  handle: string
  platform: "twitter" | "tiktok" | "instagram" | "youtube" | "twitch"
  category: "lifestyle" | "entertainment" | "gaming" | "fashion" | "tech" | "comedy" | "music" | "fitness"
  tier: "nano" | "micro" | "macro" | "mega" | "celebrity"
  followers: number
  engagement_rate: number // 0-100
  authenticity_score: number // 0-100 (how genuine their audience is)
  demographics: {
    age_groups: Record<string, number> // "13-17": 25, "18-24": 40, etc.
    gender: Record<string, number> // "male": 45, "female": 55
    locations: Record<string, number> // "US": 60, "UK": 15, etc.
  }
  content_style: {
    humor_level: number // 0-100
    professionalism: number // 0-100
    controversy_tolerance: number // 0-100
    brand_safety: number // 0-100
  }
  pricing: {
    base_rate: number
    negotiation_flexibility: number // 0-100
    preferred_payment: "upfront" | "performance" | "hybrid"
  }
  availability: {
    busy_until?: Date
    blackout_dates: Date[]
    preferred_campaign_length: number // days
  }
  past_performance: {
    campaigns_completed: number
    average_roi: number
    reliability_score: number // 0-100
    scandal_history: number // 0-10
  }
  relationships: {
    studio_history: Record<string, number> // studio_id -> relationship score
    competitor_conflicts: string[] // competitor studio IDs
    genre_affinity: Record<string, number> // genre -> affinity score
  }
  special_abilities: string[] // "viral_potential", "award_influence", "crisis_management", etc.
}

export class InfluencerDatabase {
  private influencers: Influencer[] = [
    // Celebrity Tier
    {
      id: "celeb_001",
      name: "Emma Stone",
      handle: "@emmastone",
      platform: "instagram",
      category: "entertainment",
      tier: "celebrity",
      followers: 15000000,
      engagement_rate: 8.5,
      authenticity_score: 95,
      demographics: {
        age_groups: { "18-24": 30, "25-34": 35, "35-44": 25, "45+": 10 },
        gender: { male: 35, female: 65 },
        locations: { US: 45, UK: 15, Canada: 10, Australia: 8, Other: 22 },
      },
      content_style: {
        humor_level: 75,
        professionalism: 90,
        controversy_tolerance: 30,
        brand_safety: 95,
      },
      pricing: {
        base_rate: 500000,
        negotiation_flexibility: 20,
        preferred_payment: "upfront",
      },
      availability: {
        preferred_campaign_length: 14,
        blackout_dates: [],
      },
      past_performance: {
        campaigns_completed: 25,
        average_roi: 340,
        reliability_score: 95,
        scandal_history: 1,
      },
      relationships: {
        studio_history: {},
        competitor_conflicts: [],
        genre_affinity: { Drama: 90, Comedy: 85, Romance: 80, Action: 60 },
      },
      special_abilities: ["award_influence", "mainstream_appeal", "brand_safety"],
    },

    // Mega Influencer
    {
      id: "mega_001",
      name: "MovieReviewGuru",
      handle: "@moviereviewguru",
      platform: "youtube",
      category: "entertainment",
      tier: "mega",
      followers: 5200000,
      engagement_rate: 12.3,
      authenticity_score: 88,
      demographics: {
        age_groups: { "16-24": 45, "25-34": 35, "35-44": 15, "45+": 5 },
        gender: { male: 70, female: 30 },
        locations: { US: 55, UK: 12, Canada: 8, Germany: 6, Other: 19 },
      },
      content_style: {
        humor_level: 60,
        professionalism: 85,
        controversy_tolerance: 70,
        brand_safety: 80,
      },
      pricing: {
        base_rate: 150000,
        negotiation_flexibility: 40,
        preferred_payment: "hybrid",
      },
      availability: {
        preferred_campaign_length: 21,
        blackout_dates: [],
      },
      past_performance: {
        campaigns_completed: 45,
        average_roi: 280,
        reliability_score: 90,
        scandal_history: 2,
      },
      relationships: {
        studio_history: {},
        competitor_conflicts: [],
        genre_affinity: { "Sci-Fi": 95, Action: 90, Horror: 85, Drama: 70, Comedy: 65 },
      },
      special_abilities: ["viral_potential", "critic_influence", "deep_analysis"],
    },

    // TikTok Macro Influencer
    {
      id: "macro_001",
      name: "DanceQueenMia",
      handle: "@dancequeenmia",
      platform: "tiktok",
      category: "entertainment",
      tier: "macro",
      followers: 2800000,
      engagement_rate: 18.7,
      authenticity_score: 82,
      demographics: {
        age_groups: { "13-17": 35, "18-24": 40, "25-34": 20, "35+": 5 },
        gender: { male: 25, female: 75 },
        locations: { US: 60, UK: 10, Canada: 8, Australia: 5, Other: 17 },
      },
      content_style: {
        humor_level: 90,
        professionalism: 60,
        controversy_tolerance: 50,
        brand_safety: 75,
      },
      pricing: {
        base_rate: 75000,
        negotiation_flexibility: 60,
        preferred_payment: "performance",
      },
      availability: {
        preferred_campaign_length: 7,
        blackout_dates: [],
      },
      past_performance: {
        campaigns_completed: 35,
        average_roi: 420,
        reliability_score: 85,
        scandal_history: 0,
      },
      relationships: {
        studio_history: {},
        competitor_conflicts: [],
        genre_affinity: { Comedy: 95, Musical: 90, Romance: 80, Action: 70, Drama: 50 },
      },
      special_abilities: ["viral_potential", "trend_creation", "youth_appeal"],
    },

    // Micro Influencer - Gaming/Entertainment
    {
      id: "micro_001",
      name: "PixelCinema",
      handle: "@pixelcinema",
      platform: "twitch",
      category: "gaming",
      tier: "micro",
      followers: 450000,
      engagement_rate: 25.4,
      authenticity_score: 92,
      demographics: {
        age_groups: { "16-24": 50, "25-34": 35, "35-44": 12, "45+": 3 },
        gender: { male: 65, female: 35 },
        locations: { US: 45, UK: 15, Germany: 10, Canada: 8, Other: 22 },
      },
      content_style: {
        humor_level: 85,
        professionalism: 70,
        controversy_tolerance: 80,
        brand_safety: 85,
      },
      pricing: {
        base_rate: 25000,
        negotiation_flexibility: 70,
        preferred_payment: "hybrid",
      },
      availability: {
        preferred_campaign_length: 10,
        blackout_dates: [],
      },
      past_performance: {
        campaigns_completed: 20,
        average_roi: 380,
        reliability_score: 95,
        scandal_history: 0,
      },
      relationships: {
        studio_history: {},
        competitor_conflicts: [],
        genre_affinity: { "Sci-Fi": 95, Action: 90, Horror: 85, Animation: 80, Comedy: 75 },
      },
      special_abilities: ["niche_expertise", "high_engagement", "authentic_reviews"],
    },

    // Fashion/Lifestyle Macro
    {
      id: "macro_002",
      name: "StyleIcon_Sarah",
      handle: "@styleiconSarah",
      platform: "instagram",
      category: "fashion",
      tier: "macro",
      followers: 1200000,
      engagement_rate: 15.2,
      authenticity_score: 78,
      demographics: {
        age_groups: { "18-24": 35, "25-34": 40, "35-44": 20, "45+": 5 },
        gender: { male: 15, female: 85 },
        locations: { US: 40, UK: 15, France: 10, Italy: 8, Other: 27 },
      },
      content_style: {
        humor_level: 50,
        professionalism: 95,
        controversy_tolerance: 20,
        brand_safety: 95,
      },
      pricing: {
        base_rate: 45000,
        negotiation_flexibility: 30,
        preferred_payment: "upfront",
      },
      availability: {
        preferred_campaign_length: 14,
        blackout_dates: [],
      },
      past_performance: {
        campaigns_completed: 60,
        average_roi: 250,
        reliability_score: 98,
        scandal_history: 0,
      },
      relationships: {
        studio_history: {},
        competitor_conflicts: [],
        genre_affinity: { Romance: 95, Drama: 80, Comedy: 75, Musical: 85, Action: 40 },
      },
      special_abilities: ["fashion_influence", "brand_safety", "premium_audience"],
    },

    // Comedy Micro Influencer
    {
      id: "micro_002",
      name: "ComedyKing_Jake",
      handle: "@comedykingjake",
      platform: "twitter",
      category: "comedy",
      tier: "micro",
      followers: 680000,
      engagement_rate: 22.1,
      authenticity_score: 85,
      demographics: {
        age_groups: { "18-24": 40, "25-34": 35, "35-44": 20, "45+": 5 },
        gender: { male: 60, female: 40 },
        locations: { US: 70, UK: 12, Canada: 10, Australia: 5, Other: 3 },
      },
      content_style: {
        humor_level: 95,
        professionalism: 60,
        controversy_tolerance: 85,
        brand_safety: 70,
      },
      pricing: {
        base_rate: 18000,
        negotiation_flexibility: 80,
        preferred_payment: "performance",
      },
      availability: {
        preferred_campaign_length: 5,
        blackout_dates: [],
      },
      past_performance: {
        campaigns_completed: 30,
        average_roi: 450,
        reliability_score: 80,
        scandal_history: 3,
      },
      relationships: {
        studio_history: {},
        competitor_conflicts: [],
        genre_affinity: { Comedy: 100, Action: 80, Horror: 75, "Sci-Fi": 70, Drama: 50 },
      },
      special_abilities: ["viral_potential", "meme_creation", "controversy_navigation"],
    },
  ]

  getInfluencers(filters?: {
    platform?: string
    tier?: string
    category?: string
    min_followers?: number
    max_budget?: number
    genre_affinity?: string
  }): Influencer[] {
    let filtered = [...this.influencers]

    if (filters) {
      if (filters.platform) {
        filtered = filtered.filter((inf) => inf.platform === filters.platform)
      }
      if (filters.tier) {
        filtered = filtered.filter((inf) => inf.tier === filters.tier)
      }
      if (filters.category) {
        filtered = filtered.filter((inf) => inf.category === filters.category)
      }
      if (filters.min_followers) {
        filtered = filtered.filter((inf) => inf.followers >= filters.min_followers)
      }
      if (filters.max_budget) {
        filtered = filtered.filter((inf) => inf.pricing.base_rate <= filters.max_budget)
      }
      if (filters.genre_affinity) {
        filtered = filtered.filter((inf) => (inf.relationships.genre_affinity[filters.genre_affinity!] || 0) >= 70)
      }
    }

    return filtered.sort((a, b) => b.followers - a.followers)
  }

  getInfluencerById(id: string): Influencer | undefined {
    return this.influencers.find((inf) => inf.id === id)
  }

  getRecommendations(
    movieGenre: string,
    budget: number,
    targetDemographic: { age: string; gender: string; location: string },
  ): Influencer[] {
    return this.influencers
      .filter((inf) => inf.pricing.base_rate <= budget)
      .map((inf) => ({
        influencer: inf,
        score: this.calculateRecommendationScore(inf, movieGenre, targetDemographic),
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
      .map((item) => item.influencer)
  }

  private calculateRecommendationScore(
    influencer: Influencer,
    genre: string,
    targetDemo: { age: string; gender: string; location: string },
  ): number {
    let score = 0

    // Genre affinity (40% weight)
    const genreAffinity = influencer.relationships.genre_affinity[genre] || 50
    score += genreAffinity * 0.4

    // Demographic match (30% weight)
    const ageMatch = influencer.demographics.age_groups[targetDemo.age] || 0
    const genderMatch = influencer.demographics.gender[targetDemo.gender] || 0
    const locationMatch = influencer.demographics.locations[targetDemo.location] || 0
    const demoScore = (ageMatch + genderMatch + locationMatch) / 3
    score += demoScore * 0.3

    // Performance metrics (20% weight)
    const performanceScore = (influencer.engagement_rate + influencer.past_performance.average_roi / 10) / 2
    score += performanceScore * 0.2

    // Authenticity and reliability (10% weight)
    const trustScore = (influencer.authenticity_score + influencer.past_performance.reliability_score) / 2
    score += trustScore * 0.1

    return score
  }

  updateInfluencerRelationship(influencerId: string, studioId: string, campaignSuccess: number): void {
    const influencer = this.getInfluencerById(influencerId)
    if (influencer) {
      const currentRelationship = influencer.relationships.studio_history[studioId] || 50
      const relationshipChange = (campaignSuccess - 50) * 0.2 // -10 to +10 change
      influencer.relationships.studio_history[studioId] = Math.max(
        0,
        Math.min(100, currentRelationship + relationshipChange),
      )
    }
  }
}
