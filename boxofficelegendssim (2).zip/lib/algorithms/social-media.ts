export interface SocialMediaPost {
  id: string
  platform: "Twitter" | "TikTok" | "Instagram" | "YouTube"
  content: string
  likes: number
  comments: number
  shares: number
  timestamp: Date
  sentiment: "positive" | "negative" | "neutral"
  viralityScore: number
}

export interface SocialMediaFactors {
  movieBuzz: number
  actorPopularity: number
  plotLeaks: boolean
  scandals: number
  fanTheories: number
  memeGeneration: number
}

export class SocialMediaAlgorithm {
  private postTemplates = {
    positive: [
      "Just watched {movie} and WOW! {actor} was incredible! 🔥",
      "{movie} is a masterpiece! Can't stop thinking about that ending 🤯",
      "The cinematography in {movie} is absolutely stunning! Must watch! ✨",
      "{actor} deserves an Oscar for {movie}! What a performance! 🏆",
    ],
    negative: [
      "Really disappointed by {movie}. Expected so much more 😞",
      "Why did they cast {actor} in {movie}? Completely wrong choice",
      "{movie} was a waste of 2 hours. Save your money folks 💸",
      "The plot of {movie} makes no sense. What were they thinking? 🤦",
    ],
    neutral: [
      "Watched {movie} last night. {actor} was decent, nothing special",
      "{movie} has some good moments but overall pretty average",
      "Mixed feelings about {movie}. Some parts great, others not so much",
      "If you're a fan of {genre}, you might enjoy {movie}",
    ],
  }

  generateSocialMediaPosts(
    movieTitle: string,
    actorName: string,
    genre: string,
    factors: SocialMediaFactors,
    count = 5,
  ): SocialMediaPost[] {
    const posts: SocialMediaPost[] = []

    for (let i = 0; i < count; i++) {
      const post = this.generateSinglePost(movieTitle, actorName, genre, factors)
      posts.push(post)
    }

    return posts.sort((a, b) => b.viralityScore - a.viralityScore)
  }

  private generateSinglePost(
    movieTitle: string,
    actorName: string,
    genre: string,
    factors: SocialMediaFactors,
  ): SocialMediaPost {
    const sentiment = this.determineSentiment(factors)
    const platform = this.selectPlatform(factors)
    const template = this.selectTemplate(sentiment)

    const content = template.replace("{movie}", movieTitle).replace("{actor}", actorName).replace("{genre}", genre)

    const viralityScore = this.calculateViralityScore(sentiment, factors, platform)
    const engagement = this.generateEngagement(viralityScore, platform)

    return {
      id: Math.random().toString(36).substr(2, 9),
      platform,
      content,
      likes: engagement.likes,
      comments: engagement.comments,
      shares: engagement.shares,
      timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000), // Random time in last week
      sentiment,
      viralityScore,
    }
  }

  private determineSentiment(factors: SocialMediaFactors): "positive" | "negative" | "neutral" {
    let sentimentScore = factors.movieBuzz + factors.actorPopularity - factors.scandals * 20

    if (factors.plotLeaks) sentimentScore -= 15
    sentimentScore += factors.fanTheories * 5
    sentimentScore += factors.memeGeneration * 10

    if (sentimentScore > 70) return "positive"
    if (sentimentScore < 40) return "negative"
    return "neutral"
  }

  private selectPlatform(factors: SocialMediaFactors): "Twitter" | "TikTok" | "Instagram" | "YouTube" {
    const platforms: Array<"Twitter" | "TikTok" | "Instagram" | "YouTube"> = [
      "Twitter",
      "TikTok",
      "Instagram",
      "YouTube",
    ]
    const weights = [0.3, 0.3, 0.25, 0.15] // Twitter and TikTok more likely

    // Adjust weights based on factors
    if (factors.memeGeneration > 70) {
      weights[1] += 0.2 // TikTok boost for memes
      weights[0] -= 0.1
    }

    if (factors.fanTheories > 60) {
      weights[0] += 0.15 // Twitter boost for theories
      weights[3] += 0.1 // YouTube boost for analysis
    }

    const random = Math.random()
    let cumulative = 0

    for (let i = 0; i < platforms.length; i++) {
      cumulative += weights[i]
      if (random < cumulative) return platforms[i]
    }

    return "Twitter"
  }

  private selectTemplate(sentiment: "positive" | "negative" | "neutral"): string {
    const templates = this.postTemplates[sentiment]
    return templates[Math.floor(Math.random() * templates.length)]
  }

  private calculateViralityScore(
    sentiment: "positive" | "negative" | "neutral",
    factors: SocialMediaFactors,
    platform: string,
  ): number {
    let baseScore = factors.movieBuzz + factors.actorPopularity

    // Sentiment multipliers
    if (sentiment === "positive") baseScore *= 1.2
    if (sentiment === "negative") baseScore *= 1.1 // Controversy can go viral too
    if (sentiment === "neutral") baseScore *= 0.8

    // Platform multipliers
    if (platform === "TikTok") baseScore *= 1.3 // TikTok has higher viral potential
    if (platform === "Twitter") baseScore *= 1.1

    // Factor bonuses
    if (factors.plotLeaks) baseScore += 30
    if (factors.scandals > 0) baseScore += factors.scandals * 15
    baseScore += factors.memeGeneration * 2
    baseScore += factors.fanTheories * 1.5

    return Math.max(0, Math.min(100, baseScore))
  }

  private generateEngagement(
    viralityScore: number,
    platform: string,
  ): {
    likes: number
    comments: number
    shares: number
  } {
    const baseEngagement = Math.floor(viralityScore * 100)

    // Platform-specific engagement patterns
    let likesMultiplier = 1
    let commentsMultiplier = 0.1
    let sharesMultiplier = 0.05

    switch (platform) {
      case "TikTok":
        likesMultiplier = 2
        commentsMultiplier = 0.15
        sharesMultiplier = 0.1
        break
      case "Instagram":
        likesMultiplier = 1.5
        commentsMultiplier = 0.08
        sharesMultiplier = 0.03
        break
      case "YouTube":
        likesMultiplier = 0.8
        commentsMultiplier = 0.2
        sharesMultiplier = 0.02
        break
    }

    return {
      likes: Math.floor(baseEngagement * likesMultiplier * (0.8 + Math.random() * 0.4)),
      comments: Math.floor(baseEngagement * commentsMultiplier * (0.8 + Math.random() * 0.4)),
      shares: Math.floor(baseEngagement * sharesMultiplier * (0.8 + Math.random() * 0.4)),
    }
  }

  calculateTrendDecay(currentBuzz: number, daysElapsed: number): number {
    // Exponential decay with half-life of about 7 days
    const decayRate = 0.1
    return currentBuzz * Math.exp(-decayRate * daysElapsed)
  }

  generateMemeChallenge(movieTitle: string, viralityThreshold: number): string | null {
    if (Math.random() * 100 < viralityThreshold) {
      const challenges = [
        `#${movieTitle.replace(/\s+/g, "")}Challenge`,
        `#${movieTitle.replace(/\s+/g, "")}Dance`,
        `#${movieTitle.replace(/\s+/g, "")}Reaction`,
        `#Recreate${movieTitle.replace(/\s+/g, "")}Scene`,
      ]
      return challenges[Math.floor(Math.random() * challenges.length)]
    }
    return null
  }
}
