export interface MovieData {
  id: string
  title: string
  genre: string
  budget: number
  scriptQuality: number // 1-100
  directorSkill: number // 1-100
  castFame: number // 1-100
  castTalent: number // 1-100
  castSynergy: number // 1-100
  marketingBudget: number
  releaseWeek: number
  releaseYear: number
  awards: number
  scandals: number
}

export interface MarketConditions {
  genreTrends: Record<string, number> // genre -> popularity (1-100)
  competition: MovieData[]
  socialBuzz: number // 1-100
  criticalReviews: number // 1-100
}

export class MovieSuccessAlgorithm {
  calculateMovieSuccess(movie: MovieData, market: MarketConditions): number {
    // Base quality score (40% weight)
    const qualityScore = this.calculateQualityScore(movie)

    // Market conditions (30% weight)
    const marketScore = this.calculateMarketScore(movie, market)

    // External factors (30% weight)
    const externalScore = this.calculateExternalScore(movie, market)

    const totalScore = qualityScore * 0.4 + marketScore * 0.3 + externalScore * 0.3

    // Add randomness factor (±10%)
    const randomFactor = 0.9 + Math.random() * 0.2

    return Math.max(0, Math.min(100, totalScore * randomFactor))
  }

  private calculateQualityScore(movie: MovieData): number {
    const budgetEfficiency = this.calculateBudgetEfficiency(movie.budget)
    const talentScore = (movie.directorSkill + movie.castTalent + movie.castSynergy) / 3

    return movie.scriptQuality * 0.4 + talentScore * 0.4 + budgetEfficiency * 0.2
  }

  private calculateMarketScore(movie: MovieData, market: MarketConditions): number {
    const genrePopularity = market.genreTrends[movie.genre] || 50
    const competitionFactor = this.calculateCompetitionFactor(movie, market.competition)
    const marketingEffectiveness = this.calculateMarketingEffectiveness(movie.marketingBudget, movie.budget)

    return genrePopularity * 0.4 + competitionFactor * 0.3 + marketingEffectiveness * 0.3
  }

  private calculateExternalScore(movie: MovieData, market: MarketConditions): number {
    const socialBuzzBonus = market.socialBuzz > 70 ? 20 : market.socialBuzz > 40 ? 10 : 0
    const criticalBonus = market.criticalReviews > 80 ? 25 : market.criticalReviews > 60 ? 15 : 0
    const awardBonus = movie.awards * 5
    const scandalPenalty = movie.scandals * 10

    return Math.max(0, 50 + socialBuzzBonus + criticalBonus + awardBonus - scandalPenalty)
  }

  private calculateBudgetEfficiency(budget: number): number {
    // Sweet spot around $15-50M for optimal efficiency
    if (budget < 1000000) return 30 // Too low
    if (budget < 5000000) return 60 // Low budget
    if (budget < 15000000) return 80 // Indie sweet spot
    if (budget < 50000000) return 95 // Major studio sweet spot
    if (budget < 100000000) return 85 // High budget
    if (budget < 200000000) return 70 // Very high budget
    return 50 // Excessive budget
  }

  private calculateCompetitionFactor(movie: MovieData, competition: MovieData[]): number {
    const sameWeekCompetitors = competition.filter(
      (c) => c.releaseWeek === movie.releaseWeek && c.releaseYear === movie.releaseYear,
    )

    const sameGenreCompetitors = sameWeekCompetitors.filter((c) => c.genre === movie.genre)

    let competitionScore = 100
    competitionScore -= sameWeekCompetitors.length * 15
    competitionScore -= sameGenreCompetitors.length * 25

    return Math.max(20, competitionScore)
  }

  private calculateMarketingEffectiveness(marketingBudget: number, productionBudget: number): number {
    const marketingRatio = marketingBudget / productionBudget

    if (marketingRatio < 0.1) return 30 // Under-marketed
    if (marketingRatio < 0.3) return 70 // Adequate marketing
    if (marketingRatio < 0.5) return 90 // Good marketing
    if (marketingRatio < 0.8) return 95 // Excellent marketing
    return 85 // Over-marketed (diminishing returns)
  }
}
