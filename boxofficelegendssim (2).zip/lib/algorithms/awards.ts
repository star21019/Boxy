export interface AwardCategory {
  id: string
  name: string
  weight: number // Importance of category
  criteria: {
    scriptQuality: number
    acting: number
    direction: number
    technical: number
    popularity: number
  }
}

export interface AwardShow {
  id: string
  name: string
  prestige: number // 1-100
  categories: AwardCategory[]
  votingBias: {
    studioSize: number // Preference for major vs indie
    genrePreference: Record<string, number>
    politicalCorrectness: number
  }
}

export interface Nomination {
  movieId: string
  categoryId: string
  probability: number
  campaignEffort: number
  bribeAmount?: number
}

export interface MovieData {
  id: string
  title: string
  genre: string
  scriptQuality: number
  castTalent: number
  directorSkill: number
  budget: number
  castFame: number
}

export class AwardsAlgorithm {
  private awardShows: AwardShow[] = [
    {
      id: "oscars",
      name: "Academy Awards",
      prestige: 100,
      categories: [
        {
          id: "best_picture",
          name: "Best Picture",
          weight: 1.0,
          criteria: { scriptQuality: 0.3, acting: 0.2, direction: 0.3, technical: 0.1, popularity: 0.1 },
        },
        {
          id: "best_actor",
          name: "Best Actor",
          weight: 0.8,
          criteria: { scriptQuality: 0.1, acting: 0.7, direction: 0.1, technical: 0.0, popularity: 0.1 },
        },
        {
          id: "best_director",
          name: "Best Director",
          weight: 0.9,
          criteria: { scriptQuality: 0.2, acting: 0.1, direction: 0.6, technical: 0.1, popularity: 0.0 },
        },
      ],
      votingBias: {
        studioSize: 0.2, // Slight preference for major studios
        genrePreference: { Drama: 0.3, Biography: 0.2, Action: -0.1, Comedy: -0.05 },
        politicalCorrectness: 0.15,
      },
    },
    {
      id: "golden_globes",
      name: "Golden Globe Awards",
      prestige: 75,
      categories: [
        {
          id: "best_motion_picture_drama",
          name: "Best Motion Picture - Drama",
          weight: 0.9,
          criteria: { scriptQuality: 0.25, acting: 0.25, direction: 0.25, technical: 0.1, popularity: 0.15 },
        },
      ],
      votingBias: {
        studioSize: 0.3, // More preference for major studios
        genrePreference: { Drama: 0.2, Musical: 0.15, Comedy: 0.1 },
        politicalCorrectness: 0.1,
      },
    },
  ]

  calculateNominationProbability(
    movie: MovieData,
    category: AwardCategory,
    awardShow: AwardShow,
    competition: MovieData[],
  ): number {
    // Base score from movie quality
    const qualityScore = this.calculateCategoryScore(movie, category)

    // Competition factor
    const competitionScore = this.calculateCompetitionFactor(movie, competition, category)

    // Bias adjustments
    const biasScore = this.calculateBiasScore(movie, awardShow)

    // Campaign and external factors
    const campaignBonus = this.calculateCampaignBonus(movie)

    const totalScore = qualityScore * 0.5 + competitionScore * 0.3 + biasScore * 0.1 + campaignBonus * 0.1

    return Math.max(0, Math.min(100, totalScore))
  }

  private calculateCategoryScore(movie: MovieData, category: AwardCategory): number {
    const criteria = category.criteria

    let score = 0
    score += movie.scriptQuality * criteria.scriptQuality
    score += movie.castTalent * criteria.acting
    score += movie.directorSkill * criteria.direction
    score += this.calculateTechnicalScore(movie) * criteria.technical
    score += this.calculatePopularityScore(movie) * criteria.popularity

    return score
  }

  private calculateTechnicalScore(movie: MovieData): number {
    // Technical score based on budget efficiency and genre
    const budgetFactor = Math.min(100, movie.budget / 1000000) // Higher budget = better technical
    const genreTechnicalBonus = this.getGenreTechnicalBonus(movie.genre)

    return Math.min(100, budgetFactor + genreTechnicalBonus)
  }

  private getGenreTechnicalBonus(genre: string): number {
    const bonuses: Record<string, number> = {
      "Sci-Fi": 20,
      Action: 15,
      Fantasy: 18,
      Animation: 25,
      Horror: 10,
      Drama: 5,
      Comedy: 5,
      Romance: 3,
    }
    return bonuses[genre] || 0
  }

  private calculatePopularityScore(movie: MovieData): number {
    // Popularity based on cast fame and box office potential
    return (movie.castFame + this.estimateBoxOfficeAppeal(movie)) / 2
  }

  private estimateBoxOfficeAppeal(movie: MovieData): number {
    // Simplified box office appeal calculation
    const genreAppeal = this.getGenreBoxOfficeAppeal(movie.genre)
    const budgetAppeal = Math.min(80, movie.budget / 2000000) // Diminishing returns

    return (genreAppeal + budgetAppeal) / 2
  }

  private getGenreBoxOfficeAppeal(genre: string): number {
    const appeals: Record<string, number> = {
      Action: 85,
      "Sci-Fi": 80,
      Comedy: 75,
      Horror: 70,
      Animation: 85,
      Drama: 50,
      Romance: 60,
      Thriller: 70,
    }
    return appeals[genre] || 60
  }

  private calculateCompetitionFactor(movie: MovieData, competition: MovieData[], category: AwardCategory): number {
    // Sort competition by category score
    const competitorScores = competition
      .filter((m) => m.id !== movie.id)
      .map((m) => this.calculateCategoryScore(m, category))
      .sort((a, b) => b - a)

    const movieScore = this.calculateCategoryScore(movie, category)

    // Calculate percentile ranking
    const betterCompetitors = competitorScores.filter((score) => score > movieScore).length
    const totalCompetitors = competitorScores.length

    if (totalCompetitors === 0) return 100

    const percentile = ((totalCompetitors - betterCompetitors) / totalCompetitors) * 100

    return percentile
  }

  private calculateBiasScore(movie: MovieData, awardShow: AwardShow): number {
    let biasScore = 50 // Neutral starting point

    // Studio size bias
    const isIndieStudio = movie.budget < 20000000
    if (isIndieStudio) {
      biasScore += awardShow.votingBias.studioSize * -50 // Penalty for indie
    } else {
      biasScore += awardShow.votingBias.studioSize * 50 // Bonus for major studio
    }

    // Genre preference
    const genreBonus = awardShow.votingBias.genrePreference[movie.genre] || 0
    biasScore += genreBonus * 100

    // Political correctness (simplified)
    const pcScore = this.calculatePoliticalCorrectnessScore(movie)
    biasScore += pcScore * awardShow.votingBias.politicalCorrectness

    return Math.max(0, Math.min(100, biasScore))
  }

  private calculatePoliticalCorrectnessScore(movie: MovieData): number {
    // Simplified PC score - in real game would be more complex
    // Based on cast diversity, themes, etc.
    return 50 + (Math.random() - 0.5) * 40 // Random for now
  }

  private calculateCampaignBonus(movie: MovieData): number {
    // Campaign effectiveness based on studio reputation and spending
    const campaignBudget = movie.budget * 0.1 // Assume 10% of budget for campaign
    const campaignEffectiveness = Math.min(50, campaignBudget / 1000000) // Diminishing returns

    return campaignEffectiveness
  }

  simulateAwardCeremony(nominations: Nomination[], awardShow: AwardShow): Record<string, string> {
    const winners: Record<string, string> = {}

    // Group nominations by category
    const categorizedNominations = nominations.reduce(
      (acc, nom) => {
        if (!acc[nom.categoryId]) acc[nom.categoryId] = []
        acc[nom.categoryId].push(nom)
        return acc
      },
      {} as Record<string, Nomination[]>,
    )

    // Select winner for each category
    Object.entries(categorizedNominations).forEach(([categoryId, noms]) => {
      const winner = this.selectWinner(noms, awardShow)
      if (winner) {
        winners[categoryId] = winner.movieId
      }
    })

    return winners
  }

  private selectWinner(nominations: Nomination[], awardShow: AwardShow): Nomination | null {
    if (nominations.length === 0) return null

    // Calculate weighted probabilities including bribes
    const weightedNominations = nominations.map((nom) => {
      let weight = nom.probability

      // Bribe bonus (risky but effective)
      if (nom.bribeAmount) {
        const bribeBonus = Math.min(30, nom.bribeAmount / 1000000) // Max 30% bonus
        weight += bribeBonus

        // Risk of exposure
        const exposureRisk = nom.bribeAmount / 10000000 // Higher bribes = higher risk
        if (Math.random() < exposureRisk) {
          // Bribe exposed! Massive penalty
          weight = 0
          // In real game, would trigger scandal
        }
      }

      return { ...nom, adjustedWeight: weight }
    })

    // Weighted random selection
    const totalWeight = weightedNominations.reduce((sum, nom) => sum + nom.adjustedWeight, 0)
    if (totalWeight === 0) return nominations[0] // Fallback

    let random = Math.random() * totalWeight
    for (const nom of weightedNominations) {
      random -= nom.adjustedWeight
      if (random <= 0) return nom
    }

    return nominations[0] // Fallback
  }

  calculateAwardImpact(
    awardWins: Record<string, number>,
    awardShow: AwardShow,
  ): {
    reputationBonus: number
    boxOfficeBonus: number
    futureNominationBonus: number
  } {
    const totalWins = Object.values(awardWins).reduce((sum, count) => sum + count, 0)
    const prestigeMultiplier = awardShow.prestige / 100

    return {
      reputationBonus: totalWins * 10 * prestigeMultiplier,
      boxOfficeBonus: totalWins * 0.15 * prestigeMultiplier, // 15% boost per win
      futureNominationBonus: totalWins * 5 * prestigeMultiplier,
    }
  }
}
