export interface BoxOfficeFactors {
  movieSuccess: number
  hypeLevel: number
  genreSaturation: number
  countryDemand: Record<string, number>
  fanbasePower: number
  criticalReviews: number
  isStreaming: boolean
  wordOfMouth: number
  week: number // Week since release
}

export class BoxOfficeAlgorithm {
  calculateWeeklyRevenue(budget: number, factors: BoxOfficeFactors, previousWeekRevenue?: number): number {
    const baseRevenue = this.calculateBaseRevenue(budget, factors)
    const weeklyMultiplier = this.getWeeklyMultiplier(factors.week)
    const wordOfMouthEffect = this.calculateWordOfMouthEffect(factors.wordOfMouth, factors.week)

    let weeklyRevenue = baseRevenue * weeklyMultiplier * wordOfMouthEffect

    // Apply streaming penalty
    if (factors.isStreaming) {
      weeklyRevenue *= 0.3 // Streaming reduces box office significantly
    }

    // Apply country-specific multipliers
    const globalMultiplier = this.calculateGlobalMultiplier(factors.countryDemand)
    weeklyRevenue *= globalMultiplier

    return Math.max(0, weeklyRevenue)
  }

  private calculateBaseRevenue(budget: number, factors: BoxOfficeFactors): number {
    // Base potential is typically 2-4x budget for successful films
    const successMultiplier = factors.movieSuccess / 100
    const hypeMultiplier = factors.hypeLevel / 100
    const fanbaseMultiplier = factors.fanbasePower / 100
    const criticalMultiplier = factors.criticalReviews / 100

    const baseMultiplier = (successMultiplier + hypeMultiplier + fanbaseMultiplier + criticalMultiplier) / 4

    // Genre saturation penalty
    const saturationPenalty = Math.max(0.5, 1 - factors.genreSaturation / 100)

    return budget * baseMultiplier * 3 * saturationPenalty
  }

  private getWeeklyMultiplier(week: number): number {
    // Typical box office decay pattern
    switch (week) {
      case 1:
        return 0.4 // Opening weekend
      case 2:
        return 0.25 // Second weekend
      case 3:
        return 0.15 // Third weekend
      case 4:
        return 0.1 // Fourth weekend
      case 5:
        return 0.05 // Fifth weekend
      default:
        return Math.max(0.01, 0.05 - (week - 5) * 0.005)
    }
  }

  private calculateWordOfMouthEffect(wordOfMouth: number, week: number): number {
    // Word of mouth becomes more important over time
    const baseEffect = wordOfMouth / 100
    const weekMultiplier = Math.min(2, 1 + (week - 1) * 0.1)

    return 0.7 + baseEffect * 0.6 * weekMultiplier
  }

  private calculateGlobalMultiplier(countryDemand: Record<string, number>): number {
    const countries = Object.keys(countryDemand)
    const totalDemand = countries.reduce((sum, country) => sum + countryDemand[country], 0)
    const averageDemand = totalDemand / countries.length

    return 0.5 + averageDemand / 100
  }

  calculateTotalBoxOffice(budget: number, factors: BoxOfficeFactors, totalWeeks = 12): number {
    let totalRevenue = 0
    const currentFactors = { ...factors }

    for (let week = 1; week <= totalWeeks; week++) {
      currentFactors.week = week
      // Word of mouth evolves based on success
      if (week > 1) {
        currentFactors.wordOfMouth = this.updateWordOfMouth(currentFactors.wordOfMouth, currentFactors.movieSuccess)
      }

      const weeklyRevenue = this.calculateWeeklyRevenue(budget, currentFactors)
      totalRevenue += weeklyRevenue

      // Break early if revenue becomes negligible
      if (weeklyRevenue < budget * 0.001) break
    }

    return totalRevenue
  }

  private updateWordOfMouth(currentWordOfMouth: number, movieSuccess: number): number {
    // Word of mouth converges toward movie quality over time
    const convergenceRate = 0.1
    const target = movieSuccess

    return currentWordOfMouth + (target - currentWordOfMouth) * convergenceRate
  }
}
