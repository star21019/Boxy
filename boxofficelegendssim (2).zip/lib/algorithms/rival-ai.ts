export interface MovieData {
  id: string
  title: string
  genre: string
  budget: number
  scriptQuality: number
  directorSkill: number
  castFame: number
  castTalent: number
  castSynergy: number
  marketingBudget: number
  releaseWeek: number
  releaseYear: number
  awards: number
  scandals: number
}

export interface MarketConditions {
  genreTrends: Record<string, number>
  competition: MovieData[]
}

export interface RivalStudio {
  id: string
  name: string
  type: "Major" | "Indie" | "Streaming"
  reputation: number
  money: number
  personality: {
    aggression: number // 0-100, how likely to compete directly
    innovation: number // 0-100, how likely to try new genres/ideas
    riskTolerance: number // 0-100, willingness to take big budget risks
    marketFollowing: number // 0-100, how much they follow trends vs set them
  }
  preferences: {
    favoriteGenres: string[]
    targetBudgetRange: [number, number]
    preferredReleaseSeasons: string[]
  }
  currentProjects: MovieData[]
  pastSuccesses: MovieData[]
  relationships: Record<string, number> // Actor/Director ID -> relationship score
}

export class RivalAIAlgorithm {
  private seasonMultipliers = {
    Spring: { Romance: 1.2, Comedy: 1.1, Drama: 1.0 },
    Summer: { Action: 1.3, "Sci-Fi": 1.2, Comedy: 1.1 },
    Fall: { Drama: 1.2, Thriller: 1.1, Horror: 1.3 },
    Winter: { Drama: 1.1, Romance: 1.0, Family: 1.2 },
  }

  planProduction(
    studio: RivalStudio,
    marketConditions: MarketConditions,
    playerActions: MovieData[],
    currentWeek: number,
  ): MovieData | null {
    // Analyze market and player behavior
    const marketAnalysis = this.analyzeMarket(marketConditions, playerActions)

    // Decide whether to produce based on studio personality
    if (!this.shouldProduce(studio, marketAnalysis, currentWeek)) {
      return null
    }

    // Select genre based on trends and personality
    const selectedGenre = this.selectGenre(studio, marketAnalysis, playerActions)

    // Determine budget based on studio type and risk tolerance
    const budget = this.determineBudget(studio, selectedGenre, marketAnalysis)

    // Select release timing
    const releaseWeek = this.selectReleaseWeek(studio, marketAnalysis, currentWeek)

    // Generate movie concept
    return this.generateMovieConcept(studio, selectedGenre, budget, releaseWeek)
  }

  private analyzeMarket(
    marketConditions: MarketConditions,
    playerActions: MovieData[],
  ): {
    trendingGenres: string[]
    oversaturatedGenres: string[]
    playerFocusGenres: string[]
    competitionLevel: number
  } {
    // Find trending genres
    const trendingGenres = Object.entries(marketConditions.genreTrends)
      .filter(([_, popularity]) => popularity > 70)
      .map(([genre, _]) => genre)

    // Find oversaturated genres
    const oversaturatedGenres = Object.entries(marketConditions.genreTrends)
      .filter(([_, popularity]) => popularity < 30)
      .map(([genre, _]) => genre)

    // Analyze player focus
    const playerGenres = playerActions.map((movie) => movie.genre)
    const playerFocusGenres = [...new Set(playerGenres)]

    // Calculate overall competition level
    const competitionLevel = marketConditions.competition.length

    return {
      trendingGenres,
      oversaturatedGenres,
      playerFocusGenres,
      competitionLevel,
    }
  }

  private shouldProduce(studio: RivalStudio, marketAnalysis: any, currentWeek: number): boolean {
    // Base production probability
    let productionProbability = 0.3

    // Adjust based on studio type
    if (studio.type === "Major") productionProbability += 0.2
    if (studio.type === "Streaming") productionProbability += 0.3

    // Adjust based on market conditions
    if (marketAnalysis.competitionLevel < 3) productionProbability += 0.2
    if (marketAnalysis.trendingGenres.length > 0) productionProbability += 0.1

    // Adjust based on studio finances
    if (studio.money > 100000000) productionProbability += 0.2
    if (studio.money < 20000000) productionProbability -= 0.3

    // Seasonal adjustments
    const season = this.getCurrentSeason(currentWeek)
    if (studio.preferences.preferredReleaseSeasons.includes(season)) {
      productionProbability += 0.15
    }

    return Math.random() < productionProbability
  }

  private selectGenre(studio: RivalStudio, marketAnalysis: any, playerActions: MovieData[]): string {
    const genreScores: Record<string, number> = {}

    // Initialize with studio preferences
    studio.preferences.favoriteGenres.forEach((genre) => {
      genreScores[genre] = 50 + studio.personality.marketFollowing * 0.3
    })

    // Add all possible genres
    const allGenres = ["Action", "Drama", "Comedy", "Sci-Fi", "Horror", "Romance", "Thriller", "Animation"]
    allGenres.forEach((genre) => {
      if (!genreScores[genre]) genreScores[genre] = 30
    })

    // Adjust based on market trends
    marketAnalysis.trendingGenres.forEach((genre: string) => {
      genreScores[genre] += studio.personality.marketFollowing * 0.4
    })

    // Penalize oversaturated genres
    marketAnalysis.oversaturatedGenres.forEach((genre: string) => {
      genreScores[genre] -= 30
    })

    // Counter-programming: avoid player's focus if aggressive
    if (studio.personality.aggression > 70) {
      marketAnalysis.playerFocusGenres.forEach((genre: string) => {
        genreScores[genre] -= 20
      })
    } else if (studio.personality.aggression > 40) {
      // Direct competition: target player's genres
      marketAnalysis.playerFocusGenres.forEach((genre: string) => {
        genreScores[genre] += 15
      })
    }

    // Innovation bonus for unexplored genres
    if (studio.personality.innovation > 60) {
      const unexploredGenres = allGenres.filter((genre) => !studio.pastSuccesses.some((movie) => movie.genre === genre))
      unexploredGenres.forEach((genre) => {
        genreScores[genre] += studio.personality.innovation * 0.2
      })
    }

    // Select genre using weighted random
    return this.weightedRandomSelect(genreScores)
  }

  private determineBudget(studio: RivalStudio, genre: string, marketAnalysis: any): number {
    const [minBudget, maxBudget] = studio.preferences.targetBudgetRange

    // Base budget within studio's range
    let budget = minBudget + (maxBudget - minBudget) * Math.random()

    // Genre-specific adjustments
    const genreBudgetMultipliers: Record<string, number> = {
      Action: 1.5,
      "Sci-Fi": 1.4,
      Animation: 1.3,
      Fantasy: 1.3,
      Drama: 0.8,
      Horror: 0.7,
      Comedy: 0.9,
      Romance: 0.8,
    }

    budget *= genreBudgetMultipliers[genre] || 1.0

    // Risk tolerance adjustment
    const riskMultiplier = 0.7 + (studio.personality.riskTolerance / 100) * 0.6
    budget *= riskMultiplier

    // Market competition adjustment
    if (marketAnalysis.competitionLevel > 5) {
      budget *= 1.2 // Increase budget to compete
    }

    // Ensure budget doesn't exceed studio's money
    budget = Math.min(budget, studio.money * 0.8)

    return Math.max(1000000, budget) // Minimum 1M budget
  }

  private selectReleaseWeek(studio: RivalStudio, marketAnalysis: any, currentWeek: number): number {
    // Production time based on budget and studio efficiency
    const productionWeeks = 12 + Math.random() * 8 // 12-20 weeks
    let targetWeek = currentWeek + productionWeeks

    // Adjust for preferred seasons
    const preferredSeasons = studio.preferences.preferredReleaseSeasons
    if (preferredSeasons.length > 0) {
      const seasonWeeks = this.getSeasonWeeks(preferredSeasons[0])
      // Find closest preferred season week
      const closestSeasonWeek = seasonWeeks.reduce((closest, week) => {
        return Math.abs(week - targetWeek) < Math.abs(closest - targetWeek) ? week : closest
      })

      // Adjust target week towards preferred season (with some flexibility)
      targetWeek += (closestSeasonWeek - targetWeek) * 0.5
    }

    // Avoid direct competition if not aggressive
    if (studio.personality.aggression < 50) {
      const competitorWeeks = marketAnalysis.competition?.map((m: MovieData) => m.releaseWeek) || []
      while (competitorWeeks.includes(Math.floor(targetWeek))) {
        targetWeek += 1
      }
    }

    return Math.max(1, Math.min(52, Math.floor(targetWeek)))
  }

  private generateMovieConcept(studio: RivalStudio, genre: string, budget: number, releaseWeek: number): MovieData {
    const titlePrefixes = ["The", "Dark", "Last", "Secret", "Hidden", "Lost", "Final", "Ultimate"]
    const titleSuffixes = ["Legacy", "Rising", "Chronicles", "Awakening", "Revolution", "Destiny", "Origins"]

    const title = `${titlePrefixes[Math.floor(Math.random() * titlePrefixes.length)]} ${titleSuffixes[Math.floor(Math.random() * titleSuffixes.length)]}`

    // Generate quality scores based on studio reputation and budget
    const baseQuality = 30 + (studio.reputation / 100) * 40
    const budgetBonus = Math.min(20, budget / 10000000) // Budget helps quality

    return {
      id: Math.random().toString(36).substr(2, 9),
      title,
      genre,
      budget,
      scriptQuality: Math.max(1, Math.min(100, baseQuality + budgetBonus + (Math.random() - 0.5) * 20)),
      directorSkill: Math.max(1, Math.min(100, baseQuality + (Math.random() - 0.5) * 30)),
      castFame: Math.max(1, Math.min(100, baseQuality + budgetBonus * 0.5 + (Math.random() - 0.5) * 25)),
      castTalent: Math.max(1, Math.min(100, baseQuality + (Math.random() - 0.5) * 25)),
      castSynergy: Math.max(1, Math.min(100, 50 + (Math.random() - 0.5) * 40)),
      marketingBudget: budget * (0.2 + Math.random() * 0.3), // 20-50% of budget
      releaseWeek,
      releaseYear: 2024, // Current year
      awards: 0,
      scandals: Math.random() < 0.1 ? 1 : 0, // 10% chance of scandal
    }
  }

  private getCurrentSeason(week: number): string {
    if (week >= 1 && week <= 13) return "Winter"
    if (week >= 14 && week <= 26) return "Spring"
    if (week >= 27 && week <= 39) return "Summer"
    return "Fall"
  }

  private getSeasonWeeks(season: string): number[] {
    switch (season) {
      case "Winter":
        return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
      case "Spring":
        return [14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26]
      case "Summer":
        return [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
      case "Fall":
        return [40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52]
      default:
        return [1]
    }
  }

  private weightedRandomSelect(scores: Record<string, number>): string {
    const items = Object.entries(scores)
    const totalWeight = items.reduce((sum, [_, score]) => sum + Math.max(0, score), 0)

    if (totalWeight === 0) return items[0][0] // Fallback

    let random = Math.random() * totalWeight
    for (const [item, score] of items) {
      random -= Math.max(0, score)
      if (random <= 0) return item
    }

    return items[0][0] // Fallback
  }

  // Sabotage actions
  attemptSabotage(
    attackerStudio: RivalStudio,
    targetStudio: string, // Player studio
    targetMovie: MovieData,
  ): {
    success: boolean
    action: string
    impact: number
    riskOfExposure: number
  } {
    if (attackerStudio.personality.aggression < 60) {
      return { success: false, action: "none", impact: 0, riskOfExposure: 0 }
    }

    const sabotageActions = [
      { action: "leak_script", impact: 15, risk: 0.3 },
      { action: "poach_actor", impact: 25, risk: 0.4 },
      { action: "spread_rumors", impact: 10, risk: 0.2 },
      { action: "schedule_conflict", impact: 20, risk: 0.5 },
    ]

    const selectedAction = sabotageActions[Math.floor(Math.random() * sabotageActions.length)]
    const successChance = 0.3 + (attackerStudio.personality.aggression / 100) * 0.4

    return {
      success: Math.random() < successChance,
      action: selectedAction.action,
      impact: selectedAction.impact,
      riskOfExposure: selectedAction.risk,
    }
  }
}
