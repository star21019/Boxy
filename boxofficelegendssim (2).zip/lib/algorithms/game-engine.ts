import { MovieSuccessAlgorithm, type MovieData, type MarketConditions } from "./movie-success"
import { BoxOfficeAlgorithm, type BoxOfficeFactors } from "./box-office"
import { SocialMediaAlgorithm, type SocialMediaFactors } from "./social-media"
import { AwardsAlgorithm } from "./awards"
import { RivalAIAlgorithm, type RivalStudio } from "./rival-ai"

export interface GameState {
  currentWeek: number
  currentYear: number
  playerStudio: {
    name: string
    type: "Indie" | "Major" | "Streaming"
    reputation: number
    money: number
    level: number
  }
  movies: MovieData[]
  rivalStudios: RivalStudio[]
  marketConditions: MarketConditions
  upcomingEvents: GameEvent[]
}

export interface GameEvent {
  id: string
  type: "award_show" | "industry_strike" | "scandal" | "trend_shift" | "festival"
  week: number
  year: number
  description: string
  impact: Record<string, number>
}

export class GameEngine {
  private movieSuccessAlgorithm = new MovieSuccessAlgorithm()
  private boxOfficeAlgorithm = new BoxOfficeAlgorithm()
  private socialMediaAlgorithm = new SocialMediaAlgorithm()
  private awardsAlgorithm = new AwardsAlgorithm()
  private rivalAIAlgorithm = new RivalAIAlgorithm()

  advanceWeek(gameState: GameState): GameState {
    const newState = { ...gameState }

    // Advance time
    newState.currentWeek += 1
    if (newState.currentWeek > 52) {
      newState.currentWeek = 1
      newState.currentYear += 1
    }

    // Process weekly events
    this.processWeeklyEvents(newState)

    // Update box office for released movies
    this.updateBoxOffice(newState)

    // Update social media buzz
    this.updateSocialMedia(newState)

    // Process rival AI actions
    this.processRivalActions(newState)

    // Update market conditions
    this.updateMarketConditions(newState)

    // Check for random events
    this.checkRandomEvents(newState)

    // Update player studio stats
    this.updatePlayerStudio(newState)

    return newState
  }

  private processWeeklyEvents(gameState: GameState): void {
    const currentEvents = gameState.upcomingEvents.filter(
      (event) => event.week === gameState.currentWeek && event.year === gameState.currentYear,
    )

    currentEvents.forEach((event) => {
      this.processEvent(event, gameState)
    })

    // Remove processed events
    gameState.upcomingEvents = gameState.upcomingEvents.filter(
      (event) => !(event.week === gameState.currentWeek && event.year === gameState.currentYear),
    )
  }

  private processEvent(event: GameEvent, gameState: GameState): void {
    switch (event.type) {
      case "award_show":
        this.processAwardShow(event, gameState)
        break
      case "industry_strike":
        this.processIndustryStrike(event, gameState)
        break
      case "scandal":
        this.processScandal(event, gameState)
        break
      case "trend_shift":
        this.processTrendShift(event, gameState)
        break
    }
  }

  private updateBoxOffice(gameState: GameState): void {
    gameState.movies.forEach((movie) => {
      if (movie.releaseWeek <= gameState.currentWeek && movie.releaseYear <= gameState.currentYear) {
        const weeksSinceRelease = this.calculateWeeksSinceRelease(
          movie.releaseWeek,
          movie.releaseYear,
          gameState.currentWeek,
          gameState.currentYear,
        )

        if (weeksSinceRelease <= 12) {
          // Movies earn for 12 weeks
          const boxOfficeFactors: BoxOfficeFactors = {
            movieSuccess: this.movieSuccessAlgorithm.calculateMovieSuccess(movie, gameState.marketConditions),
            hypeLevel: this.calculateHypeLevel(movie, gameState),
            genreSaturation: this.calculateGenreSaturation(movie.genre, gameState),
            countryDemand: { USA: 80, International: 70 }, // Simplified
            fanbasePower: movie.castFame,
            criticalReviews: movie.scriptQuality,
            isStreaming: false, // Simplified
            wordOfMouth: this.calculateWordOfMouth(movie, gameState),
            week: weeksSinceRelease,
          }

          const weeklyRevenue = this.boxOfficeAlgorithm.calculateWeeklyRevenue(movie.budget, boxOfficeFactors)

          movie.boxOffice = (movie.boxOffice || 0) + weeklyRevenue
          gameState.playerStudio.money += weeklyRevenue * 0.5 // Studio gets 50% of box office
        }
      }
    })
  }

  private updateSocialMedia(gameState: GameState): void {
    gameState.movies.forEach((movie) => {
      const socialFactors: SocialMediaFactors = {
        movieBuzz: this.calculateMovieBuzz(movie, gameState),
        actorPopularity: movie.castFame,
        plotLeaks: Math.random() < 0.05, // 5% chance of leaks
        scandals: movie.scandals,
        fanTheories: Math.random() * 100,
        memeGeneration: this.calculateMemeGeneration(movie),
      }

      // Generate new social media posts
      const newPosts = this.socialMediaAlgorithm.generateSocialMediaPosts(
        movie.title,
        "Lead Actor", // Simplified
        movie.genre,
        socialFactors,
        2, // Generate 2 posts per movie per week
      )

      // In a real implementation, these would be stored and displayed
    })
  }

  private processRivalActions(gameState: GameState): void {
    gameState.rivalStudios.forEach((rival) => {
      // Each rival has a chance to start a new project
      const newProject = this.rivalAIAlgorithm.planProduction(
        rival,
        gameState.marketConditions,
        gameState.movies,
        gameState.currentWeek,
      )

      if (newProject) {
        rival.currentProjects.push(newProject)
        rival.money -= newProject.budget
      }

      // Process ongoing projects
      rival.currentProjects.forEach((project) => {
        if (project.releaseWeek <= gameState.currentWeek && project.releaseYear <= gameState.currentYear) {
          // Movie is released, calculate its success
          const success = this.movieSuccessAlgorithm.calculateMovieSuccess(project, gameState.marketConditions)

          // Update rival studio stats
          rival.reputation += success > 70 ? 5 : success > 40 ? 0 : -2
          rival.reputation = Math.max(0, Math.min(100, rival.reputation))

          // Move to past successes
          rival.pastSuccesses.push(project)
        }
      })

      // Remove completed projects
      rival.currentProjects = rival.currentProjects.filter(
        (project) => project.releaseWeek > gameState.currentWeek || project.releaseYear > gameState.currentYear,
      )

      // Attempt sabotage (if aggressive)
      if (rival.personality.aggression > 70 && Math.random() < 0.1) {
        const targetMovie = gameState.movies.find(
          (m) =>
            m.releaseWeek > gameState.currentWeek ||
            (m.releaseWeek === gameState.currentWeek && m.releaseYear >= gameState.currentYear),
        )

        if (targetMovie) {
          const sabotageResult = this.rivalAIAlgorithm.attemptSabotage(rival, gameState.playerStudio.name, targetMovie)

          if (sabotageResult.success) {
            // Apply sabotage effects
            this.applySabotageEffects(targetMovie, sabotageResult, gameState)
          }
        }
      }
    })
  }

  private updateMarketConditions(gameState: GameState): void {
    // Slowly evolve genre trends
    Object.keys(gameState.marketConditions.genreTrends).forEach((genre) => {
      const currentTrend = gameState.marketConditions.genreTrends[genre]
      const trendChange = (Math.random() - 0.5) * 5 // ±2.5 points per week
      gameState.marketConditions.genreTrends[genre] = Math.max(0, Math.min(100, currentTrend + trendChange))
    })

    // Update competition list
    gameState.marketConditions.competition = [
      ...gameState.movies,
      ...gameState.rivalStudios.flatMap((rival) => rival.currentProjects),
    ]
  }

  private checkRandomEvents(gameState: GameState): void {
    // 5% chance of random event each week
    if (Math.random() < 0.05) {
      const randomEvent = this.generateRandomEvent(gameState)
      gameState.upcomingEvents.push(randomEvent)
    }
  }

  private updatePlayerStudio(gameState: GameState): void {
    // Calculate weekly expenses
    const weeklyExpenses = this.calculateWeeklyExpenses(gameState)
    gameState.playerStudio.money -= weeklyExpenses

    // Update reputation based on recent movie performance
    const recentMovies = gameState.movies.filter((movie) => {
      const weeksSinceRelease = this.calculateWeeksSinceRelease(
        movie.releaseWeek,
        movie.releaseYear,
        gameState.currentWeek,
        gameState.currentYear,
      )
      return weeksSinceRelease >= 0 && weeksSinceRelease <= 4 // Movies released in last 4 weeks
    })

    if (recentMovies.length > 0) {
      const avgSuccess =
        recentMovies.reduce((sum, movie) => {
          return sum + this.movieSuccessAlgorithm.calculateMovieSuccess(movie, gameState.marketConditions)
        }, 0) / recentMovies.length

      const reputationChange = avgSuccess > 70 ? 2 : avgSuccess > 40 ? 0 : -1
      gameState.playerStudio.reputation += reputationChange
      gameState.playerStudio.reputation = Math.max(0, Math.min(100, gameState.playerStudio.reputation))
    }

    // Level up based on reputation and money
    const newLevel = Math.floor((gameState.playerStudio.reputation + gameState.playerStudio.money / 10000000) / 20)
    gameState.playerStudio.level = Math.max(gameState.playerStudio.level, newLevel)
  }

  // Helper methods
  private calculateWeeksSinceRelease(
    releaseWeek: number,
    releaseYear: number,
    currentWeek: number,
    currentYear: number,
  ): number {
    const yearDiff = currentYear - releaseYear
    return yearDiff * 52 + (currentWeek - releaseWeek)
  }

  private calculateHypeLevel(movie: MovieData, gameState: GameState): number {
    // Simplified hype calculation
    return (movie.castFame + movie.directorSkill) / 2
  }

  private calculateGenreSaturation(genre: string, gameState: GameState): number {
    const recentMoviesInGenre = gameState.marketConditions.competition.filter((m) => m.genre === genre).length
    return Math.min(100, recentMoviesInGenre * 20)
  }

  private calculateWordOfMouth(movie: MovieData, gameState: GameState): number {
    return (movie.scriptQuality + movie.castTalent) / 2
  }

  private calculateMovieBuzz(movie: MovieData, gameState: GameState): number {
    const weeksSinceRelease = this.calculateWeeksSinceRelease(
      movie.releaseWeek,
      movie.releaseYear,
      gameState.currentWeek,
      gameState.currentYear,
    )

    if (weeksSinceRelease < 0) {
      // Pre-release buzz
      return movie.castFame + (movie.marketingBudget / movie.budget) * 50
    } else {
      // Post-release buzz decays
      const initialBuzz = movie.castFame + movie.scriptQuality
      return initialBuzz * Math.exp(-weeksSinceRelease * 0.1)
    }
  }

  private calculateMemeGeneration(movie: MovieData): number {
    // Certain genres more likely to generate memes
    const memeMultipliers: Record<string, number> = {
      Comedy: 1.5,
      Action: 1.2,
      "Sci-Fi": 1.3,
      Horror: 1.1,
      Drama: 0.7,
    }

    return ((movie.castFame + movie.scriptQuality) / 2) * (memeMultipliers[movie.genre] || 1.0)
  }

  private calculateWeeklyExpenses(gameState: GameState): number {
    // Base studio operating costs
    let expenses = 100000 // $100k base weekly cost

    // Scale with studio size
    if (gameState.playerStudio.type === "Major") expenses *= 5
    if (gameState.playerStudio.type === "Streaming") expenses *= 3

    // Add ongoing production costs
    const ongoingProductions = gameState.movies.filter(
      (movie) => movie.releaseWeek > gameState.currentWeek || movie.releaseYear > gameState.currentYear,
    )

    expenses += ongoingProductions.reduce((sum, movie) => sum + movie.budget * 0.02, 0) // 2% of budget per week

    return expenses
  }

  private generateRandomEvent(gameState: GameState): GameEvent {
    const eventTypes = ["scandal", "trend_shift", "industry_strike", "festival"]
    const eventType = eventTypes[Math.floor(Math.random() * eventTypes.length)] as GameEvent["type"]

    return {
      id: Math.random().toString(36).substr(2, 9),
      type: eventType,
      week: gameState.currentWeek + Math.floor(Math.random() * 8) + 1, // 1-8 weeks from now
      year: gameState.currentYear,
      description: this.generateEventDescription(eventType),
      impact: this.generateEventImpact(eventType),
    }
  }

  private generateEventDescription(eventType: GameEvent["type"]): string {
    const descriptions = {
      scandal: "Celebrity scandal rocks the industry",
      trend_shift: "Audience preferences shift dramatically",
      industry_strike: "Writers and actors go on strike",
      festival: "Major film festival announces lineup",
    }
    return descriptions[eventType] || "Unknown event"
  }

  private generateEventImpact(eventType: GameEvent["type"]): Record<string, number> {
    switch (eventType) {
      case "scandal":
        return { reputation: -10, socialBuzz: 20 }
      case "trend_shift":
        return { genreTrends: 30 }
      case "industry_strike":
        return { productionCosts: 50, releaseDelays: 4 }
      case "festival":
        return { reputation: 5, awardChances: 15 }
      default:
        return {}
    }
  }

  private processAwardShow(event: GameEvent, gameState: GameState): void {
    // Simplified award show processing
    const eligibleMovies = gameState.movies.filter((movie) => {
      const weeksSinceRelease = this.calculateWeeksSinceRelease(
        movie.releaseWeek,
        movie.releaseYear,
        gameState.currentWeek,
        gameState.currentYear,
      )
      return weeksSinceRelease >= 4 && weeksSinceRelease <= 52 // Released 4-52 weeks ago
    })

    // Award some movies
    eligibleMovies.forEach((movie) => {
      if (Math.random() < 0.1) {
        // 10% chance of winning an award
        movie.awards += 1
        gameState.playerStudio.reputation += 10
        gameState.playerStudio.money += 5000000 // Award bonus
      }
    })
  }

  private processIndustryStrike(event: GameEvent, gameState: GameState): void {
    // Delay all movies in production
    gameState.movies.forEach((movie) => {
      if (movie.releaseWeek > gameState.currentWeek) {
        movie.releaseWeek += event.impact.releaseDelays || 4
        if (movie.releaseWeek > 52) {
          movie.releaseWeek -= 52
          movie.releaseYear += 1
        }
      }
    })

    // Increase production costs
    gameState.movies.forEach((movie) => {
      if (movie.releaseWeek > gameState.currentWeek) {
        movie.budget *= 1 + (event.impact.productionCosts || 0) / 100
      }
    })
  }

  private processScandal(event: GameEvent, gameState: GameState): void {
    // Random movie gets scandal
    const activeMovies = gameState.movies.filter(
      (movie) => movie.releaseWeek >= gameState.currentWeek - 4 && movie.releaseWeek <= gameState.currentWeek + 8,
    )

    if (activeMovies.length > 0) {
      const targetMovie = activeMovies[Math.floor(Math.random() * activeMovies.length)]
      targetMovie.scandals += 1
      gameState.playerStudio.reputation += event.impact.reputation || -10
    }
  }

  private processTrendShift(event: GameEvent, gameState: GameState): void {
    // Randomly boost or reduce genre trends
    const genres = Object.keys(gameState.marketConditions.genreTrends)
    const affectedGenre = genres[Math.floor(Math.random() * genres.length)]

    const trendChange = (Math.random() - 0.5) * (event.impact.genreTrends || 60)
    gameState.marketConditions.genreTrends[affectedGenre] = Math.max(
      0,
      Math.min(100, gameState.marketConditions.genreTrends[affectedGenre] + trendChange),
    )
  }

  private applySabotageEffects(targetMovie: MovieData, sabotageResult: any, gameState: GameState): void {
    switch (sabotageResult.action) {
      case "leak_script":
        targetMovie.scriptQuality -= sabotageResult.impact
        break
      case "poach_actor":
        targetMovie.castFame -= sabotageResult.impact
        targetMovie.castTalent -= sabotageResult.impact
        break
      case "spread_rumors":
        targetMovie.scandals += 1
        break
      case "schedule_conflict":
        targetMovie.releaseWeek += 2
        if (targetMovie.releaseWeek > 52) {
          targetMovie.releaseWeek -= 52
          targetMovie.releaseYear += 1
        }
        break
    }

    // Clamp values
    targetMovie.scriptQuality = Math.max(1, targetMovie.scriptQuality)
    targetMovie.castFame = Math.max(1, targetMovie.castFame)
    targetMovie.castTalent = Math.max(1, targetMovie.castTalent)
  }

  // Game ending conditions
  checkGameEndConditions(gameState: GameState): {
    isGameOver: boolean
    endingType: "bankruptcy" | "victory" | "scandal" | null
    message: string
  } {
    // Bankruptcy
    if (gameState.playerStudio.money < -10000000) {
      return {
        isGameOver: true,
        endingType: "bankruptcy",
        message: "Your studio has gone bankrupt! Game Over.",
      }
    }

    // Victory - #1 studio for 10 consecutive weeks
    const isTopStudio = this.isTopStudio(gameState)
    if (isTopStudio && gameState.playerStudio.level >= 20) {
      return {
        isGameOver: true,
        endingType: "victory",
        message: "Congratulations! You've built the most successful studio in Hollywood!",
      }
    }

    // Scandal ending - too many scandals
    const totalScandals = gameState.movies.reduce((sum, movie) => sum + movie.scandals, 0)
    if (totalScandals > 10 && gameState.playerStudio.reputation < 20) {
      return {
        isGameOver: true,
        endingType: "scandal",
        message: "Your studio's reputation is ruined by scandals. Game Over.",
      }
    }

    return {
      isGameOver: false,
      endingType: null,
      message: "",
    }
  }

  private isTopStudio(gameState: GameState): boolean {
    // Compare with rival studios
    const playerScore = gameState.playerStudio.reputation + gameState.playerStudio.money / 10000000

    for (const rival of gameState.rivalStudios) {
      const rivalScore = rival.reputation + rival.money / 10000000
      if (rivalScore > playerScore) return false
    }

    return true
  }

  // Save/Load functionality
  saveGame(gameState: GameState): string {
    return JSON.stringify(gameState)
  }

  loadGame(saveData: string): GameState {
    return JSON.parse(saveData)
  }
}
