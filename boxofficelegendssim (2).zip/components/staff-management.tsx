"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { toast } from "sonner"
import { Users, UserPlus, Star, TrendingUp, DollarSign, GraduationCap, Heart } from "lucide-react"

interface StaffMember {
  id: string
  name: string
  role: string
  skill: number
  salary: number
  experience: number
  morale: number
  specialty: string
  hiredDate: string
}

interface StaffManagementProps {
  studioData: any
  onUpdateStudio: (data: any) => void
}

export function StaffManagement({ studioData, onUpdateStudio }: StaffManagementProps) {
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null)

  const formatMoney = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(1)}K`
    return `$${amount.toLocaleString()}`
  }

  const staff: StaffMember[] = studioData?.staff || [
    {
      id: "staff_1",
      name: "Sarah Johnson",
      role: "Director",
      skill: 85,
      salary: 150000,
      experience: 12,
      morale: 90,
      specialty: "Drama",
      hiredDate: "2023-01-15",
    },
    {
      id: "staff_2",
      name: "Mike Chen",
      role: "Producer",
      skill: 78,
      salary: 120000,
      experience: 8,
      morale: 85,
      specialty: "Action",
      hiredDate: "2023-03-20",
    },
    {
      id: "staff_3",
      name: "Emma Rodriguez",
      role: "Screenwriter",
      skill: 92,
      salary: 90000,
      experience: 15,
      morale: 95,
      specialty: "Comedy",
      hiredDate: "2022-11-10",
    },
    {
      id: "staff_4",
      name: "David Kim",
      role: "Cinematographer",
      skill: 88,
      salary: 110000,
      experience: 10,
      morale: 80,
      specialty: "Sci-Fi",
      hiredDate: "2023-05-05",
    },
  ]

  const promoteStaff = (staffId: string) => {
    const updatedStaff = staff.map((member) => {
      if (member.id === staffId) {
        return {
          ...member,
          skill: Math.min(100, member.skill + 5),
          salary: member.salary * 1.2,
          morale: Math.min(100, member.morale + 10),
        }
      }
      return member
    })

    onUpdateStudio({
      staff: updatedStaff,
    })

    toast.success(`${staff.find((s) => s.id === staffId)?.name} has been promoted!`)
  }

  const trainStaff = (staffId: string) => {
    const trainingCost = 10000

    if (studioData.money < trainingCost) {
      toast.error("Insufficient funds for training!")
      return
    }

    const updatedStaff = staff.map((member) => {
      if (member.id === staffId) {
        return {
          ...member,
          skill: Math.min(100, member.skill + 3),
          experience: member.experience + 1,
        }
      }
      return member
    })

    onUpdateStudio({
      staff: updatedStaff,
      money: studioData.money - trainingCost,
    })

    toast.success(`${staff.find((s) => s.id === staffId)?.name} completed training!`)
  }

  const fireStaff = (staffId: string) => {
    const updatedStaff = staff.filter((member) => member.id !== staffId)

    onUpdateStudio({
      staff: updatedStaff,
    })

    toast.success(`Staff member has been released.`)
  }

  const getSkillColor = (skill: number) => {
    if (skill >= 90) return "text-purple-400"
    if (skill >= 80) return "text-blue-400"
    if (skill >= 70) return "text-green-400"
    if (skill >= 60) return "text-yellow-400"
    return "text-red-400"
  }

  const getMoraleColor = (morale: number) => {
    if (morale >= 90) return "text-green-400"
    if (morale >= 70) return "text-yellow-400"
    return "text-red-400"
  }

  const totalSalaries = staff.reduce((sum, member) => sum + member.salary, 0)
  const averageSkill = staff.length > 0 ? staff.reduce((sum, member) => sum + member.skill, 0) / staff.length : 0
  const averageMorale = staff.length > 0 ? staff.reduce((sum, member) => sum + member.morale, 0) / staff.length : 0

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Staff Management</h2>
        <p className="text-gray-300">Manage your talented team members</p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="staff-list">Staff List</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="hiring">Hiring</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-black/20 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Users className="w-8 h-8 text-blue-400" />
                  <div>
                    <p className="text-sm text-gray-400">Total Staff</p>
                    <p className="text-xl font-bold text-blue-400">{staff.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-8 h-8 text-green-400" />
                  <div>
                    <p className="text-sm text-gray-400">Monthly Salaries</p>
                    <p className="text-xl font-bold text-green-400">{formatMoney(totalSalaries)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-yellow-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Star className="w-8 h-8 text-yellow-400" />
                  <div>
                    <p className="text-sm text-gray-400">Avg Skill</p>
                    <p className="text-xl font-bold text-yellow-400">{averageSkill.toFixed(1)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-purple-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Heart className="w-8 h-8 text-purple-400" />
                  <div>
                    <p className="text-sm text-gray-400">Avg Morale</p>
                    <p className="text-xl font-bold text-purple-400">{averageMorale.toFixed(1)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Team Composition</CardTitle>
                <CardDescription>Breakdown by role</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(
                  staff.reduce((acc: any, member) => {
                    acc[member.role] = (acc[member.role] || 0) + 1
                    return acc
                  }, {}),
                ).map(([role, count]) => (
                  <div key={role} className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-white">{role}</span>
                      <span className="text-gray-400">{count as number} members</span>
                    </div>
                    <Progress value={((count as number) / staff.length) * 100} className="h-2" />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Top Performers</CardTitle>
                <CardDescription>Highest skilled team members</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {staff
                  .sort((a, b) => b.skill - a.skill)
                  .slice(0, 5)
                  .map((member, index) => (
                    <div key={member.id} className="flex items-center gap-3 p-2 bg-white/5 rounded">
                      <div className="w-6 h-6 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center text-white font-bold text-xs">
                        {index + 1}
                      </div>
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-xs">
                          {member.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-white font-medium text-sm">{member.name}</p>
                        <p className="text-gray-400 text-xs">{member.role}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold text-sm ${getSkillColor(member.skill)}`}>{member.skill}</p>
                        <p className="text-xs text-gray-400">Skill</p>
                      </div>
                    </div>
                  ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="staff-list" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {staff.map((member) => (
              <Card key={member.id} className="bg-black/20 border-white/10 hover:border-blue-500/50 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                        {member.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-white text-lg">{member.name}</CardTitle>
                      <CardDescription>{member.role}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Skill Level</p>
                      <div className="flex items-center gap-2">
                        <Progress value={member.skill} className="h-2 flex-1" />
                        <span className={`text-sm font-bold ${getSkillColor(member.skill)}`}>{member.skill}</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Morale</p>
                      <div className="flex items-center gap-2">
                        <Progress value={member.morale} className="h-2 flex-1" />
                        <span className={`text-sm font-bold ${getMoraleColor(member.morale)}`}>{member.morale}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Salary:</span>
                      <span className="text-green-400">{formatMoney(member.salary)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Experience:</span>
                      <span className="text-white">{member.experience} years</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Specialty:</span>
                      <Badge variant="outline" className="text-xs">
                        {member.specialty}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => promoteStaff(member.id)}
                      className="flex-1 bg-green-500 hover:bg-green-600"
                    >
                      <TrendingUp className="w-3 h-3 mr-1" />
                      Promote
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => trainStaff(member.id)} className="flex-1">
                      <GraduationCap className="w-3 h-3 mr-1" />
                      Train
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Performance Metrics</CardTitle>
                <CardDescription>Team productivity and efficiency</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Overall Productivity</span>
                    <span className="text-white">{averageSkill.toFixed(1)}%</span>
                  </div>
                  <Progress value={averageSkill} className="h-3" />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Team Morale</span>
                    <span className="text-white">{averageMorale.toFixed(1)}%</span>
                  </div>
                  <Progress value={averageMorale} className="h-3" />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Experience Level</span>
                    <span className="text-white">
                      {(staff.reduce((sum, s) => sum + s.experience, 0) / staff.length).toFixed(1)} years
                    </span>
                  </div>
                  <Progress
                    value={Math.min(100, (staff.reduce((sum, s) => sum + s.experience, 0) / staff.length) * 5)}
                    className="h-3"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Salary Efficiency</span>
                    <span className="text-white">
                      {((averageSkill / (totalSalaries / staff.length)) * 1000).toFixed(1)}
                    </span>
                  </div>
                  <Progress
                    value={Math.min(100, (averageSkill / (totalSalaries / staff.length)) * 1000)}
                    className="h-3"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Department Analysis</CardTitle>
                <CardDescription>Performance by department</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(
                  staff.reduce((acc: any, member) => {
                    if (!acc[member.role]) {
                      acc[member.role] = { skill: 0, morale: 0, count: 0, salary: 0 }
                    }
                    acc[member.role].skill += member.skill
                    acc[member.role].morale += member.morale
                    acc[member.role].salary += member.salary
                    acc[member.role].count += 1
                    return acc
                  }, {}),
                ).map(([role, data]: [string, any]) => (
                  <div key={role} className="p-3 bg-white/5 rounded border border-white/10">
                    <h4 className="font-semibold text-white mb-2">{role}</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-400">Avg Skill:</span>
                        <span className={`ml-2 font-bold ${getSkillColor(data.skill / data.count)}`}>
                          {(data.skill / data.count).toFixed(1)}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-400">Avg Morale:</span>
                        <span className={`ml-2 font-bold ${getMoraleColor(data.morale / data.count)}`}>
                          {(data.morale / data.count).toFixed(1)}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-400">Members:</span>
                        <span className="ml-2 text-white font-bold">{data.count}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Total Cost:</span>
                        <span className="ml-2 text-green-400 font-bold">{formatMoney(data.salary)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="hiring" className="space-y-6">
          <Card className="bg-black/20 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400">Available Candidates</CardTitle>
              <CardDescription>Talented professionals looking for opportunities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { name: "Alex Thompson", role: "Director", skill: 82, salary: 140000, specialty: "Horror" },
                  { name: "Maria Garcia", role: "Producer", skill: 75, salary: 115000, specialty: "Romance" },
                  { name: "James Wilson", role: "Editor", skill: 88, salary: 95000, specialty: "Action" },
                  { name: "Lisa Chang", role: "Composer", skill: 91, salary: 105000, specialty: "Fantasy" },
                  { name: "Robert Davis", role: "VFX Supervisor", skill: 85, salary: 125000, specialty: "Sci-Fi" },
                  { name: "Anna Petrov", role: "Casting Director", skill: 79, salary: 85000, specialty: "Drama" },
                ].map((candidate, index) => (
                  <Card key={index} className="border-white/10 hover:border-blue-500/50 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-gradient-to-r from-green-500 to-blue-500 text-white">
                            {candidate.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-semibold text-white">{candidate.name}</h4>
                          <p className="text-sm text-gray-400">{candidate.role}</p>
                        </div>
                      </div>

                      <div className="space-y-2 mb-4">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Skill:</span>
                          <span className={`font-bold ${getSkillColor(candidate.skill)}`}>{candidate.skill}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Salary:</span>
                          <span className="text-green-400">{formatMoney(candidate.salary)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Specialty:</span>
                          <Badge variant="outline" className="text-xs">
                            {candidate.specialty}
                          </Badge>
                        </div>
                      </div>

                      <Button
                        className="w-full bg-blue-500 hover:bg-blue-600"
                        onClick={() => {
                          if (studioData.money < candidate.salary * 12) {
                            toast.error("Insufficient funds for annual salary!")
                            return
                          }

                          const newStaff = {
                            id: `staff_${Date.now()}`,
                            name: candidate.name,
                            role: candidate.role,
                            skill: candidate.skill,
                            salary: candidate.salary,
                            experience: Math.floor(Math.random() * 10) + 1,
                            morale: 85 + Math.floor(Math.random() * 15),
                            specialty: candidate.specialty,
                            hiredDate: new Date().toISOString(),
                          }

                          onUpdateStudio({
                            staff: [...staff, newStaff],
                            money: studioData.money - candidate.salary * 12,
                          })

                          toast.success(`${candidate.name} has been hired!`)
                        }}
                      >
                        <UserPlus className="w-4 h-4 mr-2" />
                        Hire ({formatMoney(candidate.salary * 12)}/year)
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
