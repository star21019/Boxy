"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ImageIcon, Sparkles, Download, Share, Save } from "lucide-react"

interface PosterStyle {
  id: string
  name: string
  preview: string
  style: string
  description: string
  genre: string[]
  mood: string
}

interface MoviePoster {
  title: string
  tagline: string
  genre: string
  rating: string
  releaseDate: string
  cast: string[]
  director: string
  studio: string
  style: string
  layout: string
  textColor: string
  accentColor: string
}

export function MoviePosterCreator() {
  const [currentTab, setCurrentTab] = useState("style")
  const [posterData, setPosterData] = useState<MoviePoster>({
    title: "",
    tagline: "",
    genre: "",
    rating: "PG-13",
    releaseDate: "",
    cast: [],
    director: "",
    studio: "",
    style: "",
    layout: "classic",
    textColor: "white",
    accentColor: "gold",
  })

  const posterStyles: PosterStyle[] = [
    {
      id: "blockbuster_action",
      name: "Blockbuster Action",
      preview: "💥",
      style: "bg-gradient-to-b from-orange-600 via-red-600 to-black",
      description: "High-energy explosive design for action films",
      genre: ["Action", "Adventure", "Thriller"],
      mood: "Intense",
    },
    {
      id: "dramatic_portrait",
      name: "Dramatic Portrait",
      preview: "🎭",
      style: "bg-gradient-to-b from-gray-800 via-gray-900 to-black",
      description: "Character-focused design for dramatic films",
      genre: ["Drama", "Biography", "Historical"],
      mood: "Serious",
    },
    {
      id: "romantic_sunset",
      name: "Romantic Sunset",
      preview: "💕",
      style: "bg-gradient-to-br from-pink-400 via-rose-500 to-purple-600",
      description: "Warm and passionate for romantic stories",
      genre: ["Romance", "Comedy", "Musical"],
      mood: "Warm",
    },
    {
      id: "sci_fi_cosmic",
      name: "Sci-Fi Cosmic",
      preview: "🌌",
      style: "bg-gradient-to-b from-indigo-900 via-purple-800 to-black",
      description: "Futuristic space design for sci-fi epics",
      genre: ["Sci-Fi", "Fantasy", "Adventure"],
      mood: "Mysterious",
    },
    {
      id: "horror_nightmare",
      name: "Horror Nightmare",
      preview: "👻",
      style: "bg-gradient-to-b from-red-900 via-black to-gray-900",
      description: "Dark and terrifying for horror films",
      genre: ["Horror", "Thriller", "Supernatural"],
      mood: "Terrifying",
    },
    {
      id: "comedy_bright",
      name: "Comedy Bright",
      preview: "😂",
      style: "bg-gradient-to-br from-yellow-400 via-orange-400 to-red-400",
      description: "Colorful and fun for comedy films",
      genre: ["Comedy", "Family", "Animation"],
      mood: "Playful",
    },
    {
      id: "noir_classic",
      name: "Film Noir Classic",
      preview: "🕵️",
      style: "bg-gradient-to-b from-gray-600 via-gray-800 to-black",
      description: "Classic black and white aesthetic",
      genre: ["Crime", "Mystery", "Thriller"],
      mood: "Mysterious",
    },
    {
      id: "fantasy_magical",
      name: "Fantasy Magical",
      preview: "✨",
      style: "bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-800",
      description: "Enchanting design for fantasy adventures",
      genre: ["Fantasy", "Adventure", "Family"],
      mood: "Magical",
    },
    {
      id: "indie_artistic",
      name: "Indie Artistic",
      preview: "🎨",
      style: "bg-gradient-to-br from-teal-500 via-green-600 to-blue-700",
      description: "Creative and unique for independent films",
      genre: ["Drama", "Independent", "Art"],
      mood: "Artistic",
    },
    {
      id: "western_desert",
      name: "Western Desert",
      preview: "🤠",
      style: "bg-gradient-to-b from-yellow-600 via-orange-700 to-red-800",
      description: "Rugged design for western films",
      genre: ["Western", "Action", "Adventure"],
      mood: "Rugged",
    },
    {
      id: "animated_colorful",
      name: "Animated Colorful",
      preview: "🌈",
      style: "bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500",
      description: "Vibrant and playful for animated features",
      genre: ["Animation", "Family", "Comedy"],
      mood: "Joyful",
    },
    {
      id: "documentary_real",
      name: "Documentary Real",
      preview: "📹",
      style: "bg-gradient-to-b from-blue-800 via-gray-700 to-gray-900",
      description: "Clean and informative for documentaries",
      genre: ["Documentary", "Biography", "Historical"],
      mood: "Informative",
    },
  ]

  const layouts = [
    { id: "classic", name: "Classic", description: "Traditional movie poster layout" },
    { id: "character_focus", name: "Character Focus", description: "Large character image with title" },
    { id: "action_montage", name: "Action Montage", description: "Multiple action scenes combined" },
    { id: "minimalist", name: "Minimalist", description: "Clean and simple design" },
    { id: "split_screen", name: "Split Screen", description: "Divided poster with contrasting elements" },
    { id: "floating_heads", name: "Floating Heads", description: "Cast faces arranged artistically" },
  ]

  const textColors = [
    { id: "white", name: "White", color: "text-white" },
    { id: "black", name: "Black", color: "text-black" },
    { id: "gold", name: "Gold", color: "text-yellow-400" },
    { id: "silver", name: "Silver", color: "text-gray-300" },
    { id: "red", name: "Red", color: "text-red-500" },
    { id: "blue", name: "Blue", color: "text-blue-400" },
  ]

  const accentColors = [
    { id: "gold", name: "Gold", color: "border-yellow-400 text-yellow-400" },
    { id: "silver", name: "Silver", color: "border-gray-300 text-gray-300" },
    { id: "red", name: "Red", color: "border-red-500 text-red-500" },
    { id: "blue", name: "Blue", color: "border-blue-400 text-blue-400" },
    { id: "green", name: "Green", color: "border-green-400 text-green-400" },
    { id: "purple", name: "Purple", color: "border-purple-400 text-purple-400" },
  ]

  const generateTagline = () => {
    const taglines = [
      "The adventure begins",
      "Nothing will ever be the same",
      "Some secrets should stay buried",
      "The truth will set you free",
      "Love conquers all",
      "Justice has a new name",
      "The future is in their hands",
      "Every legend has a beginning",
      "The greatest story ever told",
      "Prepare for the unexpected",
      "Heroes rise when darkness falls",
      "The ultimate battle begins",
      "Destiny awaits",
      "The world will never be the same",
      "Some fights are worth fighting",
    ]
    const randomTagline = taglines[Math.floor(Math.random() * taglines.length)]
    setPosterData({ ...posterData, tagline: randomTagline })
  }

  const selectedStyle = posterStyles.find((style) => style.id === posterData.style)

  return (
    <div className="space-y-6">
      <Card className="bg-black/20 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <ImageIcon className="w-5 h-5" />
            Movie Poster Creator
          </CardTitle>
          <CardDescription className="text-gray-300">
            Design stunning movie posters that capture your film's essence
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Poster Preview */}
        <div className="lg:col-span-1">
          <Card className="bg-black/20 border-blue-500/30 sticky top-4">
            <CardHeader>
              <CardTitle className="text-blue-400">Live Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div
                className={`w-full aspect-[2/3] rounded-lg relative overflow-hidden ${
                  selectedStyle?.style || "bg-gradient-to-b from-gray-800 to-black"
                }`}
              >
                {/* Background overlay */}
                <div className="absolute inset-0 bg-black/30"></div>

                {/* Content */}
                <div className="relative z-10 h-full flex flex-col justify-between p-4">
                  {/* Top section - Studio/Rating */}
                  <div className="flex justify-between items-start">
                    <div
                      className={`text-xs ${textColors.find((c) => c.id === posterData.textColor)?.color || "text-white"}`}
                    >
                      {posterData.studio && <div className="bg-black/50 px-2 py-1 rounded">{posterData.studio}</div>}
                    </div>
                    <div
                      className={`text-xs ${textColors.find((c) => c.id === posterData.textColor)?.color || "text-white"}`}
                    >
                      {posterData.rating && <div className="bg-black/50 px-2 py-1 rounded">{posterData.rating}</div>}
                    </div>
                  </div>

                  {/* Middle section - Main visual area */}
                  <div className="flex-1 flex items-center justify-center">
                    <div className="text-6xl opacity-50">{selectedStyle?.preview || "🎬"}</div>
                  </div>

                  {/* Bottom section - Title and info */}
                  <div className="space-y-2">
                    {posterData.title && (
                      <h1
                        className={`text-2xl font-bold text-center ${
                          textColors.find((c) => c.id === posterData.textColor)?.color || "text-white"
                        }`}
                        style={{ textShadow: "2px 2px 4px rgba(0,0,0,0.8)" }}
                      >
                        {posterData.title}
                      </h1>
                    )}

                    {posterData.tagline && (
                      <p
                        className={`text-sm text-center italic ${
                          textColors.find((c) => c.id === posterData.textColor)?.color || "text-white"
                        } opacity-90`}
                      >
                        "{posterData.tagline}"
                      </p>
                    )}

                    {posterData.cast.length > 0 && (
                      <div
                        className={`text-xs text-center ${
                          textColors.find((c) => c.id === posterData.textColor)?.color || "text-white"
                        } opacity-80`}
                      >
                        Starring {posterData.cast.slice(0, 3).join(" • ")}
                      </div>
                    )}

                    {posterData.director && (
                      <div
                        className={`text-xs text-center ${
                          textColors.find((c) => c.id === posterData.textColor)?.color || "text-white"
                        } opacity-80`}
                      >
                        Directed by {posterData.director}
                      </div>
                    )}

                    {posterData.releaseDate && (
                      <div
                        className={`text-sm text-center font-semibold ${
                          accentColors.find((c) => c.id === posterData.accentColor)?.color || "text-yellow-400"
                        }`}
                      >
                        {posterData.releaseDate}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <Button className="w-full bg-gradient-to-r from-green-500 to-blue-500">
                  <Download className="w-4 h-4 mr-2" />
                  Download Poster
                </Button>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" className="border-purple-500/30">
                    <Share className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                  <Button variant="outline" className="border-blue-500/30">
                    <Save className="w-4 h-4 mr-2" />
                    Save Draft
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Poster Editor */}
        <div className="lg:col-span-2">
          <Tabs value={currentTab} onValueChange={setCurrentTab}>
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="style">Style</TabsTrigger>
              <TabsTrigger value="content">Content</TabsTrigger>
              <TabsTrigger value="layout">Layout</TabsTrigger>
              <TabsTrigger value="colors">Colors</TabsTrigger>
              <TabsTrigger value="export">Export</TabsTrigger>
            </TabsList>

            <TabsContent value="style" className="space-y-4">
              <Card className="bg-black/20 border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-green-400">Choose Poster Style</CardTitle>
                  <CardDescription className="text-gray-300">
                    Select a style that matches your movie's genre and mood
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {posterStyles.map((style) => (
                      <Card
                        key={style.id}
                        className={`cursor-pointer transition-all ${
                          posterData.style === style.id
                            ? "border-green-400 bg-green-500/10"
                            : "border-white/10 hover:border-green-500/50"
                        }`}
                        onClick={() => setPosterData({ ...posterData, style: style.id })}
                      >
                        <CardContent className="p-4 text-center">
                          <div
                            className={`w-full aspect-[2/3] rounded-lg flex items-center justify-center text-3xl ${style.style} mb-3`}
                          >
                            {style.preview}
                          </div>
                          <h4 className="font-semibold text-white text-sm">{style.name}</h4>
                          <p className="text-xs text-gray-400 mt-1">{style.description}</p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {style.genre.slice(0, 2).map((genre) => (
                              <Badge key={genre} variant="outline" className="text-xs">
                                {genre}
                              </Badge>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="content" className="space-y-4">
              <Card className="bg-black/20 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-400">Poster Content</CardTitle>
                  <CardDescription className="text-gray-300">Add text and information to your poster</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Movie Title</label>
                    <Input
                      value={posterData.title}
                      onChange={(e) => setPosterData({ ...posterData, title: e.target.value })}
                      placeholder="Enter movie title..."
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Tagline</label>
                    <div className="flex gap-2">
                      <Input
                        value={posterData.tagline}
                        onChange={(e) => setPosterData({ ...posterData, tagline: e.target.value })}
                        placeholder="Enter catchy tagline..."
                        className="flex-1"
                      />
                      <Button onClick={generateTagline} variant="outline" className="border-blue-500/30">
                        <Sparkles className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-white">Genre</label>
                      <Select
                        value={posterData.genre}
                        onValueChange={(value) => setPosterData({ ...posterData, genre: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Choose genre..." />
                        </SelectTrigger>
                        <SelectContent>
                          {[
                            "Action",
                            "Drama",
                            "Comedy",
                            "Sci-Fi",
                            "Horror",
                            "Romance",
                            "Thriller",
                            "Fantasy",
                            "Animation",
                            "Documentary",
                          ].map((genre) => (
                            <SelectItem key={genre} value={genre}>
                              {genre}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-white">Rating</label>
                      <Select
                        value={posterData.rating}
                        onValueChange={(value) => setPosterData({ ...posterData, rating: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="G">G - General Audiences</SelectItem>
                          <SelectItem value="PG">PG - Parental Guidance</SelectItem>
                          <SelectItem value="PG-13">PG-13 - Parents Strongly Cautioned</SelectItem>
                          <SelectItem value="R">R - Restricted</SelectItem>
                          <SelectItem value="NC-17">NC-17 - Adults Only</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-white">Director</label>
                      <Input
                        value={posterData.director}
                        onChange={(e) => setPosterData({ ...posterData, director: e.target.value })}
                        placeholder="Director name..."
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-white">Studio</label>
                      <Input
                        value={posterData.studio}
                        onChange={(e) => setPosterData({ ...posterData, studio: e.target.value })}
                        placeholder="Studio name..."
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Release Date</label>
                    <Input
                      value={posterData.releaseDate}
                      onChange={(e) => setPosterData({ ...posterData, releaseDate: e.target.value })}
                      placeholder="Coming Soon / Summer 2024 / December 15, 2024"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Cast (one per line)</label>
                    <Textarea
                      value={posterData.cast.join("\n")}
                      onChange={(e) =>
                        setPosterData({ ...posterData, cast: e.target.value.split("\n").filter(Boolean) })
                      }
                      placeholder="Enter cast names, one per line..."
                      rows={4}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="layout" className="space-y-4">
              <Card className="bg-black/20 border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-purple-400">Layout Options</CardTitle>
                  <CardDescription className="text-gray-300">
                    Choose how elements are arranged on your poster
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {layouts.map((layout) => (
                      <Card
                        key={layout.id}
                        className={`cursor-pointer transition-all ${
                          posterData.layout === layout.id
                            ? "border-purple-400 bg-purple-500/10"
                            : "border-white/10 hover:border-purple-500/50"
                        }`}
                        onClick={() => setPosterData({ ...posterData, layout: layout.id })}
                      >
                        <CardContent className="p-4">
                          <h4 className="font-semibold text-white mb-2">{layout.name}</h4>
                          <p className="text-sm text-gray-400">{layout.description}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="colors" className="space-y-4">
              <Card className="bg-black/20 border-yellow-500/30">
                <CardHeader>
                  <CardTitle className="text-yellow-400">Color Scheme</CardTitle>
                  <CardDescription className="text-gray-300">Customize text and accent colors</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-white">Text Color</label>
                    <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                      {textColors.map((color) => (
                        <Button
                          key={color.id}
                          variant={posterData.textColor === color.id ? "default" : "outline"}
                          className={`${color.color} ${posterData.textColor === color.id ? "border-yellow-400" : "border-white/20"}`}
                          onClick={() => setPosterData({ ...posterData, textColor: color.id })}
                        >
                          {color.name}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-sm font-medium text-white">Accent Color</label>
                    <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                      {accentColors.map((color) => (
                        <Button
                          key={color.id}
                          variant={posterData.accentColor === color.id ? "default" : "outline"}
                          className={`${color.color} ${posterData.accentColor === color.id ? "bg-white/10" : ""}`}
                          onClick={() => setPosterData({ ...posterData, accentColor: color.id })}
                        >
                          {color.name}
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="export" className="space-y-4">
              <Card className="bg-black/20 border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-green-400">Export Options</CardTitle>
                  <CardDescription className="text-gray-300">Download and share your poster</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-white/5 rounded-lg">
                      <h4 className="font-semibold text-white mb-2">High Resolution</h4>
                      <p className="text-sm text-gray-400 mb-3">Perfect for printing and professional use</p>
                      <Button className="w-full bg-gradient-to-r from-green-500 to-blue-500">
                        <Download className="w-4 h-4 mr-2" />
                        Download 4K (3840x5760)
                      </Button>
                    </div>

                    <div className="p-4 bg-white/5 rounded-lg">
                      <h4 className="font-semibold text-white mb-2">Social Media</h4>
                      <p className="text-sm text-gray-400 mb-3">Optimized for social platforms</p>
                      <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500">
                        <Share className="w-4 h-4 mr-2" />
                        Share (1080x1620)
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-white">Marketing Impact</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center p-3 bg-white/5 rounded-lg">
                        <div className="text-2xl font-bold text-green-400">8.5/10</div>
                        <div className="text-sm text-gray-400">Visual Appeal</div>
                      </div>
                      <div className="text-center p-3 bg-white/5 rounded-lg">
                        <div className="text-2xl font-bold text-blue-400">92%</div>
                        <div className="text-sm text-gray-400">Genre Match</div>
                      </div>
                      <div className="text-center p-3 bg-white/5 rounded-lg">
                        <div className="text-2xl font-bold text-purple-400">High</div>
                        <div className="text-sm text-gray-400">Market Appeal</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-lg border border-blue-500/30">
                    <h4 className="font-semibold text-white mb-2">Pro Tips</h4>
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• Use high contrast for better readability</li>
                      <li>• Keep taglines short and impactful</li>
                      <li>• Ensure the title is the most prominent element</li>
                      <li>• Consider your target audience when choosing colors</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
