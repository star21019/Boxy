"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { toast } from "sonner"
import { Users, Star, DollarSign, Search, Filter, UserPlus, Briefcase, Heart, Clock, Target } from "lucide-react"

interface StaffMember {
  id: string
  name: string
  role: "Director" | "Writer" | "Producer" | "Actor" | "Cinematographer" | "Editor" | "Composer" | "VFX Artist"
  experience: number
  skill: number
  salary: number
  contract: "Freelance" | "Short-term" | "Long-term" | "Exclusive"
  specialties: string[]
  reputation: number
  availability: boolean
  morale: number
  projects: number
}

interface StaffHiringProps {
  studioData: any
  onUpdateStudio: (data: any) => void
}

const availableStaff: StaffMember[] = [
  {
    id: "dir_001",
    name: "Marcus Chen",
    role: "Director",
    experience: 15,
    skill: 92,
    salary: 2500000,
    contract: "Long-term",
    specialties: ["Action", "Sci-Fi", "Thriller"],
    reputation: 88,
    availability: true,
    morale: 85,
    projects: 23,
  },
  {
    id: "wri_001",
    name: "Sarah Williams",
    role: "Writer",
    experience: 8,
    skill: 85,
    salary: 800000,
    contract: "Freelance",
    specialties: ["Drama", "Romance", "Comedy"],
    reputation: 76,
    availability: true,
    morale: 90,
    projects: 15,
  },
  {
    id: "pro_001",
    name: "David Rodriguez",
    role: "Producer",
    experience: 12,
    skill: 88,
    salary: 1800000,
    contract: "Short-term",
    specialties: ["Budget Management", "Scheduling", "Logistics"],
    reputation: 82,
    availability: true,
    morale: 78,
    projects: 31,
  },
  {
    id: "act_001",
    name: "Emma Thompson",
    role: "Actor",
    experience: 20,
    skill: 95,
    salary: 5000000,
    contract: "Exclusive",
    specialties: ["Drama", "Period Pieces", "Character Acting"],
    reputation: 94,
    availability: false,
    morale: 92,
    projects: 47,
  },
  {
    id: "cin_001",
    name: "Alex Kim",
    role: "Cinematographer",
    experience: 10,
    skill: 87,
    salary: 1200000,
    contract: "Freelance",
    specialties: ["Visual Storytelling", "Lighting", "Camera Work"],
    reputation: 79,
    availability: true,
    morale: 88,
    projects: 19,
  },
  {
    id: "edi_001",
    name: "Lisa Park",
    role: "Editor",
    experience: 7,
    skill: 83,
    salary: 650000,
    contract: "Short-term",
    specialties: ["Pacing", "Color Grading", "Sound Design"],
    reputation: 74,
    availability: true,
    morale: 86,
    projects: 12,
  },
  {
    id: "com_001",
    name: "Michael Foster",
    role: "Composer",
    experience: 14,
    skill: 90,
    salary: 1500000,
    contract: "Long-term",
    specialties: ["Orchestral", "Electronic", "Ambient"],
    reputation: 85,
    availability: true,
    morale: 91,
    projects: 28,
  },
  {
    id: "vfx_001",
    name: "Rachel Green",
    role: "VFX Artist",
    experience: 6,
    skill: 81,
    salary: 900000,
    contract: "Freelance",
    specialties: ["CGI", "Motion Graphics", "Compositing"],
    reputation: 72,
    availability: true,
    morale: 84,
    projects: 14,
  },
]

export function StaffHiring({ studioData, onUpdateStudio }: StaffHiringProps) {
  const [selectedRole, setSelectedRole] = useState<string>("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("skill")
  const [currentStaff, setCurrentStaff] = useState<StaffMember[]>(studioData?.staff || [])

  const formatMoney = (amount: number) => {
    if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(0)}K`
    }
    return `$${amount.toLocaleString()}`
  }

  const getSkillColor = (skill: number) => {
    if (skill >= 90) return "text-purple-400"
    if (skill >= 80) return "text-blue-400"
    if (skill >= 70) return "text-green-400"
    if (skill >= 60) return "text-yellow-400"
    return "text-red-400"
  }

  const getSkillLabel = (skill: number) => {
    if (skill >= 90) return "Elite"
    if (skill >= 80) return "Expert"
    if (skill >= 70) return "Skilled"
    if (skill >= 60) return "Competent"
    return "Novice"
  }

  const filteredStaff = availableStaff
    .filter((staff) => {
      const matchesRole = selectedRole === "all" || staff.role === selectedRole
      const matchesSearch =
        staff.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        staff.specialties.some((s) => s.toLowerCase().includes(searchTerm.toLowerCase()))
      return matchesRole && matchesSearch && staff.availability
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "skill":
          return b.skill - a.skill
        case "salary":
          return a.salary - b.salary
        case "experience":
          return b.experience - a.experience
        case "reputation":
          return b.reputation - a.reputation
        default:
          return 0
      }
    })

  const hireStaff = (staff: StaffMember) => {
    if (studioData.money < staff.salary) {
      toast.error("Insufficient funds to hire this staff member!")
      return
    }

    const newStaff = [...currentStaff, { ...staff, id: `hired_${Date.now()}` }]
    const newMoney = studioData.money - staff.salary
    const reputationBonus = Math.floor(staff.reputation / 10)
    const newReputation = Math.min(100, studioData.reputation + reputationBonus)

    setCurrentStaff(newStaff)
    onUpdateStudio({
      staff: newStaff,
      money: newMoney,
      reputation: newReputation,
    })

    toast.success(`Successfully hired ${staff.name}! Reputation +${reputationBonus}`)
  }

  const fireStaff = (staffId: string) => {
    const newStaff = currentStaff.filter((s) => s.id !== staffId)
    setCurrentStaff(newStaff)
    onUpdateStudio({ staff: newStaff })
    toast.success("Staff member released from contract")
  }

  const getStaffStats = () => {
    const totalStaff = currentStaff.length
    const avgSkill = totalStaff > 0 ? Math.round(currentStaff.reduce((sum, s) => sum + s.skill, 0) / totalStaff) : 0
    const avgMorale = totalStaff > 0 ? Math.round(currentStaff.reduce((sum, s) => sum + s.morale, 0) / totalStaff) : 0
    const monthlyCost = currentStaff.reduce((sum, s) => sum + s.salary * 0.1, 0) // 10% of salary per month

    return { totalStaff, avgSkill, avgMorale, monthlyCost }
  }

  const stats = getStaffStats()

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Staff & Talent Management</h2>
        <p className="text-gray-300">Build your dream team to create amazing content</p>
      </div>

      {/* Studio Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-black/20 border-blue-500/30">
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 mx-auto text-blue-400 mb-2" />
            <div className="text-2xl font-bold text-white">{stats.totalStaff}</div>
            <div className="text-sm text-gray-400">Total Staff</div>
          </CardContent>
        </Card>
        <Card className="bg-black/20 border-green-500/30">
          <CardContent className="p-4 text-center">
            <Star className="w-8 h-8 mx-auto text-green-400 mb-2" />
            <div className="text-2xl font-bold text-white">{stats.avgSkill}</div>
            <div className="text-sm text-gray-400">Avg Skill</div>
          </CardContent>
        </Card>
        <Card className="bg-black/20 border-yellow-500/30">
          <CardContent className="p-4 text-center">
            <Heart className="w-8 h-8 mx-auto text-yellow-400 mb-2" />
            <div className="text-2xl font-bold text-white">{stats.avgMorale}%</div>
            <div className="text-sm text-gray-400">Avg Morale</div>
          </CardContent>
        </Card>
        <Card className="bg-black/20 border-red-500/30">
          <CardContent className="p-4 text-center">
            <DollarSign className="w-8 h-8 mx-auto text-red-400 mb-2" />
            <div className="text-2xl font-bold text-white">{formatMoney(stats.monthlyCost)}</div>
            <div className="text-sm text-gray-400">Monthly Cost</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="hire" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="hire">Hire New Staff</TabsTrigger>
          <TabsTrigger value="manage">Manage Current Staff</TabsTrigger>
        </TabsList>

        <TabsContent value="hire" className="space-y-4">
          {/* Filters */}
          <Card className="bg-black/20 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-purple-400 flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Search & Filter
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Search</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="Name or specialty..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Role</label>
                  <Select value={selectedRole} onValueChange={setSelectedRole}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roles</SelectItem>
                      <SelectItem value="Director">Director</SelectItem>
                      <SelectItem value="Writer">Writer</SelectItem>
                      <SelectItem value="Producer">Producer</SelectItem>
                      <SelectItem value="Actor">Actor</SelectItem>
                      <SelectItem value="Cinematographer">Cinematographer</SelectItem>
                      <SelectItem value="Editor">Editor</SelectItem>
                      <SelectItem value="Composer">Composer</SelectItem>
                      <SelectItem value="VFX Artist">VFX Artist</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Sort By</label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="skill">Skill Level</SelectItem>
                      <SelectItem value="salary">Salary (Low to High)</SelectItem>
                      <SelectItem value="experience">Experience</SelectItem>
                      <SelectItem value="reputation">Reputation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Budget</label>
                  <div className="text-lg font-bold text-green-400">{formatMoney(studioData.money)}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Available Staff */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredStaff.map((staff) => (
              <Card key={staff.id} className="bg-black/20 border-blue-500/30 hover:border-blue-400/50 transition-all">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                          {staff.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-lg font-bold text-white">{staff.name}</h3>
                        <p className="text-sm text-gray-400">{staff.role}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className={getSkillColor(staff.skill)}>
                      {getSkillLabel(staff.skill)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Skills & Stats */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-gray-400">Skill</span>
                        <span className={getSkillColor(staff.skill)}>{staff.skill}/100</span>
                      </div>
                      <Progress value={staff.skill} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-gray-400">Reputation</span>
                        <span className="text-yellow-400">{staff.reputation}/100</span>
                      </div>
                      <Progress value={staff.reputation} className="h-2" />
                    </div>
                  </div>

                  {/* Experience & Projects */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-400" />
                      <span className="text-gray-300">{staff.experience} years exp</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Target className="w-4 h-4 text-green-400" />
                      <span className="text-gray-300">{staff.projects} projects</span>
                    </div>
                  </div>

                  {/* Specialties */}
                  <div>
                    <div className="text-sm text-gray-400 mb-2">Specialties:</div>
                    <div className="flex flex-wrap gap-1">
                      {staff.specialties.map((specialty, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Contract & Salary */}
                  <div className="flex items-center justify-between pt-2 border-t border-gray-700">
                    <div>
                      <div className="text-lg font-bold text-green-400">{formatMoney(staff.salary)}</div>
                      <div className="text-xs text-gray-400">{staff.contract} contract</div>
                    </div>
                    <Button
                      onClick={() => hireStaff(staff)}
                      disabled={studioData.money < staff.salary}
                      className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      Hire
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredStaff.length === 0 && (
            <Card className="bg-black/20 border-gray-500/30">
              <CardContent className="p-8 text-center">
                <Users className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Staff Found</h3>
                <p className="text-gray-400">Try adjusting your search criteria or filters.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="manage" className="space-y-4">
          {currentStaff.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {currentStaff.map((staff) => (
                <Card key={staff.id} className="bg-black/20 border-green-500/30">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-12 h-12">
                          <AvatarFallback className="bg-gradient-to-r from-green-500 to-blue-500 text-white">
                            {staff.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="text-lg font-bold text-white">{staff.name}</h3>
                          <p className="text-sm text-gray-400">{staff.role}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-green-400 border-green-500/50">
                        Hired
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Performance Metrics */}
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-400">Skill</span>
                          <span className={getSkillColor(staff.skill)}>{staff.skill}</span>
                        </div>
                        <Progress value={staff.skill} className="h-1" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-400">Morale</span>
                          <span className="text-yellow-400">{staff.morale}%</span>
                        </div>
                        <Progress value={staff.morale} className="h-1" />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-gray-400">Rep</span>
                          <span className="text-purple-400">{staff.reputation}</span>
                        </div>
                        <Progress value={staff.reputation} className="h-1" />
                      </div>
                    </div>

                    {/* Contract Info */}
                    <div className="flex items-center justify-between pt-2 border-t border-gray-700">
                      <div>
                        <div className="text-sm font-bold text-green-400">{formatMoney(staff.salary * 0.1)}/month</div>
                        <div className="text-xs text-gray-400">{staff.contract}</div>
                      </div>
                      <Button
                        onClick={() => fireStaff(staff.id)}
                        variant="outline"
                        size="sm"
                        className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                      >
                        Release
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-black/20 border-gray-500/30">
              <CardContent className="p-8 text-center">
                <Briefcase className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Staff Hired</h3>
                <p className="text-gray-400 mb-4">Start building your team by hiring talented professionals.</p>
                <Button
                  onClick={() => {
                    const tabsList = document.querySelector('[role="tablist"]')
                    const hireTab = tabsList?.querySelector('[value="hire"]') as HTMLElement
                    hireTab?.click()
                  }}
                  className="bg-gradient-to-r from-blue-500 to-purple-500"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Hire Your First Staff Member
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
