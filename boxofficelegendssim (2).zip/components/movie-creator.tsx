"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { toast } from "sonner"
import {
  Play,
  ChevronRight,
  ChevronLeft,
  Shuffle,
  Plus,
  Trash2,
  User,
  Users,
  Palette,
  Film,
  Type,
  Zap,
} from "lucide-react"
import { movieTitlesByGenre, movieTypes, characterRoles, posterStyles } from "@/lib/movie-data"

interface Character {
  id: string
  name: string
  role: string
  gender: "male" | "female"
  description: string
}

interface MovieCreatorProps {
  studioData: any
  onUpdateStudio: (data: any) => void
}

export function MovieCreator({ studioData, onUpdateStudio }: MovieCreatorProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [movieData, setMovieData] = useState({
    title: "",
    customTitle: false,
    genre: "",
    movieType: "",
    budget: 25000000,
    marketingBudget: 5000000,
    description: "",
    characters: [] as Character[],
    posterStyle: "classic",
    posterColors: ["#1a1a1a", "#ffffff", "#ff0000"],
    posterText: "",
    targetAudience: "teen",
  })

  const genres = [
    { id: "action", name: "Action", icon: "💥", multiplier: 1.2 },
    { id: "comedy", name: "Comedy", icon: "😂", multiplier: 1.0 },
    { id: "drama", name: "Drama", icon: "🎭", multiplier: 0.9 },
    { id: "horror", name: "Horror", icon: "👻", multiplier: 1.5 },
    { id: "romance", name: "Romance", icon: "💕", multiplier: 0.8 },
    { id: "scifi", name: "Sci-Fi", icon: "🚀", multiplier: 1.3 },
    { id: "fantasy", name: "Fantasy", icon: "🧙", multiplier: 1.4 },
    { id: "thriller", name: "Thriller", icon: "🔪", multiplier: 1.1 },
    { id: "animation", name: "Animation", icon: "🎨", multiplier: 1.6 },
    { id: "documentary", name: "Documentary", icon: "📹", multiplier: 0.6 },
  ]

  const targetAudiences = [
    { id: "family", name: "Family (G/PG)", multiplier: 1.3 },
    { id: "teen", name: "Teen (PG-13)", multiplier: 1.2 },
    { id: "adult", name: "Adult (R)", multiplier: 1.0 },
    { id: "mature", name: "Mature (NC-17)", multiplier: 0.7 },
  ]

  const availableDirectors = [
    { id: "dir_1", name: "Marcus Chen", skill: 92, specialty: "Action", cost: 2500000 },
    { id: "dir_2", name: "Sarah Williams", skill: 85, specialty: "Drama", cost: 1800000 },
    { id: "dir_3", name: "David Kim", skill: 88, specialty: "Sci-Fi", cost: 2200000 },
    { id: "dir_4", name: "Emma Rodriguez", skill: 90, specialty: "Comedy", cost: 2000000 },
  ]

  const availableActors = [
    { id: "act_1", name: "Chris Evans", tier: "A-List", cost: 15000000, appeal: 95 },
    { id: "act_2", name: "Zendaya", tier: "A-List", cost: 12000000, appeal: 92 },
    { id: "act_3", name: "Michael B. Jordan", tier: "A-List", cost: 10000000, appeal: 88 },
    { id: "act_4", name: "Emma Stone", tier: "A-List", cost: 8000000, appeal: 90 },
    { id: "act_5", name: "John Boyega", tier: "B-List", cost: 5000000, appeal: 82 },
    { id: "act_6", name: "Anya Taylor-Joy", tier: "B-List", cost: 4000000, appeal: 85 },
    { id: "act_7", name: "LaKeith Stanfield", tier: "B-List", cost: 3000000, appeal: 80 },
    { id: "act_8", name: "Thomasin McKenzie", tier: "C-List", cost: 1500000, appeal: 75 },
  ]

  const generateRandomTitle = () => {
    if (!movieData.genre) return ""
    const titles = movieTitlesByGenre[movieData.genre as keyof typeof movieTitlesByGenre] || []
    return titles[Math.floor(Math.random() * titles.length)]
  }

  const addCharacter = () => {
    const newCharacter: Character = {
      id: `char_${Date.now()}`,
      name: "",
      role: "supporting",
      gender: "male",
      description: "",
    }
    setMovieData({
      ...movieData,
      characters: [...movieData.characters, newCharacter],
    })
  }

  const updateCharacter = (id: string, updates: Partial<Character>) => {
    setMovieData({
      ...movieData,
      characters: movieData.characters.map((char) => (char.id === id ? { ...char, ...updates } : char)),
    })
  }

  const removeCharacter = (id: string) => {
    setMovieData({
      ...movieData,
      characters: movieData.characters.filter((char) => char.id !== id),
    })
  }

  const calculateTotalCost = () => {
    let total = movieData.budget + movieData.marketingBudget

    // Add character costs based on roles
    movieData.characters.forEach((char) => {
      const role = characterRoles.find((r) => r.id === char.role)
      if (role) {
        total += movieData.budget * role.cost * 0.1 // 10% of budget per role multiplier
      }
    })

    return total
  }

  const calculateSuccessPrediction = () => {
    let prediction = 50

    // Genre modifier
    const genre = genres.find((g) => g.id === movieData.genre)
    if (genre) prediction *= genre.multiplier

    // Movie type modifier
    const type = movieTypes.find((t) => t.id === movieData.movieType)
    if (type) prediction *= type.successModifier

    // Character count bonus
    const leadCount = movieData.characters.filter((c) => c.role === "lead").length
    const supportingCount = movieData.characters.filter((c) => c.role === "supporting").length

    if (leadCount >= 1 && leadCount <= 2) prediction += 10
    if (supportingCount >= 2 && supportingCount <= 4) prediction += 5

    // Budget efficiency
    const budgetRatio = movieData.budget / 50000000
    prediction *= Math.min(1.5, 0.8 + budgetRatio * 0.7)

    return Math.min(100, Math.max(10, prediction))
  }

  const formatMoney = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`
    return `$${amount.toLocaleString()}`
  }

  const nextStep = () => {
    if (currentStep < 7) setCurrentStep(currentStep + 1)
  }

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1)
  }

  const createMovie = () => {
    const totalCost = calculateTotalCost()

    if (studioData.money < totalCost) {
      toast.error("Insufficient funds!")
      return
    }

    const newMovie = {
      id: `movie_${Date.now()}`,
      title: movieData.customTitle ? movieData.title : generateRandomTitle(),
      genre: movieData.genre,
      movieType: movieData.movieType,
      budget: movieData.budget,
      marketingBudget: movieData.marketingBudget,
      description: movieData.description,
      characters: movieData.characters,
      posterStyle: movieData.posterStyle,
      posterColors: movieData.posterColors,
      status: "Development",
      successPrediction: calculateSuccessPrediction(),
      createdAt: new Date().toISOString(),
    }

    onUpdateStudio({
      money: studioData.money - totalCost,
      projects: [...(studioData.projects || []), newMovie],
      movies: (studioData.movies || 0) + 1,
      reputation: Math.min(100, studioData.reputation + 2),
    })

    toast.success(`"${newMovie.title}" has entered development!`)

    // Reset form
    setMovieData({
      title: "",
      customTitle: false,
      genre: "",
      movieType: "",
      budget: 25000000,
      marketingBudget: 5000000,
      description: "",
      characters: [],
      posterStyle: "classic",
      posterColors: ["#1a1a1a", "#ffffff", "#ff0000"],
      posterText: "",
      targetAudience: "teen",
    })
    setCurrentStep(1)
  }

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <Card className="bg-black/20 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400 flex items-center gap-2">
                <Type className="w-5 h-5" />
                Step 1: Movie Title & Genre
              </CardTitle>
              <CardDescription>Choose your movie's identity</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <label className="text-sm font-medium text-white mb-2 block">Movie Title</label>
                    <div className="flex gap-2">
                      <Input
                        value={movieData.customTitle ? movieData.title : movieData.genre ? generateRandomTitle() : ""}
                        onChange={(e) => setMovieData({ ...movieData, title: e.target.value, customTitle: true })}
                        placeholder="Enter custom title or use generated..."
                        disabled={!movieData.customTitle && !movieData.genre}
                      />
                      <Button
                        variant="outline"
                        onClick={() => {
                          if (movieData.genre) {
                            setMovieData({ ...movieData, title: generateRandomTitle(), customTitle: false })
                          }
                        }}
                        disabled={!movieData.genre}
                      >
                        <Shuffle className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <input
                        type="checkbox"
                        checked={movieData.customTitle}
                        onChange={(e) => setMovieData({ ...movieData, customTitle: e.target.checked })}
                        className="rounded"
                      />
                      <label className="text-sm text-gray-400">Use custom title</label>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-white mb-3 block">Genre</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {genres.map((genre) => (
                      <Card
                        key={genre.id}
                        className={`cursor-pointer transition-all ${
                          movieData.genre === genre.id
                            ? "border-blue-400 bg-blue-500/10"
                            : "border-white/10 hover:border-blue-500/50"
                        }`}
                        onClick={() => setMovieData({ ...movieData, genre: genre.id })}
                      >
                        <CardContent className="p-4 text-center">
                          <div className="text-2xl mb-2">{genre.icon}</div>
                          <h3 className="font-semibold text-white text-sm">{genre.name}</h3>
                          <Badge variant="outline" className="text-xs mt-1">
                            {genre.multiplier}x
                          </Badge>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )

      case 2:
        return (
          <Card className="bg-black/20 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-purple-400 flex items-center gap-2">
                <Zap className="w-5 h-5" />
                Step 2: Story Type
              </CardTitle>
              <CardDescription>Choose the narrative structure</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {movieTypes.map((type) => (
                  <Card
                    key={type.id}
                    className={`cursor-pointer transition-all ${
                      movieData.movieType === type.id
                        ? "border-purple-400 bg-purple-500/10"
                        : "border-white/10 hover:border-purple-500/50"
                    }`}
                    onClick={() => setMovieData({ ...movieData, movieType: type.id })}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-white">{type.name}</h3>
                        <div className="flex gap-2">
                          <Badge variant="outline" className="text-green-400">
                            {type.successModifier}x
                          </Badge>
                          <Badge
                            variant="outline"
                            className={`${
                              type.riskLevel === "High"
                                ? "text-red-400"
                                : type.riskLevel === "Medium"
                                  ? "text-yellow-400"
                                  : "text-green-400"
                            }`}
                          >
                            {type.riskLevel}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-sm text-gray-400">{type.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        )

      case 3:
        return (
          <Card className="bg-black/20 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-400">Step 3: Budget Planning</CardTitle>
              <CardDescription>Allocate your resources</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-white">Production Budget</label>
                  <span className="text-green-400 font-bold">{formatMoney(movieData.budget)}</span>
                </div>
                <Slider
                  value={[movieData.budget]}
                  onValueChange={([value]) => setMovieData({ ...movieData, budget: value })}
                  min={1000000}
                  max={200000000}
                  step={1000000}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>$1M</span>
                  <span>$200M</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-medium text-white">Marketing Budget</label>
                  <span className="text-blue-400 font-bold">{formatMoney(movieData.marketingBudget)}</span>
                </div>
                <Slider
                  value={[movieData.marketingBudget]}
                  onValueChange={([value]) => setMovieData({ ...movieData, marketingBudget: value })}
                  min={500000}
                  max={50000000}
                  step={500000}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>$500K</span>
                  <span>$50M</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-white mb-2 block">Description</label>
                <Textarea
                  value={movieData.description}
                  onChange={(e) => setMovieData({ ...movieData, description: e.target.value })}
                  placeholder="Brief plot description..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        )

      case 4:
        return (
          <Card className="bg-black/20 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-yellow-400 flex items-center gap-2">
                <Users className="w-5 h-5" />
                Step 4: Character Creation
              </CardTitle>
              <CardDescription>Design your movie's characters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-white">Characters ({movieData.characters.length})</h3>
                <Button onClick={addCharacter} className="bg-yellow-500 hover:bg-yellow-600">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Character
                </Button>
              </div>

              <div className="space-y-4 max-h-96 overflow-y-auto">
                {movieData.characters.map((character, index) => (
                  <Card key={character.id} className="border-white/10">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-semibold text-white">Character {index + 1}</h4>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeCharacter(character.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-gray-400 mb-1 block">Name</label>
                          <Input
                            value={character.name}
                            onChange={(e) => updateCharacter(character.id, { name: e.target.value })}
                            placeholder="Character name..."
                          />
                        </div>

                        <div>
                          <label className="text-sm text-gray-400 mb-1 block">Role</label>
                          <Select
                            value={character.role}
                            onValueChange={(value) => updateCharacter(character.id, { role: value })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {characterRoles.map((role) => (
                                <SelectItem key={role.id} value={role.id}>
                                  {role.name} - {role.description}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <label className="text-sm text-gray-400 mb-1 block">Gender</label>
                          <Select
                            value={character.gender}
                            onValueChange={(value: "male" | "female") =>
                              updateCharacter(character.id, { gender: value })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="male">Male</SelectItem>
                              <SelectItem value="female">Female</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <label className="text-sm text-gray-400 mb-1 block">Description</label>
                          <Input
                            value={character.description}
                            onChange={(e) => updateCharacter(character.id, { description: e.target.value })}
                            placeholder="Brief description..."
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {movieData.characters.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No characters added yet. Click "Add Character" to start building your cast.</p>
                </div>
              )}
            </CardContent>
          </Card>
        )

      case 5:
        const selectedPosterStyle = posterStyles.find((s) => s.id === movieData.posterStyle) || posterStyles[0]

        return (
          <Card className="bg-black/20 border-pink-500/30">
            <CardHeader>
              <CardTitle className="text-pink-400 flex items-center gap-2">
                <Palette className="w-5 h-5" />
                Step 5: Poster Design
              </CardTitle>
              <CardDescription>Create your movie poster</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-white mb-3 block">Poster Style</label>
                    <div className="grid grid-cols-2 gap-3">
                      {posterStyles.map((style) => (
                        <Card
                          key={style.id}
                          className={`cursor-pointer transition-all ${
                            movieData.posterStyle === style.id
                              ? "border-pink-400 bg-pink-500/10"
                              : "border-white/10 hover:border-pink-500/50"
                          }`}
                          onClick={() =>
                            setMovieData({ ...movieData, posterStyle: style.id, posterColors: style.colors })
                          }
                        >
                          <CardContent className="p-3 text-center">
                            <div className="text-2xl mb-2">{style.preview}</div>
                            <h4 className="font-semibold text-white text-sm">{style.name}</h4>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-white mb-2 block">Poster Text</label>
                    <Input
                      value={movieData.posterText}
                      onChange={(e) => setMovieData({ ...movieData, posterText: e.target.value })}
                      placeholder="Tagline or additional text..."
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-white mb-2 block">Color Scheme</label>
                    <div className="flex gap-2">
                      {selectedPosterStyle.colors.map((color, index) => (
                        <div
                          key={index}
                          className="w-8 h-8 rounded border-2 border-white/20"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-sm font-medium text-white block">Preview</label>
                  <div
                    className="aspect-[2/3] rounded-lg border-2 border-white/20 p-4 flex flex-col justify-between"
                    style={{
                      backgroundColor: selectedPosterStyle.colors[0],
                      color: selectedPosterStyle.colors[1],
                      borderColor: selectedPosterStyle.colors[2],
                    }}
                  >
                    <div className="text-center">
                      <div className="text-lg mb-2">{selectedPosterStyle.preview}</div>
                      <div className="text-xs opacity-75">
                        {genres.find((g) => g.id === movieData.genre)?.name || "Genre"}
                      </div>
                    </div>

                    <div className="text-center">
                      <h3 className="font-bold text-lg mb-2">
                        {movieData.customTitle
                          ? movieData.title
                          : movieData.genre
                            ? generateRandomTitle()
                            : "Movie Title"}
                      </h3>
                      {movieData.posterText && <p className="text-sm opacity-75">{movieData.posterText}</p>}
                    </div>

                    <div className="text-center text-xs opacity-50">{studioData?.name || "Studio"} Pictures</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )

      case 6:
        const totalCost = calculateTotalCost()
        const successPrediction = calculateSuccessPrediction()

        return (
          <Card className="bg-black/20 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-purple-400 flex items-center gap-2">
                <Film className="w-5 h-5" />
                Step 6: Final Review
              </CardTitle>
              <CardDescription>Review your movie before production</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-white mb-2">
                  "
                  {movieData.customTitle ? movieData.title : movieData.genre ? generateRandomTitle() : "Untitled Movie"}
                  "
                </h2>
                <div className="flex justify-center gap-2 mb-4">
                  <Badge variant="outline" className="text-purple-400">
                    {genres.find((g) => g.id === movieData.genre)?.name || "No Genre"}
                  </Badge>
                  <Badge variant="outline" className="text-blue-400">
                    {movieTypes.find((t) => t.id === movieData.movieType)?.name || "No Type"}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Project Details</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Production Budget:</span>
                      <span className="text-green-400">{formatMoney(movieData.budget)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Marketing Budget:</span>
                      <span className="text-blue-400">{formatMoney(movieData.marketingBudget)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Characters:</span>
                      <span className="text-white">{movieData.characters.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Poster Style:</span>
                      <span className="text-white">
                        {posterStyles.find((s) => s.id === movieData.posterStyle)?.name}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Financial Projection</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Cost:</span>
                      <span className="text-red-400">{formatMoney(totalCost)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Studio Budget:</span>
                      <span className="text-green-400">{formatMoney(studioData.money)}</span>
                    </div>
                    <div className="flex justify-between border-t border-gray-600 pt-2">
                      <span className="text-white font-semibold">Remaining:</span>
                      <span
                        className={`font-bold ${studioData.money - totalCost >= 0 ? "text-green-400" : "text-red-400"}`}
                      >
                        {formatMoney(studioData.money - totalCost)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-white/5 rounded-lg border border-purple-500/30">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-semibold text-white">Success Prediction</h3>
                  <span className="text-2xl font-bold text-purple-400">{Math.round(successPrediction)}%</span>
                </div>
                <Progress value={successPrediction} className="h-3 mb-2" />
                <p className="text-sm text-gray-400">Based on genre, type, budget, and characters</p>
              </div>

              {movieData.characters.length > 0 && (
                <div className="p-4 bg-white/5 rounded-lg">
                  <h3 className="text-lg font-semibold text-white mb-3">Cast Overview</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {movieData.characters.map((char, index) => (
                      <div key={char.id} className="flex items-center gap-2 text-sm">
                        <User className="w-4 h-4 text-gray-400" />
                        <span className="text-white">{char.name || `Character ${index + 1}`}</span>
                        <Badge variant="outline" className="text-xs">
                          {characterRoles.find((r) => r.id === char.role)?.name}
                        </Badge>
                        <span className="text-gray-400">({char.gender})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="text-center">
                <Button
                  onClick={createMovie}
                  disabled={studioData.money < totalCost || !movieData.genre || !movieData.movieType}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-lg px-8 py-3"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Start Production
                </Button>
                {studioData.money < totalCost && <p className="text-red-400 text-sm mt-2">Insufficient funds!</p>}
              </div>
            </CardContent>
          </Card>
        )

      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Create Your Next Blockbuster</h2>
        <p className="text-gray-300">Design every aspect of your movie from story to poster</p>
      </div>

      {/* Progress Indicator */}
      <div className="flex justify-center">
        <div className="flex items-center space-x-2">
          {[1, 2, 3, 4, 5, 6].map((step) => (
            <div key={step} className="flex items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  step === currentStep
                    ? "bg-purple-500 text-white"
                    : step < currentStep
                      ? "bg-green-500 text-white"
                      : "bg-gray-600 text-gray-300"
                }`}
              >
                {step}
              </div>
              {step < 6 && <div className={`w-8 h-1 ${step < currentStep ? "bg-green-500" : "bg-gray-600"}`} />}
            </div>
          ))}
        </div>
      </div>

      {/* Step Content */}
      {renderStep()}

      {/* Navigation */}
      <div className="flex justify-between">
        <Button
          onClick={prevStep}
          disabled={currentStep === 1}
          variant="outline"
          className="border-gray-500/30 bg-transparent"
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>
        <Button
          onClick={nextStep}
          disabled={currentStep === 6}
          className="bg-gradient-to-r from-blue-500 to-purple-500"
        >
          Next
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  )
}
