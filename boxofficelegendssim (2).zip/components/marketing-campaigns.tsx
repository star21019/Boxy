"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "sonner"
import { Megaphone, TrendingUp, Clock, DollarSign, Target, Zap } from "lucide-react"
import { marketingCampaigns } from "@/lib/movie-data"

const CAMPAIGNS = [
  { id: "social", name: "Social Media Blitz", cost: 500000, effectiveness: 10 },
  { id: "tv", name: "TV Commercials", cost: 2000000, effectiveness: 20 },
  { id: "celebrity", name: "Celebrity Endorsement", cost: 4000000, effectiveness: 30 },
]

interface MarketingCampaignsProps {
  studioData: any
  onUpdateStudio: (updates: any) => void
}

export function MarketingCampaigns({ studioData, onUpdateStudio }: MarketingCampaignsProps) {
  const [selectedMovie, setSelectedMovie] = useState("")
  const [active, setActive] = useState<string | null>(null)

  const formatMoney = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`
    return `$${amount.toLocaleString()}`
  }

  const availableMovies =
    studioData.projects?.filter(
      (project: any) => project.status === "Post-Production" || project.status === "Marketing",
    ) || []

  const activeCampaigns = studioData.activeCampaigns || []

  const startCampaign = (campaignId: string) => {
    if (!selectedMovie) {
      toast.error("Please select a movie first!")
      return
    }

    const campaign = marketingCampaigns.find((c) => c.id === campaignId)
    const movie = studioData.projects.find((p: any) => p.id === selectedMovie)

    if (!campaign || !movie) return

    if (studioData.money < campaign.cost) {
      toast.error("Insufficient funds for this campaign!")
      return
    }

    // Check if campaign is already running for this movie
    const existingCampaign = activeCampaigns.find(
      (c: any) => c.movieId === selectedMovie && c.campaignId === campaignId,
    )

    if (existingCampaign) {
      toast.error("This campaign is already running for this movie!")
      return
    }

    const newCampaign = {
      id: `campaign_${Date.now()}`,
      movieId: selectedMovie,
      movieTitle: movie.title,
      campaignId,
      name: campaign.name,
      cost: campaign.cost,
      effectiveness: campaign.effectiveness,
      duration: campaign.duration,
      weeksRemaining: campaign.duration,
      startWeek: 1, // This would be current game week
    }

    onUpdateStudio({
      money: studioData.money - campaign.cost,
      activeCampaigns: [...activeCampaigns, newCampaign],
    })

    // Update movie marketing boost
    const updatedProjects = studioData.projects.map((p: any) => {
      if (p.id === selectedMovie) {
        return {
          ...p,
          marketingBoost: (p.marketingBoost || 0) + campaign.effectiveness,
          status: "Marketing",
        }
      }
      return p
    })

    onUpdateStudio({ projects: updatedProjects })

    toast.success(`${campaign.name} campaign started for "${movie.title}"!`)
  }

  const cancelCampaign = (campaignId: string) => {
    const campaign = activeCampaigns.find((c: any) => c.id === campaignId)
    if (campaign) {
      // Refund 50% of remaining cost
      const refund = ((campaign.cost * campaign.weeksRemaining) / campaign.duration) * 0.5

      onUpdateStudio({
        money: studioData.money + refund,
        activeCampaigns: activeCampaigns.filter((c: any) => c.id !== campaignId),
      })

      toast.success(`Campaign cancelled. Refund: ${formatMoney(refund)}`)
    }
  }

  const getTotalMarketingSpend = () => {
    return activeCampaigns.reduce((sum: number, campaign: any) => sum + campaign.cost, 0)
  }

  const getMovieMarketingBoost = (movieId: string) => {
    const movie = studioData.projects?.find((p: any) => p.id === movieId)
    return movie?.marketingBoost || 0
  }

  const launchCampaign = (c: (typeof CAMPAIGNS)[0]) => {
    if (studioData.money < c.cost) return
    setActive(c.id)
    onUpdateStudio({ money: studioData.money - c.cost })
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Marketing Campaigns</h2>
        <p className="text-gray-300">Promote your movies and maximize box office success</p>
      </div>

      <Tabs defaultValue="campaigns" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="campaigns">Available Campaigns</TabsTrigger>
          <TabsTrigger value="active">Active Campaigns</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="campaigns" className="space-y-6">
          {/* Movie Selection */}
          <Card className="bg-black/20 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400">Select Movie to Promote</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {availableMovies.map((movie: any) => (
                  <Card
                    key={movie.id}
                    className={`cursor-pointer transition-all ${
                      selectedMovie === movie.id
                        ? "border-blue-400 bg-blue-500/10"
                        : "border-white/10 hover:border-blue-500/50"
                    }`}
                    onClick={() => setSelectedMovie(movie.id)}
                  >
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-white mb-2">{movie.title}</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Status:</span>
                          <Badge variant="outline">{movie.status}</Badge>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Marketing Boost:</span>
                          <span className="text-green-400">+{getMovieMarketingBoost(movie.id)}%</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Budget:</span>
                          <span className="text-blue-400">{formatMoney(movie.budget)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {availableMovies.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  <Megaphone className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No movies available for marketing.</p>
                  <p className="text-sm">Movies must be in Post-Production or Marketing phase.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Available Campaigns */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {marketingCampaigns.map((campaign) => (
              <Card key={campaign.id} className="bg-black/20 border-white/10">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Megaphone className="w-5 h-5" />
                    {campaign.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Cost:</span>
                      <span className="text-red-400">{formatMoney(campaign.cost)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Effectiveness:</span>
                      <span className="text-green-400">{campaign.effectiveness}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Duration:</span>
                      <span className="text-blue-400">{campaign.duration} weeks</span>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-400">Effectiveness</span>
                      <span className="text-white">{campaign.effectiveness}%</span>
                    </div>
                    <Progress value={campaign.effectiveness} className="h-2" />
                  </div>

                  <Button
                    onClick={() => startCampaign(campaign.id)}
                    disabled={!selectedMovie || studioData.money < campaign.cost}
                    className="w-full bg-purple-500 hover:bg-purple-600"
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    Start Campaign
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* New Campaigns Section */}
          <Card className="bg-black/20 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-400 flex items-center gap-2">
                <Megaphone className="w-5 h-5" />
                New Marketing Campaigns
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {CAMPAIGNS.map((c) => (
                <Card
                  key={c.id}
                  className={`flex items-center justify-between p-4 ${
                    active === c.id ? "border-green-500/60" : "border-white/10"
                  }`}
                >
                  <div>
                    <h3 className="font-semibold text-white">{c.name}</h3>
                    <p className="text-xs text-gray-400">
                      Cost ${c.cost.toLocaleString()} • +{c.effectiveness}% awareness
                    </p>
                  </div>
                  <Button
                    size="sm"
                    disabled={active === c.id || studioData.money < c.cost}
                    onClick={() => launchCampaign(c)}
                  >
                    {active === c.id ? "Running" : "Launch"}
                  </Button>
                </Card>
              ))}
              {active && (
                <p className="text-xs text-green-400">
                  Campaign in progress! You’ll see its effect on your next box-office turn.
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="active" className="space-y-6">
          <Card className="bg-black/20 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-400">Active Marketing Campaigns</CardTitle>
            </CardHeader>
            <CardContent>
              {activeCampaigns.length > 0 ? (
                <div className="space-y-4">
                  {activeCampaigns.map((campaign: any) => (
                    <div key={campaign.id} className="p-4 bg-white/5 rounded border border-green-500/30">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-white">{campaign.name}</h3>
                          <p className="text-sm text-gray-400">for "{campaign.movieTitle}"</p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => cancelCampaign(campaign.id)}
                          className="text-red-400 border-red-400 hover:bg-red-400/10"
                        >
                          Cancel
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="text-center">
                          <DollarSign className="w-6 h-6 text-red-400 mx-auto mb-1" />
                          <p className="text-sm text-gray-400">Cost</p>
                          <p className="font-semibold text-red-400">{formatMoney(campaign.cost)}</p>
                        </div>

                        <div className="text-center">
                          <Target className="w-6 h-6 text-green-400 mx-auto mb-1" />
                          <p className="text-sm text-gray-400">Effectiveness</p>
                          <p className="font-semibold text-green-400">{campaign.effectiveness}%</p>
                        </div>

                        <div className="text-center">
                          <Clock className="w-6 h-6 text-blue-400 mx-auto mb-1" />
                          <p className="text-sm text-gray-400">Weeks Left</p>
                          <p className="font-semibold text-blue-400">{campaign.weeksRemaining}</p>
                        </div>

                        <div className="text-center">
                          <TrendingUp className="w-6 h-6 text-purple-400 mx-auto mb-1" />
                          <p className="text-sm text-gray-400">Progress</p>
                          <p className="font-semibold text-purple-400">
                            {Math.round(((campaign.duration - campaign.weeksRemaining) / campaign.duration) * 100)}%
                          </p>
                        </div>
                      </div>

                      <div className="mt-3">
                        <Progress
                          value={((campaign.duration - campaign.weeksRemaining) / campaign.duration) * 100}
                          className="h-2"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <Megaphone className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No active marketing campaigns.</p>
                  <p className="text-sm">Start a campaign to promote your movies!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-black/20 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-8 h-8 text-green-400" />
                  <div>
                    <p className="text-sm text-gray-400">Total Marketing Spend</p>
                    <p className="text-xl font-bold text-green-400">{formatMoney(getTotalMarketingSpend())}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Megaphone className="w-8 h-8 text-blue-400" />
                  <div>
                    <p className="text-sm text-gray-400">Active Campaigns</p>
                    <p className="text-xl font-bold text-blue-400">{activeCampaigns.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-purple-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Target className="w-8 h-8 text-purple-400" />
                  <div>
                    <p className="text-sm text-gray-400">Avg Effectiveness</p>
                    <p className="text-xl font-bold text-purple-400">
                      {activeCampaigns.length > 0
                        ? Math.round(
                            activeCampaigns.reduce((sum: number, c: any) => sum + c.effectiveness, 0) /
                              activeCampaigns.length,
                          )
                        : 0}
                      %
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-yellow-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-8 h-8 text-yellow-400" />
                  <div>
                    <p className="text-sm text-gray-400">Movies in Marketing</p>
                    <p className="text-xl font-bold text-yellow-400">
                      {studioData.projects?.filter((p: any) => p.status === "Marketing").length || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Marketing Performance by Movie</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {studioData.projects
                  ?.filter((p: any) => p.marketingBoost > 0)
                  .map((movie: any) => (
                    <div key={movie.id} className="p-4 bg-white/5 rounded border border-white/10">
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="font-semibold text-white">{movie.title}</h3>
                        <Badge variant="outline" className="text-green-400">
                          +{movie.marketingBoost}% boost
                        </Badge>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-sm text-gray-400">Budget</p>
                          <p className="font-semibold text-blue-400">{formatMoney(movie.budget)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-400">Marketing Boost</p>
                          <p className="font-semibold text-green-400">+{movie.marketingBoost}%</p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-400">Expected ROI</p>
                          <p className="font-semibold text-purple-400">
                            {Math.round((movie.marketingBoost || 0) * 2)}%
                          </p>
                        </div>
                      </div>
                      <div className="mt-3">
                        <Progress value={Math.min(100, movie.marketingBoost)} className="h-2" />
                      </div>
                    </div>
                  )) || (
                  <div className="text-center py-8 text-gray-400">
                    <TrendingUp className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No marketing data available yet.</p>
                    <p className="text-sm">Start marketing campaigns to see performance metrics!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
