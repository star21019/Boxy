"use client"

import { CardDescription } from "@/components/ui/card"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { toast } from "sonner"
import { Building2, TrendingUp, DollarSign, Film, Users, Target, Zap, Shield } from "lucide-react"

interface Rival {
  id: string
  name: string
  reputation: number
  money: number
}

const DEFAULT_RIVALS: Rival[] = [
  { id: "r1", name: "Silver Screen Corp", reputation: 80, money: 120000000 },
  { id: "r2", name: "IndieGem Pictures", reputation: 60, money: 15000000 },
  { id: "r3", name: "StreamFlix Studios", reputation: 70, money: 90000000 },
]

interface RivalStudiosProps {
  studioData: any
  onUpdateStudio: (updates: any) => void
}

export function RivalStudios({ studioData, onUpdateStudio }: RivalStudiosProps) {
  const [selectedRival, setSelectedRival] = useState("")
  const [gameWeek, setGameWeek] = useState(1)
  const [rivals] = useState<Rival[]>(DEFAULT_RIVALS)

  const formatMoney = (amount: number) => {
    if (amount >= 1000000000) return `$${(amount / 1000000000).toFixed(1)}B`
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(1)}K`
    return `$${amount.toLocaleString()}`
  }

  // Initialize rival studios with current projects
  const [rivalsWithProjects, setRivalsWithProjects] = useState(() =>
    rivals.map((rival) => ({
      ...rival,
      currentProjects: [],
      recentReleases: [],
      weeklyRevenue: 0,
      marketShare: 0,
    })),
  )

  const simulateRivalActivity = () => {
    const updatedRivals = rivalsWithProjects.map((rival) => {
      const newRival = { ...rival }

      // Chance to start new project
      if (Math.random() < 0.15 && newRival.money > 10000000) {
        // 15% chance per week
        const newProject = generateRivalProject(newRival)
        if (newProject) {
          newRival.currentProjects = [...(newRival.currentProjects || []), newProject]
          newRival.money -= newProject.budget
        }
      }

      // Process ongoing projects
      newRival.currentProjects = (newRival.currentProjects || []).map((project: any) => {
        if (project.releaseWeek <= gameWeek && !project.released) {
          // Movie is being released
          project.released = true
          project.weeksSinceRelease = 0
          project.totalBoxOffice = 0

          // Move to recent releases
          newRival.recentReleases = [...(newRival.recentReleases || []), project].slice(-5) // Keep last 5

          return project
        }
        return project
      })

      // Calculate box office for recent releases
      newRival.weeklyRevenue = 0
      newRival.recentReleases = (newRival.recentReleases || []).map((movie: any) => {
        if (movie.released && movie.weeksSinceRelease < 12) {
          const weeklyRevenue = calculateRivalBoxOffice(movie, newRival)
          movie.totalBoxOffice = (movie.totalBoxOffice || 0) + weeklyRevenue
          movie.weeksSinceRelease += 1
          newRival.weeklyRevenue += weeklyRevenue
          newRival.money += weeklyRevenue * 0.5 // Studio share
        }
        return movie
      })

      // Update reputation based on recent performance
      const avgBoxOffice =
        newRival.recentReleases.reduce((sum: number, movie: any) => sum + (movie.totalBoxOffice || 0), 0) /
        Math.max(1, newRival.recentReleases.length)

      if (avgBoxOffice > 100000000) newRival.reputation += 1
      else if (avgBoxOffice < 20000000) newRival.reputation -= 1

      newRival.reputation = Math.max(0, Math.min(100, newRival.reputation))

      return newRival
    })

    // Calculate market share
    const totalRevenue =
      updatedRivals.reduce((sum, rival) => sum + rival.weeklyRevenue, 0) + (studioData.weeklyRevenue || 0)

    updatedRivals.forEach((rival) => {
      rival.marketShare = totalRevenue > 0 ? (rival.weeklyRevenue / totalRevenue) * 100 : 0
    })

    setRivalsWithProjects(updatedRivals)
    setGameWeek((prev) => prev + 1)
  }

  const generateRivalProject = (rival: any) => {
    const genres = rival.specialties || ["Drama", "Action", "Comedy"]
    const selectedGenre = genres[Math.floor(Math.random() * genres.length)]

    let budgetRange: [number, number]
    switch (rival.type) {
      case "Major":
        budgetRange = [20000000, 200000000]
        break
      case "Streaming":
        budgetRange = [5000000, 100000000]
        break
      default: // Indie
        budgetRange = [500000, 20000000]
    }

    const budget = budgetRange[0] + Math.random() * (budgetRange[1] - budgetRange[0])

    if (rival.money < budget) return null

    return {
      id: `rival_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      title: generateMovieTitle(selectedGenre),
      genre: selectedGenre,
      budget,
      releaseWeek: gameWeek + Math.floor(Math.random() * 20) + 8, // 8-28 weeks from now
      status: "Development",
      released: false,
    }
  }

  const generateMovieTitle = (genre: string): string => {
    const titlePrefixes = ["The", "Dark", "Last", "Secret", "Hidden", "Lost", "Final", "Ultimate"]
    const titleSuffixes = ["Legacy", "Rising", "Chronicles", "Awakening", "Revolution", "Destiny", "Origins"]

    return `${titlePrefixes[Math.floor(Math.random() * titlePrefixes.length)]} ${titleSuffixes[Math.floor(Math.random() * titleSuffixes.length)]}`
  }

  const calculateRivalBoxOffice = (movie: any, rival: any) => {
    const baseRevenue = movie.budget * 0.12 // 12% of budget per week
    const weekDecay = Math.max(0.1, 1 - (movie.weeksSinceRelease || 0) * 0.18)
    const reputationMultiplier = (rival.reputation / 100) * 1.5
    const typeMultiplier = rival.type === "Major" ? 1.2 : rival.type === "Streaming" ? 1.1 : 0.8
    const randomFactor = 0.7 + Math.random() * 0.6

    return baseRevenue * weekDecay * reputationMultiplier * typeMultiplier * randomFactor
  }

  const sabotageRival = (rivalId: string) => {
    const sabotageActions = [
      { name: "Poach Talent", cost: 2000000, effect: "Steal their best actors", success: 0.6 },
      { name: "Leak Script", cost: 500000, effect: "Damage their upcoming movie", success: 0.7 },
      { name: "Counter-Marketing", cost: 1500000, effect: "Reduce their marketing effectiveness", success: 0.8 },
      { name: "Schedule Conflict", cost: 1000000, effect: "Force them to change release date", success: 0.5 },
    ]

    const action = sabotageActions[Math.floor(Math.random() * sabotageActions.length)]

    if (studioData.money < action.cost) {
      toast.error("Insufficient funds for sabotage!")
      return
    }

    if (Math.random() < action.success) {
      const updatedRivals = rivalsWithProjects.map((rival) => {
        if (rival.id === rivalId) {
          return {
            ...rival,
            reputation: Math.max(0, rival.reputation - 5),
            money: Math.max(0, rival.money - action.cost * 0.5),
          }
        }
        return rival
      })

      setRivalsWithProjects(updatedRivals)
      onUpdateStudio({
        money: studioData.money - action.cost,
        reputation: Math.max(0, studioData.reputation - 2), // Sabotage hurts your reputation
      })

      toast.success(`Sabotage successful! ${action.effect}`)
    } else {
      onUpdateStudio({
        money: studioData.money - action.cost,
        reputation: Math.max(0, studioData.reputation - 5), // Failed sabotage hurts more
      })

      toast.error("Sabotage failed and was exposed! Your reputation has been damaged.")
    }
  }

  const formAlliance = (rivalId: string) => {
    const allianceCost = 5000000

    if (studioData.money < allianceCost) {
      toast.error("Insufficient funds to form alliance!")
      return
    }

    const rival = rivalsWithProjects.find((r) => r.id === rivalId)
    if (!rival) return

    // Check if alliance is possible (reputation difference)
    const reputationDiff = Math.abs(studioData.reputation - rival.reputation)
    if (reputationDiff > 30) {
      toast.error("Reputation difference too large for alliance!")
      return
    }

    onUpdateStudio({
      money: studioData.money - allianceCost,
      alliances: [...(studioData.alliances || []), rivalId],
      reputation: studioData.reputation + 3,
    })

    toast.success(`Alliance formed with ${rival.name}! +3 reputation, shared resources unlocked.`)
  }

  const getPlayerRanking = () => {
    const allStudios = [
      { name: studioData.name, reputation: studioData.reputation, money: studioData.money, isPlayer: true },
      ...rivalsWithProjects.map((rival) => ({ ...rival, isPlayer: false })),
    ]

    return (
      allStudios
        .sort((a, b) => b.reputation + b.money / 10000000 - (a.reputation + a.money / 10000000))
        .findIndex((studio) => studio.isPlayer) + 1
    )
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Rival Studios</h2>
        <p className="text-gray-300">Monitor competition and industry dynamics</p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Industry Overview</TabsTrigger>
          <TabsTrigger value="rivals">Rival Analysis</TabsTrigger>
          <TabsTrigger value="competition">Competition</TabsTrigger>
          <TabsTrigger value="actions">Strategic Actions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-black/20 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Target className="w-8 h-8 text-blue-400" />
                  <div>
                    <p className="text-sm text-gray-400">Your Ranking</p>
                    <p className="text-xl font-bold text-blue-400">#{getPlayerRanking()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-8 h-8 text-green-400" />
                  <div>
                    <p className="text-sm text-gray-400">Market Share</p>
                    <p className="text-xl font-bold text-green-400">
                      {(
                        ((studioData.weeklyRevenue || 0) /
                          Math.max(
                            1,
                            rivalsWithProjects.reduce((sum, r) => sum + r.weeklyRevenue, 0) +
                              (studioData.weeklyRevenue || 0),
                          )) *
                        100
                      ).toFixed(1)}
                      %
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-purple-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Building2 className="w-8 h-8 text-purple-400" />
                  <div>
                    <p className="text-sm text-gray-400">Active Rivals</p>
                    <p className="text-xl font-bold text-purple-400">{rivalsWithProjects.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-yellow-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Film className="w-8 h-8 text-yellow-400" />
                  <div>
                    <p className="text-sm text-gray-400">Week</p>
                    <p className="text-xl font-bold text-yellow-400">{gameWeek}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Industry Leaderboard</CardTitle>
              <CardDescription>Studios ranked by reputation and financial power</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { name: studioData.name, reputation: studioData.reputation, money: studioData.money, isPlayer: true },
                  ...rivalsWithProjects.map((rival) => ({ ...rival, isPlayer: false })),
                ]
                  .sort((a, b) => b.reputation + b.money / 10000000 - (a.reputation + a.money / 10000000))
                  .map((studio, index) => (
                    <div
                      key={studio.name}
                      className={`flex items-center gap-4 p-3 rounded ${studio.isPlayer ? "bg-blue-500/20 border border-blue-500/30" : "bg-white/5"}`}
                    >
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-bold">
                        {index + 1}
                      </div>
                      <Avatar className="w-10 h-10">
                        <AvatarFallback className={studio.isPlayer ? "bg-blue-500" : "bg-gray-600"}>
                          {studio.name
                            .split(" ")
                            .map((n: string) => n[0])
                            .join("")
                            .slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className={`font-semibold ${studio.isPlayer ? "text-blue-400" : "text-white"}`}>
                          {studio.name} {studio.isPlayer && "(You)"}
                        </h3>
                        <p className="text-sm text-gray-400">{studio.type || "Player Studio"}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-yellow-400">Rep: {studio.reputation}</p>
                        <p className="text-sm text-green-400">{formatMoney(studio.money)}</p>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Button onClick={simulateRivalActivity} className="bg-purple-500 hover:bg-purple-600">
              <Zap className="w-4 h-4 mr-2" />
              Advance Week
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="rivals" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {rivalsWithProjects.map((rival) => (
              <Card key={rival.id} className="bg-black/20 border-white/10">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback className="bg-gradient-to-r from-red-500 to-pink-500 text-white">
                        {rival.name
                          .split(" ")
                          .map((n: string) => n[0])
                          .join("")
                          .slice(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-white">{rival.name}</CardTitle>
                      <CardDescription>{rival.type} Studio</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-400">Reputation</p>
                      <p className="font-bold text-yellow-400">{rival.reputation}/100</p>
                      <Progress value={rival.reputation} className="h-2 mt-1" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Money</p>
                      <p className="font-bold text-green-400">{formatMoney(rival.money)}</p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400 mb-2">Specialties</p>
                    <div className="flex flex-wrap gap-1">
                      {rival.specialties.map((specialty: string) => (
                        <Badge key={specialty} variant="outline" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400 mb-2">AI Personality</p>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Aggression</span>
                        <span>{rival.personality.aggression}%</span>
                      </div>
                      <Progress value={rival.personality.aggression} className="h-1" />

                      <div className="flex justify-between text-xs">
                        <span>Innovation</span>
                        <span>{rival.personality.innovation}%</span>
                      </div>
                      <Progress value={rival.personality.innovation} className="h-1" />

                      <div className="flex justify-between text-xs">
                        <span>Risk Tolerance</span>
                        <span>{rival.personality.riskTolerance}%</span>
                      </div>
                      <Progress value={rival.personality.riskTolerance} className="h-1" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-gray-400">Active Projects</p>
                      <p className="text-white">{rival.currentProjects?.length || 0}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">Market Share</p>
                      <p className="text-purple-400">{rival.marketShare?.toFixed(1) || 0}%</p>
                    </div>
                  </div>

                  <Button onClick={() => setSelectedRival(rival.id)} variant="outline" className="w-full">
                    <Users className="w-4 h-4 mr-2" />
                    View Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="competition" className="space-y-6">
          {selectedRival && (
            <Card className="bg-black/20 border-red-500/30">
              <CardHeader>
                <CardTitle className="text-red-400">
                  {rivalsWithProjects.find((r) => r.id === selectedRival)?.name} - Detailed Analysis
                </CardTitle>
                <CardDescription>Competitive intelligence and current projects</CardDescription>
              </CardHeader>
              <CardContent>
                {(() => {
                  const rival = rivalsWithProjects.find((r) => r.id === selectedRival)
                  if (!rival) return null

                  return (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="text-center p-4 bg-white/5 rounded">
                          <TrendingUp className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-400">Weekly Revenue</p>
                          <p className="text-xl font-bold text-blue-400">{formatMoney(rival.weeklyRevenue)}</p>
                        </div>

                        <div className="text-center p-4 bg-white/5 rounded">
                          <Film className="w-8 h-8 text-green-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-400">Recent Releases</p>
                          <p className="text-xl font-bold text-green-400">{rival.recentReleases?.length || 0}</p>
                        </div>

                        <div className="text-center p-4 bg-white/5 rounded">
                          <Building2 className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-400">In Development</p>
                          <p className="text-xl font-bold text-purple-400">{rival.currentProjects?.length || 0}</p>
                        </div>
                      </div>

                      {rival.currentProjects && rival.currentProjects.length > 0 && (
                        <div>
                          <h3 className="text-lg font-semibold text-white mb-3">Current Projects</h3>
                          <div className="space-y-2">
                            {rival.currentProjects.map((project: any) => (
                              <div key={project.id} className="p-3 bg-white/5 rounded border border-white/10">
                                <div className="flex justify-between items-center">
                                  <div>
                                    <h4 className="font-semibold text-white">{project.title}</h4>
                                    <p className="text-sm text-gray-400">
                                      {project.genre} • {formatMoney(project.budget)}
                                    </p>
                                  </div>
                                  <Badge variant="outline">
                                    {project.released ? "Released" : `Week ${project.releaseWeek}`}
                                  </Badge>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {rival.recentReleases && rival.recentReleases.length > 0 && (
                        <div>
                          <h3 className="text-lg font-semibold text-white mb-3">Recent Releases</h3>
                          <div className="space-y-2">
                            {rival.recentReleases.map((movie: any) => (
                              <div key={movie.id} className="p-3 bg-white/5 rounded border border-white/10">
                                <div className="flex justify-between items-center">
                                  <div>
                                    <h4 className="font-semibold text-white">{movie.title}</h4>
                                    <p className="text-sm text-gray-400">
                                      {movie.genre} • Budget: {formatMoney(movie.budget)}
                                    </p>
                                  </div>
                                  <div className="text-right">
                                    <p className="font-bold text-green-400">{formatMoney(movie.totalBoxOffice || 0)}</p>
                                    <p className="text-xs text-gray-400">Box Office</p>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )
                })()}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="actions" className="space-y-6">
          <Card className="bg-black/20 border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-orange-400">Strategic Actions</CardTitle>
              <CardDescription>Take action against or with rival studios</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold text-red-400 mb-3">Hostile Actions</h3>
                  <div className="space-y-3">
                    <div className="p-4 bg-red-500/10 rounded border border-red-500/30">
                      <h4 className="font-semibold text-white">Corporate Sabotage</h4>
                      <p className="text-sm text-gray-400 mb-2">Disrupt rival operations</p>
                      <p className="text-red-400 text-sm">Cost: $500K - $2M • Risk: High</p>
                      <Button
                        onClick={() => selectedRival && sabotageRival(selectedRival)}
                        disabled={!selectedRival}
                        className="w-full mt-2 bg-red-500 hover:bg-red-600"
                      >
                        <Shield className="w-4 h-4 mr-2" />
                        Execute Sabotage
                      </Button>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-green-400 mb-3">Cooperative Actions</h3>
                  <div className="space-y-3">
                    <div className="p-4 bg-green-500/10 rounded border border-green-500/30">
                      <h4 className="font-semibold text-white">Form Alliance</h4>
                      <p className="text-sm text-gray-400 mb-2">Partner with a rival studio</p>
                      <p className="text-green-400 text-sm">Cost: $5M • Benefit: Shared resources</p>
                      <Button
                        onClick={() => selectedRival && formAlliance(selectedRival)}
                        disabled={!selectedRival}
                        className="w-full mt-2 bg-green-500 hover:bg-green-600"
                      >
                        <Users className="w-4 h-4 mr-2" />
                        Form Alliance
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {!selectedRival && (
                <div className="text-center py-8 text-gray-400">
                  <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Select a rival studio first to take strategic actions.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
