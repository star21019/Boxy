"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Trophy, Crown, Star, Award, Film, Users, TrendingUp } from "lucide-react"

interface HallOfFameProps {
  studioData?: any
}

export function HallOfFame({ studioData }: HallOfFameProps) {
  const formatMoney = (amount: number) => {
    if (amount >= 1000000000) {
      return `$${(amount / 1000000000).toFixed(1)}B`
    } else if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(1)}K`
    }
    return `$${amount.toLocaleString()}`
  }

  // Hall of Fame categories with realistic achievements
  const achievements = [
    {
      id: "first_movie",
      title: "First Steps",
      description: "Release your first movie",
      icon: <Film className="w-6 h-6" />,
      progress: 0,
      maxProgress: 1,
      reward: "$100K bonus",
      unlocked: false,
      category: "Milestones",
    },
    {
      id: "box_office_king",
      title: "Box Office King",
      description: "Earn $1B total revenue",
      icon: <Crown className="w-6 h-6" />,
      progress: 0,
      maxProgress: 1000000000,
      reward: "Golden Crown badge",
      unlocked: false,
      category: "Revenue",
    },
    {
      id: "award_winner",
      title: "Award Winner",
      description: "Win your first major award",
      icon: <Trophy className="w-6 h-6" />,
      progress: 0,
      maxProgress: 1,
      reward: "Trophy display",
      unlocked: false,
      category: "Awards",
    },
    {
      id: "studio_empire",
      title: "Studio Empire",
      description: "Hire 100 employees",
      icon: <Users className="w-6 h-6" />,
      progress: 12,
      maxProgress: 100,
      reward: "Empire badge",
      unlocked: false,
      category: "Growth",
    },
    {
      id: "reputation_legend",
      title: "Industry Legend",
      description: "Reach 95+ reputation",
      icon: <Star className="w-6 h-6" />,
      progress: studioData?.reputation || 50,
      maxProgress: 95,
      reward: "Legend status",
      unlocked: false,
      category: "Reputation",
    },
  ]

  // Hall of Fame leaderboard (simulated data)
  const leaderboard = [
    {
      rank: 1,
      studio: "Marvel Studios",
      revenue: 28500000000,
      reputation: 98,
      awards: 47,
      badge: "👑",
    },
    {
      rank: 2,
      studio: "Warner Bros",
      revenue: 22100000000,
      reputation: 94,
      awards: 38,
      badge: "🏆",
    },
    {
      rank: 3,
      studio: "Universal Pictures",
      revenue: 19800000000,
      reputation: 91,
      awards: 32,
      badge: "⭐",
    },
    {
      rank: 4,
      studio: "Disney Studios",
      revenue: 18200000000,
      reputation: 89,
      awards: 29,
      badge: "🎬",
    },
    {
      rank: 5,
      studio: "Sony Pictures",
      revenue: 15600000000,
      reputation: 85,
      awards: 24,
      badge: "🎭",
    },
  ]

  const userStudio = {
    rank: studioData?.globalRank || 247,
    studio: `${studioData?.name || "Your Studio"} ${studioData?.suffix || "Studios"}`,
    revenue: studioData?.money || 25000000,
    reputation: studioData?.reputation || 50,
    awards: 0,
    badge: "🎪",
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Hall of Fame Header */}
      <Card className="bg-black/20 border-yellow-500/30">
        <CardHeader>
          <CardTitle className="text-yellow-400 flex items-center gap-2 text-2xl">
            <Trophy className="w-8 h-8" />
            Hall of Fame
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-300 mb-4">
            Immortalize your studio's greatest achievements and compete with the industry's elite.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-white/5 rounded-lg">
              <div className="text-2xl font-bold text-yellow-400">{achievements.filter((a) => a.unlocked).length}</div>
              <div className="text-sm text-gray-400">Achievements Unlocked</div>
            </div>
            <div className="text-center p-4 bg-white/5 rounded-lg">
              <div className="text-2xl font-bold text-green-400">{formatMoney(userStudio.revenue)}</div>
              <div className="text-sm text-gray-400">Total Revenue</div>
            </div>
            <div className="text-center p-4 bg-white/5 rounded-lg">
              <div className="text-2xl font-bold text-purple-400">#{userStudio.rank}</div>
              <div className="text-sm text-gray-400">Global Ranking</div>
            </div>
            <div className="text-center p-4 bg-white/5 rounded-lg">
              <div className="text-2xl font-bold text-blue-400">{userStudio.awards}</div>
              <div className="text-sm text-gray-400">Awards Won</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Achievements */}
        <Card className="bg-black/20 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-purple-400 flex items-center gap-2">
              <Award className="w-5 h-5" />
              Achievements
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-4 rounded-lg border ${
                  achievement.unlocked ? "bg-yellow-500/10 border-yellow-500/30" : "bg-white/5 border-gray-600/30"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${achievement.unlocked ? "bg-yellow-500/20" : "bg-gray-600/20"}`}>
                    {achievement.icon}
                  </div>
                  <div className="flex-grow">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold text-white">{achievement.title}</h4>
                      <Badge variant="outline" className="text-xs">
                        {achievement.category}
                      </Badge>
                      {achievement.unlocked && <Badge className="text-xs bg-yellow-500">Unlocked</Badge>}
                    </div>
                    <p className="text-sm text-gray-400 mb-2">{achievement.description}</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">Progress</span>
                        <span className="text-white">
                          {achievement.maxProgress > 1000000
                            ? `${formatMoney(achievement.progress)} / ${formatMoney(achievement.maxProgress)}`
                            : `${achievement.progress} / ${achievement.maxProgress}`}
                        </span>
                      </div>
                      <Progress value={(achievement.progress / achievement.maxProgress) * 100} className="h-2" />
                      <div className="text-xs text-green-400">Reward: {achievement.reward}</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Global Leaderboard */}
        <Card className="bg-black/20 border-green-500/30">
          <CardHeader>
            <CardTitle className="text-green-400 flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Global Leaderboard
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {leaderboard.map((studio) => (
              <div
                key={studio.rank}
                className={`p-3 rounded-lg border ${
                  studio.rank <= 3 ? "bg-yellow-500/10 border-yellow-500/30" : "bg-white/5 border-gray-600/30"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">{studio.badge}</div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">#{studio.rank}</span>
                        <span className="text-white font-medium">{studio.studio}</span>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-gray-400">
                        <span>Rep: {studio.reputation}</span>
                        <span>Awards: {studio.awards}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-green-400 font-bold">{formatMoney(studio.revenue)}</div>
                    <div className="text-xs text-gray-400">Revenue</div>
                  </div>
                </div>
              </div>
            ))}

            {/* User Studio Position */}
            <div className="border-t border-gray-600 pt-3">
              <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">{userStudio.badge}</div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-blue-400">#{userStudio.rank}</span>
                        <span className="text-white font-medium">{userStudio.studio}</span>
                        <Badge className="text-xs bg-blue-500">You</Badge>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-gray-400">
                        <span>Rep: {userStudio.reputation}</span>
                        <span>Awards: {userStudio.awards}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-green-400 font-bold">{formatMoney(userStudio.revenue)}</div>
                    <div className="text-xs text-gray-400">Revenue</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
