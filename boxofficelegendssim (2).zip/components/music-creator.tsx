"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Music, DollarSign, Play, Award } from "lucide-react"

interface MusicCreatorProps {
  studioData: any
  onUpdateStudio: (data: any) => void
}

export function MusicCreator({ studioData, onUpdateStudio }: MusicCreatorProps) {
  const [musicData, setMusicData] = useState({
    title: "",
    artist: "",
    genre: "",
    budget: 500000,
    duration: 3.5,
    type: "single", // single, album, soundtrack
    description: "",
  })

  const musicGenres = [
    "Pop",
    "Rock",
    "Hip-Hop",
    "R&B",
    "Country",
    "Electronic",
    "Jazz",
    "Classical",
    "Reggae",
    "Folk",
    "Blues",
    "Punk",
  ]

  const formatMoney = (amount: number) => {
    if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(0)}K`
    }
    return `$${amount.toLocaleString()}`
  }

  const handleCreateMusic = () => {
    if (studioData.money < musicData.budget) {
      alert("Not enough budget to create this music project!")
      return
    }

    const newMusic = {
      id: Date.now().toString(),
      ...musicData,
      status: "recording",
      progress: 0,
    }

    const newMoney = studioData.money - musicData.budget
    const newMusic_projects = [...(studioData.music || []), newMusic]
    const reputationBoost = 2
    const newReputation = Math.min(100, (studioData.reputation || 50) + reputationBoost)

    onUpdateStudio({
      money: newMoney,
      music: newMusic_projects,
      reputation: newReputation,
    })

    alert(`Music project "${newMusic.title}" created successfully!`)

    // Reset form
    setMusicData({
      title: "",
      artist: "",
      genre: "",
      budget: 500000,
      duration: 3.5,
      type: "single",
      description: "",
    })
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <Card className="bg-black/20 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <Music className="w-5 h-5" />
            Music Creator
          </CardTitle>
          <CardDescription className="text-gray-300">Create hit songs and soundtracks</CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-black/20 border-green-500/30">
          <CardContent className="p-4 text-center">
            <DollarSign className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-400">{formatMoney(studioData?.money || 25000000)}</div>
            <div className="text-sm text-gray-400">Available Budget</div>
          </CardContent>
        </Card>
        <Card className="bg-black/20 border-blue-500/30">
          <CardContent className="p-4 text-center">
            <Music className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-blue-400">{studioData?.music?.length || 0}</div>
            <div className="text-sm text-gray-400">Music Projects</div>
          </CardContent>
        </Card>
        <Card className="bg-black/20 border-purple-500/30">
          <CardContent className="p-4 text-center">
            <Award className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-purple-400">0</div>
            <div className="text-sm text-gray-400">Music Awards</div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-black/20 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-400">Music Project Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Title</label>
              <Input
                value={musicData.title}
                onChange={(e) => setMusicData({ ...musicData, title: e.target.value })}
                placeholder="Enter song/album title..."
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Artist</label>
              <Input
                value={musicData.artist}
                onChange={(e) => setMusicData({ ...musicData, artist: e.target.value })}
                placeholder="Enter artist name..."
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Genre</label>
              <Select value={musicData.genre} onValueChange={(value) => setMusicData({ ...musicData, genre: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose genre..." />
                </SelectTrigger>
                <SelectContent>
                  {musicGenres.map((genre) => (
                    <SelectItem key={genre} value={genre}>
                      {genre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Type</label>
              <Select value={musicData.type} onValueChange={(value) => setMusicData({ ...musicData, type: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="single">Single</SelectItem>
                  <SelectItem value="album">Album</SelectItem>
                  <SelectItem value="soundtrack">Soundtrack</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Duration (minutes)</label>
              <div className="space-y-2">
                <Slider
                  value={[musicData.duration]}
                  onValueChange={(value) => setMusicData({ ...musicData, duration: value[0] })}
                  max={60}
                  min={1}
                  step={0.5}
                  className="w-full"
                />
                <div className="text-center text-white font-semibold">{musicData.duration.toFixed(1)} min</div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Budget</label>
            <div className="space-y-2">
              <Slider
                value={[musicData.budget]}
                onValueChange={(value) => setMusicData({ ...musicData, budget: value[0] })}
                max={5000000}
                min={100000}
                step={50000}
                className="w-full"
              />
              <div className="text-center text-2xl font-bold text-green-400">{formatMoney(musicData.budget)}</div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Description</label>
            <Textarea
              value={musicData.description}
              onChange={(e) => setMusicData({ ...musicData, description: e.target.value })}
              placeholder="Describe the music style, theme, or concept..."
              rows={3}
            />
          </div>

          <Button
            onClick={handleCreateMusic}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500"
            disabled={!musicData.title || !musicData.artist || studioData?.money < musicData.budget}
          >
            <Play className="w-4 h-4 mr-2" />
            Start Recording
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
