"use client"

import { CardDescription } from "@/components/ui/card"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { User, Star, DollarSign, Search, UserPlus } from "lucide-react"
import { availableActors } from "@/lib/movie-data"
import { toast } from "sonner"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"
import { Input } from "@/components/ui/input"

export interface Actor {
  id: string
  name: string
  tier: "A-List" | "B-List" | "C-List"
  specialty: string
  cost: number
  appeal: number
}

const SAMPLE_ACTORS: Actor[] = [
  { id: "a1", name: "Chris Evans", tier: "A-List", specialty: "Action", cost: 15000000, appeal: 95 },
  { id: "a2", name: "Zendaya", tier: "A-List", specialty: "Drama", cost: 12000000, appeal: 92 },
  { id: "a3", name: "Simu Liu", tier: "B-List", specialty: "Action", cost: 4000000, appeal: 80 },
  { id: "a4", name: "Ana de Armas", tier: "B-List", specialty: "Thriller", cost: 5000000, appeal: 84 },
  { id: "a5", name: "Awkwafina", tier: "C-List", specialty: "Comedy", cost: 1500000, appeal: 70 },
]

interface ActorCastingProps {
  movie: any
  onUpdateMovie: (updates: any) => void
  studioData: any
  onUpdateStudio: (updates: any) => void
}

export function ActorCasting({ movie, onUpdateMovie, studioData, onUpdateStudio }: ActorCastingProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterTier, setFilterTier] = useState("all")
  const [filterSpecialty, setFilterSpecialty] = useState("all")
  const [selectedCharacter, setSelectedCharacter] = useState("")
  const [selected, setSelected] = useState<string[]>(movie.cast || [])

  const formatMoney = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`
    return `$${amount.toLocaleString()}`
  }

  const filteredActors = availableActors.filter((actor) => {
    const matchesSearch = actor.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesTier = filterTier === "all" || actor.tier === filterTier
    const matchesSpecialty = filterSpecialty === "all" || actor.specialty === filterSpecialty
    const notAlreadyCast = !selected.includes(actor.id)

    return matchesSearch && matchesTier && matchesSpecialty && notAlreadyCast
  })

  const toggleActor = (actor: Actor) => {
    const already = selected.includes(actor.id)
    const next = already ? selected.filter((id) => id !== actor.id) : [...selected, actor.id]
    setSelected(next)

    // update movie immediately for now
    onUpdateMovie({ cast: next })
  }

  const budgetUsed = selected.map((id) => SAMPLE_ACTORS.find((a) => a.id === id)!.cost).reduce((sum, c) => sum + c, 0)

  const castActor = (actor: any, characterId: string) => {
    if (studioData.money < actor.cost) {
      toast.error("Insufficient funds to hire this actor!")
      return
    }

    const character = movie.characters.find((c: any) => c.id === characterId)
    if (!character) {
      toast.error("Please select a character to cast!")
      return
    }

    // Update movie with cast details
    const newCastDetails = [
      ...(movie.castDetails || []),
      {
        ...actor,
        characterId,
        characterName: character.name,
        characterRole: character.role,
      },
    ]

    onUpdateMovie({
      castDetails: newCastDetails,
      cast: [...(movie.cast || []), actor.id],
    })

    // Deduct cost from studio
    onUpdateStudio({
      money: studioData.money - actor.cost,
    })

    toast.success(`${actor.name} has been cast as ${character.name}!`)
  }

  const removeActor = (actorId: string) => {
    const actor = movie.castDetails?.find((c: any) => c.id === actorId)
    if (actor) {
      onUpdateMovie({
        castDetails: movie.castDetails.filter((c: any) => c.id !== actorId),
        cast: movie.cast.filter((id: string) => id !== actorId),
      })

      // Refund 50% of cost
      onUpdateStudio({
        money: studioData.money + actor.cost * 0.5,
      })

      toast.success(`${actor.name} has been removed from the cast. 50% refund applied.`)
    }
  }

  const getTotalCastCost = () => {
    return movie.castDetails?.reduce((sum: number, actor: any) => sum + actor.cost, 0) || 0
  }

  const getUncastCharacters = () => {
    return (
      movie.characters?.filter((char: any) => !movie.castDetails?.some((cast: any) => cast.characterId === char.id)) ||
      []
    )
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Cast Your Movie</h2>
        <p className="text-gray-300">Hire actors for "{movie.title}"</p>
      </div>

      {/* Current Cast */}
      {movie.castDetails && movie.castDetails.length > 0 && (
        <Card className="bg-black/20 border-green-500/30">
          <CardHeader>
            <CardTitle className="text-green-400">Current Cast</CardTitle>
            <CardDescription>Total Cost: {formatMoney(getTotalCastCost())}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {movie.castDetails.map((actor: any) => (
                <div
                  key={actor.id}
                  className="flex items-center gap-3 p-3 bg-white/5 rounded border border-green-500/30"
                >
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className="bg-gradient-to-r from-green-500 to-blue-500 text-white">
                      {actor.name
                        .split(" ")
                        .map((n: string) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h4 className="font-semibold text-white">{actor.name}</h4>
                    <p className="text-sm text-gray-400">as {actor.characterName}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs">
                        {actor.tier}
                      </Badge>
                      <span className="text-green-400 text-sm">{formatMoney(actor.cost)}</span>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => removeActor(actor.id)}
                    className="text-red-400 border-red-400 hover:bg-red-400/10"
                  >
                    Remove
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Character Selection */}
      {getUncastCharacters().length > 0 && (
        <Card className="bg-black/20 border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-blue-400">Select Character to Cast</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={selectedCharacter} onValueChange={setSelectedCharacter}>
              <SelectTrigger>
                <SelectValue placeholder="Select a character..." />
              </SelectTrigger>
              <SelectContent>
                {getUncastCharacters().map((character: any) => (
                  <SelectItem key={character.id} value={character.id}>
                    {character.name} ({character.role}) - {character.gender}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <Card className="bg-black/20 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Find Actors</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-white mb-2 block">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search actors..."
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-white mb-2 block">Tier</label>
              <Select value={filterTier} onValueChange={setFilterTier}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tiers</SelectItem>
                  <SelectItem value="A-List">A-List</SelectItem>
                  <SelectItem value="B-List">B-List</SelectItem>
                  <SelectItem value="C-List">C-List</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium text-white mb-2 block">Specialty</label>
              <Select value={filterSpecialty} onValueChange={setFilterSpecialty}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specialties</SelectItem>
                  <SelectItem value="Action">Action</SelectItem>
                  <SelectItem value="Drama">Drama</SelectItem>
                  <SelectItem value="Comedy">Comedy</SelectItem>
                  <SelectItem value="Thriller">Thriller</SelectItem>
                  <SelectItem value="Sci-Fi">Sci-Fi</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Available Actors */}
      <Card className="bg-black/20 border-white/10">
        <CardHeader>
          <CardTitle className="text-white">Available Actors ({filteredActors.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96 pr-4">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredActors.map((actor) => {
                const picked = selected.includes(actor.id)
                return (
                  <Card
                    key={actor.id}
                    className={`cursor-pointer transition-all ${picked ? "border-green-500/60" : "border-white/10"}`}
                    onClick={() => selectedCharacter && castActor(actor, selectedCharacter)}
                  >
                    <CardContent className="p-4 space-y-1">
                      <h3 className="font-semibold text-white flex items-center gap-1">
                        {actor.name}
                        {picked && <UserPlus className="w-4 h-4 text-green-400" />}
                      </h3>
                      <Badge variant="outline">{actor.tier}</Badge>
                      <p className="text-xs text-gray-400">
                        {actor.specialty} • Appeal {actor.appeal}
                      </p>
                      <p className="text-xs text-gray-400">${actor.cost.toLocaleString()}</p>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Budget Summary */}
      <Card className="bg-black/20 border-yellow-500/30">
        <CardHeader>
          <CardTitle className="text-yellow-400">Budget Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-white/5 rounded">
              <DollarSign className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <p className="text-sm text-gray-400">Available Budget</p>
              <p className="text-xl font-bold text-green-400">{formatMoney(studioData.money)}</p>
            </div>

            <div className="text-center p-4 bg-white/5 rounded">
              <Star className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <p className="text-sm text-gray-400">Cast Cost</p>
              <p className="text-xl font-bold text-yellow-400">{formatMoney(budgetUsed)}</p>
            </div>

            <div className="text-center p-4 bg-white/5 rounded">
              <User className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <p className="text-sm text-gray-400">Actors Cast</p>
              <p className="text-xl font-bold text-blue-400">{selected.length}</p>
            </div>
          </div>
          <Button
            onClick={() => {
              if (studioData.money < budgetUsed) return
              onUpdateStudio({ money: studioData.money - budgetUsed })
            }}
            disabled={studioData.money < budgetUsed}
            className="bg-gradient-to-r from-green-500 to-blue-500"
          >
            Confirm Cast ({selected.length})
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
