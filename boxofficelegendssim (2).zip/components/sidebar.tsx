"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ScrollArea } from "@/components/ui/scroll-area"
import Image from "next/image"
import {
  Home,
  Building2,
  Users,
  Film,
  Tv,
  Music,
  TrendingUp,
  DollarSign,
  BarChart3,
  User,
  UserPlus,
  Briefcase,
  FileText,
  Play,
  History,
  Megaphone,
  Share2,
  Zap,
  Newspaper,
  Camera,
  Wrench,
  Headphones,
  Mic,
  Handshake,
  PiggyBank,
  Merge,
  Award,
  Trophy,
  Target,
  Crown,
  Beaker,
  Lightbulb,
  Search,
  BookOpen,
  Gamepad2,
  Medal,
  Settings,
  Volume2,
  Save,
  ChevronDown,
  ChevronRight,
  X,
} from "lucide-react"

interface SidebarProps {
  isOpen: boolean
  onToggle: () => void
  onNavigate: (section: string) => void
  currentSection: string
  studioData: any
}

export function Sidebar({ isOpen, onToggle, onNavigate, currentSection, studioData }: SidebarProps) {
  const [expandedSections, setExpandedSections] = useState<string[]>([
    "studio",
    "staff",
    "projects",
    "marketing",
    "facilities",
    "business",
    "awards",
    "research",
    "game",
    "settings",
  ])

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => (prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]))
  }

  const handleItemClick = (section: string) => {
    onNavigate(section)
    // Auto-close sidebar on mobile after navigation
    if (window.innerWidth < 1024) {
      onToggle()
    }
  }

  const sidebarSections = [
    {
      id: "studio",
      title: "Studio Dashboard",
      icon: <Building2 className="w-4 h-4" />,
      badge: "4",
      items: [
        { id: "overview", label: "Overview", icon: <Home className="w-4 h-4" /> },
        { id: "profile", label: "Studio Profile", icon: <User className="w-4 h-4" /> },
        { id: "analytics", label: "Analytics", icon: <BarChart3 className="w-4 h-4" /> },
        { id: "finances", label: "Finances", icon: <DollarSign className="w-4 h-4" /> },
      ],
    },
    {
      id: "staff",
      title: "Staff & Talent",
      icon: <Users className="w-4 h-4" />,
      badge: studioData?.staff?.length?.toString() || "0",
      items: [
        { id: "hire-staff", label: "Hire Staff", icon: <UserPlus className="w-4 h-4" /> },
        { id: "manage-staff", label: "Manage Staff", icon: <Users className="w-4 h-4" /> },
        { id: "talent-agency", label: "Talent Agency", icon: <Crown className="w-4 h-4" /> },
        { id: "contracts", label: "Contracts", icon: <FileText className="w-4 h-4" /> },
      ],
    },
    {
      id: "projects",
      title: "Projects",
      icon: <Film className="w-4 h-4" />,
      badge: studioData?.projects?.length?.toString() || "0",
      items: [
        { id: "create-movie", label: "Create Movie", icon: <Film className="w-4 h-4" /> },
        { id: "create-tv-show", label: "Create TV Show", icon: <Tv className="w-4 h-4" /> },
        { id: "create-music", label: "Create Music", icon: <Music className="w-4 h-4" /> },
        { id: "active-projects", label: "Active Projects", icon: <Play className="w-4 h-4" /> },
        { id: "project-history", label: "Project History", icon: <History className="w-4 h-4" /> },
      ],
    },
    {
      id: "marketing",
      title: "Marketing",
      icon: <Megaphone className="w-4 h-4" />,
      badge: "New",
      items: [
        { id: "social-media", label: "Social Media", icon: <Share2 className="w-4 h-4" /> },
        { id: "influencer-partnerships", label: "Influencer Partnerships", icon: <Zap className="w-4 h-4" /> },
        { id: "advertising", label: "Advertising", icon: <Megaphone className="w-4 h-4" /> },
        { id: "press-relations", label: "Press Relations", icon: <Newspaper className="w-4 h-4" /> },
      ],
    },
    {
      id: "facilities",
      title: "Studios & Facilities",
      icon: <Camera className="w-4 h-4" />,
      badge: "3",
      items: [
        { id: "studio-lots", label: "Studio Lots", icon: <Building2 className="w-4 h-4" /> },
        { id: "equipment", label: "Equipment", icon: <Wrench className="w-4 h-4" /> },
        { id: "post-production", label: "Post-Production", icon: <Film className="w-4 h-4" /> },
        { id: "sound-stages", label: "Sound Stages", icon: <Headphones className="w-4 h-4" /> },
        { id: "recording-studios", label: "Recording Studios", icon: <Mic className="w-4 h-4" /> },
      ],
    },
    {
      id: "business",
      title: "Business",
      icon: <Briefcase className="w-4 h-4" />,
      badge: "Hot",
      items: [
        { id: "partnerships", label: "Partnerships", icon: <Handshake className="w-4 h-4" /> },
        { id: "investments", label: "Investments", icon: <PiggyBank className="w-4 h-4" /> },
        { id: "mergers", label: "Mergers & Acquisitions", icon: <Merge className="w-4 h-4" /> },
        { id: "licensing", label: "Licensing", icon: <FileText className="w-4 h-4" /> },
      ],
    },
    {
      id: "awards",
      title: "Awards & Recognition",
      icon: <Award className="w-4 h-4" />,
      badge: studioData?.awards?.length?.toString() || "0",
      items: [
        { id: "hall-of-fame", label: "Hall of Fame", icon: <Trophy className="w-4 h-4" /> },
        { id: "achievements", label: "Achievements", icon: <Medal className="w-4 h-4" /> },
        { id: "competitions", label: "Competitions", icon: <Target className="w-4 h-4" /> },
        { id: "rankings", label: "Industry Rankings", icon: <Crown className="w-4 h-4" /> },
      ],
    },
    {
      id: "research",
      title: "R&D",
      icon: <Beaker className="w-4 h-4" />,
      badge: "Beta",
      items: [
        { id: "technology", label: "Technology", icon: <Lightbulb className="w-4 h-4" /> },
        { id: "innovation-lab", label: "Innovation Lab", icon: <Beaker className="w-4 h-4" /> },
        { id: "market-research", label: "Market Research", icon: <Search className="w-4 h-4" /> },
        { id: "trends", label: "Industry Trends", icon: <TrendingUp className="w-4 h-4" /> },
      ],
    },
    {
      id: "game",
      title: "Game Features",
      icon: <Gamepad2 className="w-4 h-4" />,
      badge: "6",
      items: [
        { id: "tutorial", label: "Tutorial", icon: <BookOpen className="w-4 h-4" /> },
        { id: "challenges", label: "Challenges", icon: <Target className="w-4 h-4" /> },
        { id: "leaderboards", label: "Leaderboards", icon: <Trophy className="w-4 h-4" /> },
        { id: "multiplayer", label: "Multiplayer", icon: <Users className="w-4 h-4" /> },
      ],
    },
    {
      id: "settings",
      title: "Settings",
      icon: <Settings className="w-4 h-4" />,
      badge: "",
      items: [
        { id: "game-settings", label: "Game Settings", icon: <Settings className="w-4 h-4" /> },
        { id: "audio-settings", label: "Audio Settings", icon: <Volume2 className="w-4 h-4" /> },
        { id: "save-load", label: "Save & Load", icon: <Save className="w-4 h-4" /> },
        { id: "preferences", label: "Preferences", icon: <User className="w-4 h-4" /> },
      ],
    },
  ]

  if (!isOpen) return null

  return (
    <>
      {/* Mobile Overlay */}
      <div className="lg:hidden fixed inset-0 bg-black/50 z-40" onClick={onToggle} />

      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-80 bg-black/90 backdrop-blur-sm border-r border-purple-500/30 z-50 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-purple-500/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Image src="/box-office-logo.png" alt="Logo" width={32} height={32} className="rounded" />
              <div>
                <h2 className="text-white font-bold text-sm">
                  {studioData?.name || "Your Studio"} {studioData?.suffix || "Studios"}
                </h2>
                <p className="text-gray-400 text-xs">Level {studioData?.level || 1}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onToggle} className="text-white hover:bg-white/10">
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Studio Stats */}
          <div className="grid grid-cols-3 gap-2 mt-3">
            <div className="text-center p-2 bg-white/5 rounded">
              <div className="text-green-400 font-bold text-sm">
                ${((studioData?.money || 0) / 1000000).toFixed(1)}M
              </div>
              <div className="text-gray-400 text-xs">Budget</div>
            </div>
            <div className="text-center p-2 bg-white/5 rounded">
              <div className="text-yellow-400 font-bold text-sm">{studioData?.reputation || 50}</div>
              <div className="text-gray-400 text-xs">Reputation</div>
            </div>
            <div className="text-center p-2 bg-white/5 rounded">
              <div className="text-purple-400 font-bold text-sm">{studioData?.experience || 0}</div>
              <div className="text-gray-400 text-xs">XP</div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-2">
            {sidebarSections.map((section) => (
              <Collapsible
                key={section.id}
                open={expandedSections.includes(section.id)}
                onOpenChange={() => toggleSection(section.id)}
              >
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" className="w-full justify-between text-white hover:bg-white/10 p-3 h-auto">
                    <div className="flex items-center gap-3">
                      {section.icon}
                      <span className="font-medium">{section.title}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {section.badge && (
                        <Badge
                          variant="secondary"
                          className="text-xs bg-purple-500/20 text-purple-300 border-purple-500/30"
                        >
                          {section.badge}
                        </Badge>
                      )}
                      {expandedSections.includes(section.id) ? (
                        <ChevronDown className="w-4 h-4" />
                      ) : (
                        <ChevronRight className="w-4 h-4" />
                      )}
                    </div>
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-1 ml-4 mt-1">
                  {section.items.map((item) => (
                    <Button
                      key={item.id}
                      variant="ghost"
                      onClick={() => handleItemClick(item.id)}
                      className={`w-full justify-start text-sm h-9 ${
                        currentSection === item.id
                          ? "bg-white text-black hover:bg-white/90"
                          : "text-gray-300 hover:bg-white/10 hover:text-white"
                      }`}
                    >
                      {item.icon}
                      <span className="ml-2">{item.label}</span>
                    </Button>
                  ))}
                </CollapsibleContent>
              </Collapsible>
            ))}
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="p-4 border-t border-purple-500/30">
          <div className="text-center text-xs text-gray-400">
            <p>Box Office Legends Sim v2.0</p>
            <p className="mt-1">© 2024 Your Studio</p>
          </div>
        </div>
      </div>
    </>
  )
}
