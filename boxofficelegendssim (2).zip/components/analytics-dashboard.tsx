"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart3, TrendingUp, DollarSign, Film, Star, Target, Zap } from "lucide-react"

interface AnalyticsDashboardProps {
  studioData: any
}

export function AnalyticsDashboard({ studioData }: AnalyticsDashboardProps) {
  const formatMoney = (amount: number) => {
    if (amount >= 1000000000) return `$${(amount / 1000000000).toFixed(1)}B`
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(1)}K`
    return `$${amount.toLocaleString()}`
  }

  const projects = studioData?.projects || []
  const totalRevenue = projects.reduce((sum: number, project: any) => sum + (project.revenue || 0), 0)
  const totalBudget = projects.reduce((sum: number, project: any) => sum + (project.budget || 0), 0)
  const profitMargin = totalBudget > 0 ? ((totalRevenue - totalBudget) / totalBudget) * 100 : 0

  const genrePerformance = projects.reduce((acc: any, project: any) => {
    if (!acc[project.genre]) {
      acc[project.genre] = { count: 0, revenue: 0, budget: 0 }
    }
    acc[project.genre].count++
    acc[project.genre].revenue += project.revenue || 0
    acc[project.genre].budget += project.budget || 0
    return acc
  }, {})

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Studio Analytics</h2>
        <p className="text-gray-300">Deep insights into your studio's performance</p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
          <TabsTrigger value="projects">Projects</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-black/20 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-8 h-8 text-green-400" />
                  <div>
                    <p className="text-sm text-gray-400">Total Revenue</p>
                    <p className="text-xl font-bold text-green-400">{formatMoney(totalRevenue)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Film className="w-8 h-8 text-blue-400" />
                  <div>
                    <p className="text-sm text-gray-400">Total Projects</p>
                    <p className="text-xl font-bold text-blue-400">{projects.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-yellow-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Star className="w-8 h-8 text-yellow-400" />
                  <div>
                    <p className="text-sm text-gray-400">Reputation</p>
                    <p className="text-xl font-bold text-yellow-400">{studioData?.reputation || 50}/100</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-purple-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-8 h-8 text-purple-400" />
                  <div>
                    <p className="text-sm text-gray-400">Profit Margin</p>
                    <p className={`text-xl font-bold ${profitMargin >= 0 ? "text-green-400" : "text-red-400"}`}>
                      {profitMargin.toFixed(1)}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Studio Progress</CardTitle>
                <CardDescription>Your journey to becoming a legend</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Reputation</span>
                    <span className="text-white">{studioData?.reputation || 50}/100</span>
                  </div>
                  <Progress value={studioData?.reputation || 50} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Experience</span>
                    <span className="text-white">{studioData?.experience || 0}/1000</span>
                  </div>
                  <Progress value={((studioData?.experience || 0) / 1000) * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Market Share</span>
                    <span className="text-white">{((studioData?.reputation || 50) / 10).toFixed(1)}%</span>
                  </div>
                  <Progress value={(studioData?.reputation || 50) / 10} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Recent Achievements</CardTitle>
                <CardDescription>Your latest milestones</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {projects.length > 0 ? (
                  <>
                    <div className="flex items-center gap-3 p-2 bg-green-500/10 rounded border border-green-500/30">
                      <Film className="w-5 h-5 text-green-400" />
                      <div>
                        <p className="text-sm font-medium text-white">First Movie Created</p>
                        <p className="text-xs text-gray-400">Started your studio journey</p>
                      </div>
                    </div>
                    {projects.length >= 5 && (
                      <div className="flex items-center gap-3 p-2 bg-blue-500/10 rounded border border-blue-500/30">
                        <Target className="w-5 h-5 text-blue-400" />
                        <div>
                          <p className="text-sm font-medium text-white">Prolific Creator</p>
                          <p className="text-xs text-gray-400">Created 5+ projects</p>
                        </div>
                      </div>
                    )}
                    {(studioData?.reputation || 50) >= 75 && (
                      <div className="flex items-center gap-3 p-2 bg-yellow-500/10 rounded border border-yellow-500/30">
                        <Star className="w-5 h-5 text-yellow-400" />
                        <div>
                          <p className="text-sm font-medium text-white">Rising Star</p>
                          <p className="text-xs text-gray-400">Reached 75+ reputation</p>
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-4 text-gray-400">
                    <Zap className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No achievements yet. Start creating projects!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="financial" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-black/20 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-green-400 text-lg">Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white mb-2">{formatMoney(totalRevenue)}</div>
                <p className="text-sm text-gray-400">Total earnings from all projects</p>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-red-500/30">
              <CardHeader>
                <CardTitle className="text-red-400 text-lg">Expenses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white mb-2">{formatMoney(totalBudget)}</div>
                <p className="text-sm text-gray-400">Total spent on production</p>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-purple-400 text-lg">Profit</CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`text-2xl font-bold mb-2 ${totalRevenue - totalBudget >= 0 ? "text-green-400" : "text-red-400"}`}
                >
                  {formatMoney(totalRevenue - totalBudget)}
                </div>
                <p className="text-sm text-gray-400">Net profit/loss</p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Budget Allocation</CardTitle>
              <CardDescription>How you spend your money</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-white">Production Costs</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Movies</span>
                      <span className="text-white">{formatMoney(totalBudget * 0.7)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Marketing</span>
                      <span className="text-white">{formatMoney(totalBudget * 0.2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Operations</span>
                      <span className="text-white">{formatMoney(totalBudget * 0.1)}</span>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-white">ROI by Category</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Action Movies</span>
                      <span className="text-green-400">+15%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Comedy Movies</span>
                      <span className="text-green-400">+8%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Drama Movies</span>
                      <span className="text-yellow-400">+2%</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projects" className="space-y-6">
          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Project Performance</CardTitle>
              <CardDescription>How your movies are performing</CardDescription>
            </CardHeader>
            <CardContent>
              {projects.length > 0 ? (
                <div className="space-y-4">
                  {projects.slice(0, 5).map((project: any, index: number) => (
                    <div
                      key={project.id}
                      className="flex items-center justify-between p-3 bg-white/5 rounded border border-white/10"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded flex items-center justify-center text-white font-bold text-sm">
                          {index + 1}
                        </div>
                        <div>
                          <h4 className="font-semibold text-white">{project.title}</h4>
                          <p className="text-sm text-gray-400">
                            {project.genre} • {project.status}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-semibold text-white">{formatMoney(project.budget)}</div>
                        <div className="text-xs text-gray-400">Budget</div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <Film className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No projects yet. Start creating your first movie!</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Genre Performance</CardTitle>
              <CardDescription>Success rate by movie genre</CardDescription>
            </CardHeader>
            <CardContent>
              {Object.keys(genrePerformance).length > 0 ? (
                <div className="space-y-4">
                  {Object.entries(genrePerformance).map(([genre, data]: [string, any]) => (
                    <div key={genre} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-white capitalize">{genre}</span>
                        <span className="text-gray-400">{data.count} projects</span>
                      </div>
                      <Progress value={(data.revenue / Math.max(data.budget, 1)) * 50} className="h-2" />
                      <div className="flex justify-between text-sm text-gray-400">
                        <span>Revenue: {formatMoney(data.revenue)}</span>
                        <span>Budget: {formatMoney(data.budget)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <BarChart3 className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No genre data available yet.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Market Trends</CardTitle>
                <CardDescription>What's hot in the industry</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-white">Superhero Movies</span>
                    <Badge variant="outline" className="text-green-400">
                      Hot
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white">Horror Films</span>
                    <Badge variant="outline" className="text-yellow-400">
                      Rising
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white">Romantic Comedies</span>
                    <Badge variant="outline" className="text-red-400">
                      Declining
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white">Documentaries</span>
                    <Badge variant="outline" className="text-blue-400">
                      Stable
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Recommendations</CardTitle>
                <CardDescription>AI-powered suggestions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-blue-500/10 rounded border border-blue-500/30">
                  <h4 className="font-semibold text-blue-400 mb-1">Focus on Action</h4>
                  <p className="text-sm text-gray-400">Your action movies have 20% higher success rate</p>
                </div>
                <div className="p-3 bg-green-500/10 rounded border border-green-500/30">
                  <h4 className="font-semibold text-green-400 mb-1">Increase Marketing</h4>
                  <p className="text-sm text-gray-400">Higher marketing budgets correlate with better performance</p>
                </div>
                <div className="p-3 bg-yellow-500/10 rounded border border-yellow-500/30">
                  <h4 className="font-semibold text-yellow-400 mb-1">Diversify Genres</h4>
                  <p className="text-sm text-gray-400">Try horror or sci-fi for untapped potential</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
