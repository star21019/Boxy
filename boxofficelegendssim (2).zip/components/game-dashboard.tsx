"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import {
  TrendingUp,
  TrendingDown,
  Users,
  Film,
  Star,
  Trophy,
  AlertTriangle,
  CheckCircle,
  Flame,
  Award,
  Calendar,
  BarChart3,
  Zap,
  MessageSquare,
} from "lucide-react"

interface GameDashboardProps {
  studioData?: any
}

// Logo styles for display
const logoStyles = [
  { id: "modern_gradient", preview: "🎬", style: "bg-gradient-to-r from-purple-500 to-blue-500" },
  { id: "classic_gold", preview: "👑", style: "bg-gradient-to-r from-yellow-400 to-yellow-600" },
  { id: "neon_cyber", preview: "⚡", style: "bg-gradient-to-r from-cyan-400 to-purple-500" },
  { id: "royal_crimson", preview: "🏰", style: "bg-gradient-to-r from-red-600 to-purple-700" },
  { id: "emerald_forest", preview: "🌟", style: "bg-gradient-to-r from-green-500 to-emerald-600" },
  { id: "sunset_orange", preview: "🔥", style: "bg-gradient-to-r from-orange-500 to-red-500" },
  { id: "arctic_blue", preview: "❄️", style: "bg-gradient-to-r from-blue-400 to-cyan-300" },
  { id: "cosmic_purple", preview: "🌌", style: "bg-gradient-to-r from-purple-600 to-indigo-700" },
  { id: "rose_gold", preview: "🌹", style: "bg-gradient-to-r from-pink-400 to-yellow-400" },
  { id: "midnight_black", preview: "🖤", style: "bg-gradient-to-r from-gray-800 to-black" },
  {
    id: "rainbow_prism",
    preview: "🌈",
    style: "bg-gradient-to-r from-red-500 via-yellow-500 via-green-500 via-blue-500 to-purple-500",
  },
  { id: "silver_chrome", preview: "⚙️", style: "bg-gradient-to-r from-gray-300 to-gray-500" },
]

export function GameDashboard({ studioData }: GameDashboardProps) {
  // Get studio logo
  const studioLogo = logoStyles.find((l) => l.id === studioData?.logo) || logoStyles[0]

  const formatMoney = (amount: number) => {
    if (amount >= 1000000000) {
      return `$${(amount / 1000000000).toFixed(1)}B`
    } else if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(1)}K`
    }
    return `$${amount.toLocaleString()}`
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Studio Header */}
      <Card className="bg-black/20 border-purple-500/30">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row items-start lg:items-center gap-6">
            {/* Studio Logo */}
            <div className={`w-16 h-16 rounded-lg flex items-center justify-center flex-shrink-0 ${studioLogo.style}`}>
              <span className="text-2xl">{studioLogo.preview}</span>
            </div>

            {/* Studio Info */}
            <div className="flex-grow">
              <h1 className="text-2xl lg:text-3xl font-bold text-white mb-2">
                {studioData?.name || "Your Studio"} {studioData?.suffix || "Studios"}
              </h1>
              <div className="flex flex-wrap items-center gap-3 mb-3">
                <Badge variant="outline" className="text-sm">
                  {studioData?.type || "Indie Studio"}
                </Badge>
                <div className="flex items-center gap-1 text-gray-400">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">Founded {studioData?.founded || 2024}</span>
                </div>
              </div>
              <p className="text-gray-300 text-sm">
                Welcome to your entertainment empire! Start by creating your first movie project.
              </p>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-xl font-bold text-green-400">{formatMoney(studioData?.money || 25000000)}</div>
                <div className="text-xs text-gray-400">Budget</div>
              </div>
              <div>
                <div className="text-xl font-bold text-yellow-400">{studioData?.reputation || 50}</div>
                <div className="text-xs text-gray-400">Reputation</div>
              </div>
              <div>
                <div className="text-xl font-bold text-purple-400">#{studioData?.globalRank || 247}</div>
                <div className="text-xs text-gray-400">Global Rank</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Studio Performance */}
        <Card className="bg-black/20 border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-blue-400 flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Studio Performance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Key Metrics */}
            <div className="grid grid-cols-2 gap-3">
              <div className="text-center p-3 bg-white/5 rounded-lg">
                <div className="text-lg font-bold text-green-400">0</div>
                <div className="text-xs text-gray-400">Movies Released</div>
              </div>
              <div className="text-center p-3 bg-white/5 rounded-lg">
                <div className="text-lg font-bold text-blue-400">$0</div>
                <div className="text-xs text-gray-400">Total Revenue</div>
              </div>
              <div className="text-center p-3 bg-white/5 rounded-lg">
                <div className="text-lg font-bold text-purple-400">0</div>
                <div className="text-xs text-gray-400">Awards Won</div>
              </div>
              <div className="text-center p-3 bg-white/5 rounded-lg">
                <div className="text-lg font-bold text-yellow-400">12</div>
                <div className="text-xs text-gray-400">Staff Members</div>
              </div>
            </div>

            {/* Current Projects */}
            <div>
              <h4 className="text-sm font-semibold text-white mb-2">Current Projects:</h4>
              <div className="text-center p-4 bg-white/5 rounded-lg border-2 border-dashed border-gray-600">
                <Film className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-400 text-sm">No active projects</p>
                <Button className="mt-2 bg-blue-600 hover:bg-blue-700 text-xs">Start Your First Movie</Button>
              </div>
            </div>

            {/* Industry Standing */}
            <div>
              <h4 className="text-sm font-semibold text-white mb-2">Industry Standing:</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 text-sm">Global Rank</span>
                  <span className="text-white font-bold">#{studioData?.globalRank || 247}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 text-sm">Market Share</span>
                  <span className="text-white font-bold">0.01%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 text-sm">Influence Level</span>
                  <span className="text-gray-400">Minimal</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="bg-black/20 border-green-500/30">
          <CardHeader>
            <CardTitle className="text-green-400 flex items-center gap-2">
              <Zap className="w-5 h-5" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full bg-purple-600 hover:bg-purple-700 justify-start">
              <Film className="w-4 h-4 mr-2" />
              Create New Movie
            </Button>
            <Button className="w-full bg-blue-600 hover:bg-blue-700 justify-start">
              <Users className="w-4 h-4 mr-2" />
              Hire Staff
            </Button>
            <Button className="w-full bg-yellow-600 hover:bg-yellow-700 justify-start">
              <Star className="w-4 h-4 mr-2" />
              Scout Celebrities
            </Button>
            <Button className="w-full bg-red-600 hover:bg-red-700 justify-start">
              <MessageSquare className="w-4 h-4 mr-2" />
              Social Media Campaign
            </Button>
            <Button className="w-full bg-cyan-600 hover:bg-cyan-700 justify-start">
              <Trophy className="w-4 h-4 mr-2" />
              Submit to Awards
            </Button>

            <Separator className="my-4" />

            {/* Notifications */}
            <div>
              <h4 className="text-sm font-semibold text-white mb-2">Notifications:</h4>
              <div className="space-y-2">
                <div className="flex items-start gap-2 p-2 bg-blue-500/10 border border-blue-500/30 rounded">
                  <CheckCircle className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                  <div className="text-xs">
                    <div className="text-blue-300 font-medium">Welcome to Box Office Legends!</div>
                    <div className="text-gray-400">Your studio has been created successfully.</div>
                  </div>
                </div>
                <div className="flex items-start gap-2 p-2 bg-yellow-500/10 border border-yellow-500/30 rounded">
                  <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                  <div className="text-xs">
                    <div className="text-yellow-300 font-medium">Tutorial Available</div>
                    <div className="text-gray-400">Learn the basics of studio management.</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Industry Insights */}
        <Card className="bg-black/20 border-orange-500/30">
          <CardHeader>
            <CardTitle className="text-orange-400 flex items-center gap-2">
              <Flame className="w-5 h-5" />
              Industry Insights
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Trending Genres */}
            <div>
              <h4 className="text-sm font-semibold text-white mb-2">Trending Genres:</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-3 h-3 text-green-400" />
                    <span className="text-sm text-white">Action</span>
                  </div>
                  <span className="text-green-400 text-sm font-bold">85%</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-3 h-3 text-blue-400" />
                    <span className="text-sm text-white">Sci-Fi</span>
                  </div>
                  <span className="text-blue-400 text-sm font-bold">78%</span>
                </div>
                <div className="flex items-center justify-between p-2 bg-white/5 rounded">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="w-3 h-3 text-red-400" />
                    <span className="text-sm text-white">Romance</span>
                  </div>
                  <span className="text-red-400 text-sm font-bold">45%</span>
                </div>
              </div>
            </div>

            {/* Market News */}
            <div>
              <h4 className="text-sm font-semibold text-white mb-2">Market News:</h4>
              <div className="space-y-2">
                <div className="p-2 bg-white/5 rounded text-xs">
                  <div className="text-yellow-400 font-medium">Awards Season Open</div>
                  <div className="text-gray-400">Submissions now being accepted</div>
                </div>
                <div className="p-2 bg-white/5 rounded text-xs">
                  <div className="text-blue-400 font-medium">Celebrity Market Hot</div>
                  <div className="text-gray-400">High demand for A-list talent</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Industry News */}
      <Card className="bg-black/20 border-orange-500/30">
        <CardHeader>
          <CardTitle className="text-orange-400 flex items-center gap-2">
            <Flame className="w-5 h-5" />
            Industry News & Trends
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-3 bg-white/5 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-green-400" />
                <span className="text-sm font-medium text-white">Action Movies</span>
              </div>
              <div className="text-xs text-gray-400">Trending up 15% this month</div>
              <div className="text-lg font-bold text-green-400">Hot 🔥</div>
            </div>
            <div className="p-3 bg-white/5 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="w-4 h-4 text-red-400" />
                <span className="text-sm font-medium text-white">Romantic Comedy</span>
              </div>
              <div className="text-xs text-gray-400">Declining 8% this month</div>
              <div className="text-lg font-bold text-red-400">Cold ❄️</div>
            </div>
            <div className="p-3 bg-white/5 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Star className="w-4 h-4 text-yellow-400" />
                <span className="text-sm font-medium text-white">Sci-Fi</span>
              </div>
              <div className="text-xs text-gray-400">Stable demand</div>
              <div className="text-lg font-bold text-yellow-400">Steady ⚡</div>
            </div>
            <div className="p-3 bg-white/5 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Award className="w-4 h-4 text-purple-400" />
                <span className="text-sm font-medium text-white">Awards Season</span>
              </div>
              <div className="text-xs text-gray-400">Submissions open</div>
              <div className="text-lg font-bold text-purple-400">Active 🏆</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
