"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import Image from "next/image"

interface LoadingScreenProps {
  onComplete: () => void
}

const gameTips = [
  "💡 Start with smaller budget films to build your reputation before attempting blockbusters.",
  "🎬 Choose your genre wisely - some genres are more popular in certain seasons.",
  "⭐ Building relationships with A-list actors early can pay off in future projects.",
  "💰 Marketing budget is just as important as production budget for box office success.",
  "🏆 Awards season campaigns can significantly boost your studio's prestige.",
  "📱 Social media presence can make or break a movie's opening weekend.",
  "🎭 Director-actor chemistry affects the final quality of your films.",
  "🌍 International markets can save a domestic box office flop.",
  "📊 Keep an eye on trending genres to stay ahead of the competition.",
  "🎪 Sometimes taking creative risks pays off more than playing it safe.",
  "💼 Managing your studio's finances is crucial for long-term success.",
  "🎯 Target the right audience for each film to maximize profits.",
  "🔥 Viral marketing campaigns can create massive buzz for your movies.",
  "🎨 Investing in good scripts is the foundation of any successful film.",
  "⚡ Quick decision-making during production can save millions in costs.",
]

export function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [currentTip, setCurrentTip] = useState(0)
  const [loadingText, setLoadingText] = useState("Initializing Studio...")

  useEffect(() => {
    const duration = 12000 // 12 seconds
    const interval = 100 // Update every 100ms
    const increment = 100 / (duration / interval)

    const timer = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + increment

        // Update loading text based on progress
        if (newProgress < 20) {
          setLoadingText("Setting up your studio...")
        } else if (newProgress < 40) {
          setLoadingText("Loading movie database...")
        } else if (newProgress < 60) {
          setLoadingText("Connecting to industry networks...")
        } else if (newProgress < 80) {
          setLoadingText("Preparing your first project...")
        } else if (newProgress < 95) {
          setLoadingText("Almost ready...")
        } else {
          setLoadingText("Welcome to Hollywood!")
        }

        if (newProgress >= 100) {
          clearInterval(timer)
          setTimeout(onComplete, 500)
          return 100
        }
        return newProgress
      })
    }, interval)

    // Change tips every 2 seconds
    const tipTimer = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % gameTips.length)
    }, 2000)

    return () => {
      clearInterval(timer)
      clearInterval(tipTimer)
    }
  }, [onComplete])

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 flex items-center justify-center z-50">
      <Card className="w-full max-w-md mx-4 bg-black/20 border-blue-500/30">
        <CardContent className="p-8 text-center space-y-6">
          {/* Logo */}
          <div className="w-32 h-32 mx-auto relative">
            <Image
              src="/box-office-logo.png"
              alt="Box Office Legends Sim"
              width={128}
              height={128}
              className="animate-pulse"
            />
          </div>

          {/* Title */}
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">BOX OFFICE</h1>
            <h2 className="text-3xl font-bold text-blue-400 mb-2">LEGENDS SIM</h2>
            <p className="text-lg text-gray-300 font-semibold tracking-wider">CREATE, PRODUCE, DOMINATE</p>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <Progress value={progress} className="w-full h-2" />
            <p className="text-sm text-gray-300">{loadingText}</p>
            <p className="text-xs text-gray-400">{Math.round(progress)}%</p>
          </div>

          {/* Game Tip */}
          <div className="bg-white/5 rounded-lg p-4 border border-blue-500/30">
            <h3 className="text-sm font-semibold text-blue-400 mb-2">💡 Game Tip</h3>
            <p className="text-sm text-gray-300 leading-relaxed">{gameTips[currentTip]}</p>
          </div>

          {/* Loading Animation */}
          <div className="flex justify-center space-x-1">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.2}s` }}
              />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
