"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Building2,
  Star,
  Award,
  Edit,
  Save,
  Crown,
  Shield,
  Target,
  TrendingUp,
  Clock,
  DollarSign,
  Film,
  Music,
  Trophy,
} from "lucide-react"

interface StudioProfileProps {
  studioData: any
  onUpdateStudio: (data: any) => void
}

export function StudioProfile({ studioData, onUpdateStudio }: StudioProfileProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editData, setEditData] = useState({
    name: studioData?.name || "",
    suffix: studioData?.suffix || "",
    bio: studioData?.bio || "",
    specialty: studioData?.specialty || "",
    logo: studioData?.logo || "modern_gradient",
  })

  const logoStyles = [
    {
      id: "modern_gradient",
      preview: "🎬",
      style: "bg-gradient-to-r from-purple-500 to-blue-500",
      name: "Modern Gradient",
    },
    {
      id: "classic_gold",
      preview: "👑",
      style: "bg-gradient-to-r from-yellow-400 to-yellow-600",
      name: "Classic Gold",
    },
    { id: "neon_cyber", preview: "⚡", style: "bg-gradient-to-r from-cyan-400 to-purple-500", name: "Neon Cyber" },
    { id: "royal_crimson", preview: "🏰", style: "bg-gradient-to-r from-red-600 to-purple-700", name: "Royal Crimson" },
    {
      id: "emerald_forest",
      preview: "🌟",
      style: "bg-gradient-to-r from-green-500 to-emerald-600",
      name: "Emerald Forest",
    },
    { id: "sunset_orange", preview: "🔥", style: "bg-gradient-to-r from-orange-500 to-red-500", name: "Sunset Orange" },
    { id: "arctic_blue", preview: "❄️", style: "bg-gradient-to-r from-blue-400 to-cyan-300", name: "Arctic Blue" },
    {
      id: "cosmic_purple",
      preview: "🌌",
      style: "bg-gradient-to-r from-purple-600 to-indigo-700",
      name: "Cosmic Purple",
    },
  ]

  const getReputationData = (reputation: number) => {
    if (reputation >= 95)
      return {
        rank: "Legendary",
        icon: <Crown className="w-4 h-4" />,
        color: "text-yellow-400",
        description: "Industry titan with unmatched influence",
        nextRank: "Max level achieved!",
        progress: 100,
      }
    if (reputation >= 85)
      return {
        rank: "Elite",
        icon: <Star className="w-4 h-4" />,
        color: "text-purple-400",
        description: "Top-tier studio with global recognition",
        nextRank: "10 points to Legendary",
        progress: ((reputation - 85) / 10) * 100,
      }
    if (reputation >= 75)
      return {
        rank: "Established",
        icon: <Shield className="w-4 h-4" />,
        color: "text-blue-400",
        description: "Well-respected industry player",
        nextRank: "10 points to Elite",
        progress: ((reputation - 75) / 10) * 100,
      }
    if (reputation >= 60)
      return {
        rank: "Rising",
        icon: <TrendingUp className="w-4 h-4" />,
        color: "text-green-400",
        description: "Growing studio with potential",
        nextRank: "15 points to Established",
        progress: ((reputation - 60) / 15) * 100,
      }
    if (reputation >= 40)
      return {
        rank: "Developing",
        icon: <Target className="w-4 h-4" />,
        color: "text-yellow-400",
        description: "Building foundation and credibility",
        nextRank: "20 points to Rising",
        progress: ((reputation - 40) / 20) * 100,
      }
    return {
      rank: "Newcomer",
      icon: <Clock className="w-4 h-4" />,
      color: "text-gray-400",
      description: "Just starting the journey",
      nextRank: "40 points to Developing",
      progress: (reputation / 40) * 100,
    }
  }

  const formatMoney = (amount: number) => {
    if (amount >= 1000000000) {
      return `$${(amount / 1000000000).toFixed(1)}B`
    } else if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(1)}M`
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(0)}K`
    }
    return `$${amount.toLocaleString()}`
  }

  const handleSave = () => {
    onUpdateStudio(editData)
    setIsEditing(false)
  }

  const reputation = studioData?.reputation || 50
  const repData = getReputationData(reputation)
  const selectedLogo = logoStyles.find((l) => l.id === editData.logo) || logoStyles[0]

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <Card className="bg-black/20 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-purple-400 flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            Studio Profile
          </CardTitle>
          <CardDescription className="text-gray-300">Manage your studio's identity and reputation</CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="customize">Customize</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Studio Info */}
            <Card className="bg-black/20 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-blue-400">Studio Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-lg flex items-center justify-center ${selectedLogo.style}`}>
                    <span className="text-2xl">{selectedLogo.preview}</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">
                      {studioData?.name || "Your Studio"} {studioData?.suffix || "Studios"}
                    </h3>
                    <div className={`flex items-center gap-1 ${repData.color}`}>
                      {repData.icon}
                      <span className="text-sm">{repData.rank} Studio</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Founded:</span>
                    <span className="text-white">{studioData?.founded || 2024}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Type:</span>
                    <Badge variant="outline">{studioData?.type || "Indie"}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Specialty:</span>
                    <span className="text-white">{studioData?.specialty || "General Entertainment"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Level:</span>
                    <span className="text-purple-400">Level {studioData?.level || 1}</span>
                  </div>
                </div>

                {studioData?.bio && (
                  <div className="p-3 bg-white/5 rounded-lg">
                    <h4 className="text-sm font-semibold text-white mb-1">Studio Bio</h4>
                    <p className="text-gray-300 text-sm">{studioData.bio}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Reputation Details */}
            <Card className="bg-black/20 border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-yellow-400">Reputation System</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-4xl font-bold text-yellow-400 mb-2">{reputation}</div>
                  <div className={`flex items-center justify-center gap-2 ${repData.color} mb-2`}>
                    {repData.icon}
                    <span className="font-semibold">{repData.rank}</span>
                  </div>
                  <p className="text-gray-400 text-sm">{repData.description}</p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Progress to next rank:</span>
                    <span className="text-white">{repData.nextRank}</span>
                  </div>
                  <Progress value={repData.progress} className="h-2" />
                </div>

                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-white">Reputation Factors:</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2 bg-white/5 rounded">
                      <div className="text-green-400">Movie Success</div>
                      <div className="text-gray-400">+1 to +15</div>
                    </div>
                    <div className="p-2 bg-white/5 rounded">
                      <div className="text-red-400">Movie Failure</div>
                      <div className="text-gray-400">-3 to -12</div>
                    </div>
                    <div className="p-2 bg-white/5 rounded">
                      <div className="text-yellow-400">Award Win</div>
                      <div className="text-gray-400">+5 to +20</div>
                    </div>
                    <div className="p-2 bg-white/5 rounded">
                      <div className="text-purple-400">Staff Quality</div>
                      <div className="text-gray-400">+1 to +5</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Studio Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-black/20 border-green-500/30">
              <CardContent className="p-4 text-center">
                <DollarSign className="w-8 h-8 text-green-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-green-400">{formatMoney(studioData?.money || 25000000)}</div>
                <div className="text-sm text-gray-400">Total Budget</div>
              </CardContent>
            </Card>
            <Card className="bg-black/20 border-blue-500/30">
              <CardContent className="p-4 text-center">
                <Film className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-blue-400">{studioData?.movies?.length || 0}</div>
                <div className="text-sm text-gray-400">Movies Created</div>
              </CardContent>
            </Card>
            <Card className="bg-black/20 border-purple-500/30">
              <CardContent className="p-4 text-center">
                <Music className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-purple-400">{studioData?.music?.length || 0}</div>
                <div className="text-sm text-gray-400">Music Projects</div>
              </CardContent>
            </Card>
            <Card className="bg-black/20 border-yellow-500/30">
              <CardContent className="p-4 text-center">
                <Trophy className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-yellow-400">{studioData?.awards || 0}</div>
                <div className="text-sm text-gray-400">Awards Won</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card className="bg-black/20 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400">Studio Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-white/5 rounded-lg border-l-4 border-green-500">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-semibold text-white">Studio Founded</h4>
                      <p className="text-gray-400 text-sm">Your entertainment empire begins</p>
                    </div>
                    <Badge variant="outline" className="text-green-400">
                      {studioData?.founded || 2024}
                    </Badge>
                  </div>
                </div>

                {studioData?.movies?.length > 0 && (
                  <div className="p-4 bg-white/5 rounded-lg border-l-4 border-blue-500">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold text-white">First Movie Created</h4>
                        <p className="text-gray-400 text-sm">{studioData.movies[0].title}</p>
                      </div>
                      <Badge variant="outline" className="text-blue-400">
                        Recent
                      </Badge>
                    </div>
                  </div>
                )}

                {(studioData?.staff?.length || 0) > 0 && (
                  <div className="p-4 bg-white/5 rounded-lg border-l-4 border-purple-500">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold text-white">Staff Hired</h4>
                        <p className="text-gray-400 text-sm">Building your team</p>
                      </div>
                      <Badge variant="outline" className="text-purple-400">
                        {studioData.staff.length} members
                      </Badge>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-4">
          <Card className="bg-black/20 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-yellow-400">Achievement Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Trophy className="w-5 h-5 text-green-400" />
                    <span className="font-semibold text-green-400">First Steps</span>
                    <Badge variant="outline" className="text-green-400">
                      Unlocked
                    </Badge>
                  </div>
                  <p className="text-gray-300 text-sm">Create your first studio</p>
                  <div className="text-green-400 text-xs mt-1">+50 points</div>
                </div>

                <div className="p-4 bg-white/5 border border-white/10 rounded-lg opacity-50">
                  <div className="flex items-center gap-2 mb-2">
                    <Film className="w-5 h-5 text-gray-400" />
                    <span className="font-semibold text-gray-400">Movie Maker</span>
                    <Badge variant="outline" className="text-gray-400">
                      Locked
                    </Badge>
                  </div>
                  <p className="text-gray-400 text-sm">Create your first movie</p>
                  <div className="text-gray-400 text-xs mt-1">+100 points</div>
                </div>

                <div className="p-4 bg-white/5 border border-white/10 rounded-lg opacity-50">
                  <div className="flex items-center gap-2 mb-2">
                    <Star className="w-5 h-5 text-gray-400" />
                    <span className="font-semibold text-gray-400">Rising Star</span>
                    <Badge variant="outline" className="text-gray-400">
                      Locked
                    </Badge>
                  </div>
                  <p className="text-gray-400 text-sm">Reach 75 reputation</p>
                  <div className="text-gray-400 text-xs mt-1">+200 points</div>
                </div>

                <div className="p-4 bg-white/5 border border-white/10 rounded-lg opacity-50">
                  <div className="flex items-center gap-2 mb-2">
                    <Award className="w-5 h-5 text-gray-400" />
                    <span className="font-semibold text-gray-400">Award Winner</span>
                    <Badge variant="outline" className="text-gray-400">
                      Locked
                    </Badge>
                  </div>
                  <p className="text-gray-400 text-sm">Win your first award</p>
                  <div className="text-gray-400 text-xs mt-1">+300 points</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customize" className="space-y-4">
          <Card className="bg-black/20 border-purple-500/30">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-purple-400">Customize Studio</CardTitle>
                <Button onClick={() => setIsEditing(!isEditing)} variant="outline" className="border-purple-500/30">
                  <Edit className="w-4 h-4 mr-2" />
                  {isEditing ? "Cancel" : "Edit"}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {isEditing ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-white">Studio Name</label>
                      <Input
                        value={editData.name}
                        onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                        placeholder="Enter studio name..."
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-white">Suffix</label>
                      <Select
                        value={editData.suffix}
                        onValueChange={(value) => setEditData({ ...editData, suffix: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Studios">Studios</SelectItem>
                          <SelectItem value="Entertainment">Entertainment</SelectItem>
                          <SelectItem value="Pictures">Pictures</SelectItem>
                          <SelectItem value="Films">Films</SelectItem>
                          <SelectItem value="Media">Media</SelectItem>
                          <SelectItem value="Productions">Productions</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Specialty</label>
                    <Input
                      value={editData.specialty}
                      onChange={(e) => setEditData({ ...editData, specialty: e.target.value })}
                      placeholder="e.g., Action Movies, Indie Films, Music Production..."
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Studio Bio</label>
                    <Textarea
                      value={editData.bio}
                      onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                      placeholder="Tell the world about your studio's vision and mission..."
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Logo Style</label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {logoStyles.map((logo) => (
                        <div
                          key={logo.id}
                          className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                            editData.logo === logo.id
                              ? "border-purple-400 bg-purple-500/10"
                              : "border-white/10 hover:border-purple-500/50"
                          }`}
                          onClick={() => setEditData({ ...editData, logo: logo.id })}
                        >
                          <div
                            className={`w-12 h-12 rounded-lg flex items-center justify-center ${logo.style} mx-auto mb-2`}
                          >
                            <span className="text-xl">{logo.preview}</span>
                          </div>
                          <div className="text-xs text-center text-white">{logo.name}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button onClick={handleSave} className="w-full bg-purple-600 hover:bg-purple-700">
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </Button>
                </>
              ) : (
                <div className="text-center py-8">
                  <div
                    className={`w-24 h-24 rounded-lg flex items-center justify-center ${selectedLogo.style} mx-auto mb-4`}
                  >
                    <span className="text-4xl">{selectedLogo.preview}</span>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">
                    {studioData?.name || "Your Studio"} {studioData?.suffix || "Studios"}
                  </h3>
                  <p className="text-gray-400 mb-4">{selectedLogo.name} Style</p>
                  <Badge variant="outline" className={repData.color}>
                    {repData.rank} Studio
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
