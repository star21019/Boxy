"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { InfluencerDatabase, type Influencer } from "@/lib/influencer/influencer-database"
import { CampaignManager, type CampaignProposal, type ActiveCampaign } from "@/lib/influencer/campaign-manager"
import {
  Users,
  Star,
  DollarSign,
  TrendingUp,
  Target,
  CheckCircle,
  XCircle,
  Eye,
  Award,
  Handshake,
  BarChart3,
  Filter,
  Search,
  Send,
  Play,
} from "lucide-react"

interface InfluencerPartnershipDashboardProps {
  movieData: {
    title: string
    genre: string
    budget: number
    target_audience: { age: string; gender: string; location: string }
    release_date: Date
    marketing_budget: number
  }
  studioReputation: number
}

export function InfluencerPartnershipDashboard({ movieData, studioReputation }: InfluencerPartnershipDashboardProps) {
  const [influencerDB] = useState(() => new InfluencerDatabase())
  const [campaignManager] = useState(() => new CampaignManager())
  const [selectedTab, setSelectedTab] = useState("discover")
  const [influencers, setInfluencers] = useState<Influencer[]>([])
  const [activeCampaigns, setActiveCampaigns] = useState<ActiveCampaign[]>([])
  const [selectedInfluencer, setSelectedInfluencer] = useState<Influencer | null>(null)
  const [campaignProposal, setCampaignProposal] = useState<CampaignProposal | null>(null)
  const [filters, setFilters] = useState({
    platform: "",
    tier: "",
    category: "",
    min_followers: "",
    max_budget: "",
  })

  useEffect(() => {
    loadInfluencers()
    loadActiveCampaigns()
  }, [])

  const loadInfluencers = () => {
    const filterObj = {
      platform: filters.platform || undefined,
      tier: filters.tier || undefined,
      category: filters.category || undefined,
      min_followers: filters.min_followers ? Number.parseInt(filters.min_followers) : undefined,
      max_budget: filters.max_budget ? Number.parseInt(filters.max_budget) : undefined,
      genre_affinity: movieData.genre,
    }
    setInfluencers(influencerDB.getInfluencers(filterObj))
  }

  const loadActiveCampaigns = () => {
    setActiveCampaigns(campaignManager.getActiveCampaigns())
  }

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
    return num.toString()
  }

  const formatMoney = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const getTierColor = (tier: string) => {
    switch (tier) {
      case "celebrity":
        return "text-purple-400 border-purple-500/30"
      case "mega":
        return "text-red-400 border-red-500/30"
      case "macro":
        return "text-blue-400 border-blue-500/30"
      case "micro":
        return "text-green-400 border-green-500/30"
      case "nano":
        return "text-yellow-400 border-yellow-500/30"
      default:
        return "text-gray-400 border-gray-500/30"
    }
  }

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "instagram":
        return "📷"
      case "tiktok":
        return "🎵"
      case "youtube":
        return "📺"
      case "twitter":
        return "🐦"
      case "twitch":
        return "🎮"
      default:
        return "📱"
    }
  }

  const createCampaignProposal = (influencer: Influencer) => {
    const proposal = campaignManager.createCampaignProposal(influencer, movieData, {
      primary_goal: "awareness",
      budget: Math.min(movieData.marketing_budget * 0.3, influencer.pricing.base_rate * 1.2),
      duration_days: 14,
      urgency: "medium",
    })
    setCampaignProposal(proposal)
    setSelectedInfluencer(influencer)
  }

  const sendProposal = () => {
    if (!campaignProposal || !selectedInfluencer) return

    const response = campaignManager.simulateNegotiation(campaignProposal, selectedInfluencer)

    if (response.status === "accepted") {
      const campaign = campaignManager.launchCampaign(campaignProposal, selectedInfluencer)
      setActiveCampaigns([...activeCampaigns, campaign])
      alert("🎉 Campaign accepted! The influencer is excited to work with you.")
    } else if (response.status === "counter_offer") {
      alert(
        `💬 Counter offer received!\n\nConcerns: ${response.influencer_concerns.join(", ")}\n\nAcceptance probability: ${response.acceptance_probability}%`,
      )
    } else {
      alert(`❌ Proposal rejected.\n\nReasons: ${response.influencer_concerns.join(", ")}`)
    }

    setCampaignProposal(null)
    setSelectedInfluencer(null)
  }

  const simulateCampaignProgress = (campaignId: string) => {
    campaignManager.simulateCampaignProgress(campaignId, Math.floor(Math.random() * 7) + 1)
    loadActiveCampaigns()
  }

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-black/20 border-purple-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-purple-400 flex items-center gap-2 text-sm">
              <DollarSign className="w-4 h-4" />
              Marketing Budget
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{formatMoney(movieData.marketing_budget)}</div>
            <p className="text-xs text-gray-300">Available for influencer campaigns</p>
          </CardContent>
        </Card>

        <Card className="bg-black/20 border-blue-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-blue-400 flex items-center gap-2 text-sm">
              <Users className="w-4 h-4" />
              Active Campaigns
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{activeCampaigns.length}</div>
            <p className="text-xs text-gray-300">Currently running</p>
          </CardContent>
        </Card>

        <Card className="bg-black/20 border-green-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-green-400 flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4" />
              Total Reach
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {formatNumber(activeCampaigns.reduce((sum, c) => sum + c.progress.reach_achieved, 0))}
            </div>
            <p className="text-xs text-gray-300">Across all campaigns</p>
          </CardContent>
        </Card>

        <Card className="bg-black/20 border-yellow-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-yellow-400 flex items-center gap-2 text-sm">
              <Star className="w-4 h-4" />
              Studio Reputation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{studioReputation}/100</div>
            <Progress value={studioReputation} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Main Dashboard */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="discover">Discover Influencers</TabsTrigger>
          <TabsTrigger value="campaigns">Active Campaigns</TabsTrigger>
          <TabsTrigger value="proposals">Proposals</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Discover Influencers Tab */}
        <TabsContent value="discover" className="space-y-4">
          {/* Filters */}
          <Card className="bg-black/20 border-gray-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Filter Influencers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <Select value={filters.platform} onValueChange={(value) => setFilters({ ...filters, platform: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Platform" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Platforms</SelectItem>
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="tiktok">TikTok</SelectItem>
                    <SelectItem value="youtube">YouTube</SelectItem>
                    <SelectItem value="twitter">Twitter</SelectItem>
                    <SelectItem value="twitch">Twitch</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filters.tier} onValueChange={(value) => setFilters({ ...filters, tier: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Tier" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Tiers</SelectItem>
                    <SelectItem value="celebrity">Celebrity</SelectItem>
                    <SelectItem value="mega">Mega</SelectItem>
                    <SelectItem value="macro">Macro</SelectItem>
                    <SelectItem value="micro">Micro</SelectItem>
                    <SelectItem value="nano">Nano</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filters.category} onValueChange={(value) => setFilters({ ...filters, category: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All Categories</SelectItem>
                    <SelectItem value="entertainment">Entertainment</SelectItem>
                    <SelectItem value="lifestyle">Lifestyle</SelectItem>
                    <SelectItem value="gaming">Gaming</SelectItem>
                    <SelectItem value="fashion">Fashion</SelectItem>
                    <SelectItem value="comedy">Comedy</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  placeholder="Min Followers"
                  value={filters.min_followers}
                  onChange={(e) => setFilters({ ...filters, min_followers: e.target.value })}
                />

                <Button onClick={loadInfluencers} className="bg-gradient-to-r from-purple-500 to-blue-500">
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Influencer Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {influencers.slice(0, 12).map((influencer) => (
              <Card
                key={influencer.id}
                className="bg-black/20 border-white/10 hover:border-purple-500/50 transition-colors"
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center text-2xl">
                        {getPlatformIcon(influencer.platform)}
                      </div>
                      <div>
                        <h3 className="font-bold text-white">{influencer.name}</h3>
                        <p className="text-sm text-gray-400">{influencer.handle}</p>
                      </div>
                    </div>
                    <Badge className={`capitalize ${getTierColor(influencer.tier)}`}>{influencer.tier}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-white font-semibold">{formatNumber(influencer.followers)}</div>
                      <div className="text-gray-400">Followers</div>
                    </div>
                    <div>
                      <div className="text-white font-semibold">{influencer.engagement_rate.toFixed(1)}%</div>
                      <div className="text-gray-400">Engagement</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Authenticity</span>
                      <span className="text-white">{influencer.authenticity_score}/100</span>
                    </div>
                    <Progress value={influencer.authenticity_score} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">{movieData.genre} Affinity</span>
                      <span className="text-white">
                        {influencer.relationships.genre_affinity[movieData.genre] || 50}/100
                      </span>
                    </div>
                    <Progress value={influencer.relationships.genre_affinity[movieData.genre] || 50} className="h-2" />
                  </div>

                  <div className="pt-2 border-t border-white/10">
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-bold text-green-400">
                        {formatMoney(influencer.pricing.base_rate)}
                      </span>
                      <Button
                        size="sm"
                        onClick={() => createCampaignProposal(influencer)}
                        className="bg-gradient-to-r from-green-500 to-blue-500"
                      >
                        <Handshake className="w-4 h-4 mr-1" />
                        Partner
                      </Button>
                    </div>
                  </div>

                  {/* Special Abilities */}
                  {influencer.special_abilities.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {influencer.special_abilities.slice(0, 2).map((ability) => (
                        <Badge key={ability} variant="outline" className="text-xs">
                          {ability.replace("_", " ")}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Active Campaigns Tab */}
        <TabsContent value="campaigns" className="space-y-4">
          {activeCampaigns.length === 0 ? (
            <Card className="bg-black/20 border-gray-500/30">
              <CardContent className="p-8 text-center">
                <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Active Campaigns</h3>
                <p className="text-gray-400">Start by discovering and partnering with influencers!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {activeCampaigns.map((campaign) => (
                <Card key={campaign.id} className="bg-black/20 border-blue-500/30">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-blue-400 flex items-center gap-2">
                          <Users className="w-5 h-5" />
                          {campaign.influencer.name} Partnership
                        </CardTitle>
                        <CardDescription className="text-gray-300">
                          {campaign.proposal.campaign_type.replace("_", " ")} • {campaign.influencer.platform}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge
                          variant={
                            campaign.status === "completed"
                              ? "default"
                              : campaign.status === "active"
                                ? "secondary"
                                : "outline"
                          }
                          className="capitalize"
                        >
                          {campaign.status}
                        </Badge>
                        <Button
                          size="sm"
                          onClick={() => simulateCampaignProgress(campaign.id)}
                          className="bg-gradient-to-r from-purple-500 to-blue-500"
                        >
                          <Play className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Progress Overview */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-white">
                          {campaign.progress.posts_delivered}/{campaign.proposal.content_requirements.post_count}
                        </div>
                        <div className="text-sm text-gray-400">Posts Delivered</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-white">
                          {formatNumber(campaign.progress.reach_achieved)}
                        </div>
                        <div className="text-sm text-gray-400">Reach</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-white">
                          {formatNumber(campaign.progress.engagement_generated)}
                        </div>
                        <div className="text-sm text-gray-400">Engagement</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-white">{campaign.progress.sentiment_score}/100</div>
                        <div className="text-sm text-gray-400">Sentiment</div>
                      </div>
                    </div>

                    {/* Performance Metrics */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-3 bg-white/5 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <Eye className="w-4 h-4 text-blue-400" />
                          <span className="text-sm text-gray-400">Impressions</span>
                        </div>
                        <div className="text-lg font-bold text-white">
                          {formatNumber(campaign.performance_metrics.impressions)}
                        </div>
                      </div>
                      <div className="p-3 bg-white/5 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <Target className="w-4 h-4 text-green-400" />
                          <span className="text-sm text-gray-400">Conversions</span>
                        </div>
                        <div className="text-lg font-bold text-white">{campaign.performance_metrics.conversions}</div>
                      </div>
                      <div className="p-3 bg-white/5 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <TrendingUp className="w-4 h-4 text-purple-400" />
                          <span className="text-sm text-gray-400">ROI</span>
                        </div>
                        <div className="text-lg font-bold text-white">
                          {campaign.performance_metrics.roi.toFixed(1)}%
                        </div>
                      </div>
                    </div>

                    {/* Timeline and Quality */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-400">Timeline Adherence</span>
                          <span className="text-white">{campaign.timeline_adherence}%</span>
                        </div>
                        <Progress value={campaign.timeline_adherence} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-400">Content Quality</span>
                          <span className="text-white">{campaign.content_quality_score}/100</span>
                        </div>
                        <Progress value={campaign.content_quality_score} className="h-2" />
                      </div>
                    </div>

                    {/* Campaign Details */}
                    <div className="pt-4 border-t border-white/10">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-400">Investment: </span>
                          <span className="text-white font-semibold">
                            {formatMoney(campaign.proposal.compensation.base_payment)}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-400">Duration: </span>
                          <span className="text-white">
                            {Math.floor(
                              (campaign.proposal.timeline.end_date.getTime() -
                                campaign.proposal.timeline.start_date.getTime()) /
                                (24 * 60 * 60 * 1000),
                            )}{" "}
                            days
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Proposals Tab */}
        <TabsContent value="proposals" className="space-y-4">
          {campaignProposal && selectedInfluencer ? (
            <Card className="bg-black/20 border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-yellow-400 flex items-center gap-2">
                  <Send className="w-5 h-5" />
                  Campaign Proposal for {selectedInfluencer.name}
                </CardTitle>
                <CardDescription className="text-gray-300">Review and send your partnership proposal</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Proposal Overview */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-white/5 rounded-lg">
                    <h4 className="font-semibold text-white mb-2">Campaign Type</h4>
                    <p className="text-gray-300 capitalize">{campaignProposal.campaign_type.replace("_", " ")}</p>
                  </div>
                  <div className="p-4 bg-white/5 rounded-lg">
                    <h4 className="font-semibold text-white mb-2">Investment</h4>
                    <p className="text-green-400 font-bold">
                      {formatMoney(campaignProposal.compensation.base_payment)}
                    </p>
                  </div>
                  <div className="p-4 bg-white/5 rounded-lg">
                    <h4 className="font-semibold text-white mb-2">Duration</h4>
                    <p className="text-blue-400">
                      {Math.floor(
                        (campaignProposal.timeline.end_date.getTime() -
                          campaignProposal.timeline.start_date.getTime()) /
                          (24 * 60 * 60 * 1000),
                      )}{" "}
                      days
                    </p>
                  </div>
                </div>

                {/* Content Requirements */}
                <div className="p-4 bg-white/5 rounded-lg">
                  <h4 className="font-semibold text-white mb-3">Content Requirements</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-400 mb-1">Posts Required</p>
                      <p className="text-white">{campaignProposal.content_requirements.post_count}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-400 mb-1">Creative Freedom</p>
                      <div className="flex items-center gap-2">
                        <Progress value={campaignProposal.content_requirements.creative_freedom} className="flex-1" />
                        <span className="text-white text-sm">
                          {campaignProposal.content_requirements.creative_freedom}%
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <p className="text-sm text-gray-400 mb-1">Required Hashtags</p>
                    <div className="flex flex-wrap gap-2">
                      {campaignProposal.content_requirements.hashtags_required.map((hashtag, index) => (
                        <Badge key={index} variant="outline" className="text-blue-400">
                          {hashtag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Performance Bonuses */}
                <div className="p-4 bg-white/5 rounded-lg">
                  <h4 className="font-semibold text-white mb-3">Performance Bonuses</h4>
                  <div className="space-y-2">
                    {campaignProposal.compensation.performance_bonuses.map((bonus, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-gray-300 capitalize">{bonus.metric.replace("_", " ")}</span>
                        <div className="text-right">
                          <div className="text-green-400 font-semibold">{formatMoney(bonus.bonus)}</div>
                          <div className="text-xs text-gray-400">if {formatNumber(bonus.threshold)}+ achieved</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Additional Perks */}
                {campaignProposal.compensation.additional_perks.length > 0 && (
                  <div className="p-4 bg-white/5 rounded-lg">
                    <h4 className="font-semibold text-white mb-3">Additional Perks</h4>
                    <div className="space-y-1">
                      {campaignProposal.compensation.additional_perks.map((perk, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-400" />
                          <span className="text-gray-300">{perk}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-4">
                  <Button onClick={sendProposal} className="bg-gradient-to-r from-green-500 to-blue-500 flex-1">
                    <Send className="w-4 h-4 mr-2" />
                    Send Proposal
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setCampaignProposal(null)
                      setSelectedInfluencer(null)
                    }}
                    className="border-red-500/30 text-red-400"
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-black/20 border-gray-500/30">
              <CardContent className="p-8 text-center">
                <Send className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Active Proposals</h3>
                <p className="text-gray-400">
                  Create a proposal by partnering with an influencer from the Discover tab!
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          {activeCampaigns.length > 0 ? (
            <>
              {/* Overall Performance */}
              <Card className="bg-black/20 border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-purple-400 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Overall Campaign Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white">
                        {formatMoney(activeCampaigns.reduce((sum, c) => sum + c.proposal.compensation.base_payment, 0))}
                      </div>
                      <div className="text-sm text-gray-400">Total Investment</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white">
                        {formatNumber(activeCampaigns.reduce((sum, c) => sum + c.progress.reach_achieved, 0))}
                      </div>
                      <div className="text-sm text-gray-400">Total Reach</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white">
                        {formatNumber(activeCampaigns.reduce((sum, c) => sum + c.progress.engagement_generated, 0))}
                      </div>
                      <div className="text-sm text-gray-400">Total Engagement</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-white">
                        {activeCampaigns.length > 0
                          ? (
                              activeCampaigns.reduce((sum, c) => sum + c.performance_metrics.roi, 0) /
                              activeCampaigns.length
                            ).toFixed(1)
                          : 0}
                        %
                      </div>
                      <div className="text-sm text-gray-400">Average ROI</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Platform Performance */}
              <Card className="bg-black/20 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-400">Platform Performance Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(
                      activeCampaigns.reduce(
                        (acc, campaign) => {
                          const platform = campaign.influencer.platform
                          if (!acc[platform]) {
                            acc[platform] = {
                              campaigns: 0,
                              reach: 0,
                              engagement: 0,
                              investment: 0,
                              roi: 0,
                            }
                          }
                          acc[platform].campaigns += 1
                          acc[platform].reach += campaign.progress.reach_achieved
                          acc[platform].engagement += campaign.progress.engagement_generated
                          acc[platform].investment += campaign.proposal.compensation.base_payment
                          acc[platform].roi += campaign.performance_metrics.roi
                          return acc
                        },
                        {} as Record<string, any>,
                      ),
                    ).map(([platform, stats]) => (
                      <div key={platform} className="p-4 bg-white/5 rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{getPlatformIcon(platform)}</span>
                            <h4 className="font-semibold text-white capitalize">{platform}</h4>
                          </div>
                          <Badge variant="outline">{stats.campaigns} campaigns</Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <div className="text-white font-semibold">{formatNumber(stats.reach)}</div>
                            <div className="text-gray-400">Reach</div>
                          </div>
                          <div>
                            <div className="text-white font-semibold">{formatNumber(stats.engagement)}</div>
                            <div className="text-gray-400">Engagement</div>
                          </div>
                          <div>
                            <div className="text-white font-semibold">{formatMoney(stats.investment)}</div>
                            <div className="text-gray-400">Investment</div>
                          </div>
                          <div>
                            <div className="text-white font-semibold">{(stats.roi / stats.campaigns).toFixed(1)}%</div>
                            <div className="text-gray-400">Avg ROI</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Top Performing Campaigns */}
              <Card className="bg-black/20 border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-green-400 flex items-center gap-2">
                    <Award className="w-5 h-5" />
                    Top Performing Campaigns
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {activeCampaigns
                      .sort((a, b) => b.performance_metrics.roi - a.performance_metrics.roi)
                      .slice(0, 5)
                      .map((campaign, index) => (
                        <div key={campaign.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center text-sm font-bold">
                              #{index + 1}
                            </div>
                            <div>
                              <h4 className="font-semibold text-white">{campaign.influencer.name}</h4>
                              <p className="text-sm text-gray-400 capitalize">
                                {campaign.proposal.campaign_type.replace("_", " ")} • {campaign.influencer.platform}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold text-green-400">
                              {campaign.performance_metrics.roi.toFixed(1)}% ROI
                            </div>
                            <div className="text-sm text-gray-400">
                              {formatNumber(campaign.progress.reach_achieved)} reach
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card className="bg-black/20 border-gray-500/30">
              <CardContent className="p-8 text-center">
                <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">No Analytics Available</h3>
                <p className="text-gray-400">Start some campaigns to see performance analytics!</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
