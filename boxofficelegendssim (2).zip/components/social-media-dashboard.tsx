"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { SocialMediaEngine, type SocialMediaPost, type TrendingTopic } from "@/lib/ai/social-media-engine"
import {
  Twitter,
  Instagram,
  Youtube,
  Heart,
  MessageCircle,
  Share,
  Eye,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Zap,
  Users,
  BarChart3,
  Play,
  Hash,
  Verified,
  Bot,
  Star,
  ThumbsUp,
  ThumbsDown,
  Meh,
} from "lucide-react"

interface SocialMediaDashboardProps {
  movieData: {
    title: string
    actor: string
    director: string
    genre: string
    budget: number
    boxOffice: number
    rating: number
    awards: number
    scandals: number
    weeksSinceRelease: number
    marketingBudget: number
  }
}

export function SocialMediaDashboard({ movieData }: SocialMediaDashboardProps) {
  const [socialEngine] = useState(() => new SocialMediaEngine())
  const [posts, setPosts] = useState<SocialMediaPost[]>([])
  const [metrics, setMetrics] = useState<any>(null)
  const [trending, setTrending] = useState<TrendingTopic[]>([])
  const [selectedPlatform, setSelectedPlatform] = useState("all")
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    generateBuzz()
  }, [movieData])

  const generateBuzz = async () => {
    setIsLoading(true)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const result = socialEngine.generateMovieBuzz(movieData)
    setPosts(result.posts)
    setMetrics(result.metrics)
    setTrending(result.trending)
    setIsLoading(false)
  }

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "twitter":
        return <Twitter className="w-4 h-4" />
      case "tiktok":
        return <Play className="w-4 h-4" />
      case "instagram":
        return <Instagram className="w-4 h-4" />
      case "youtube":
        return <Youtube className="w-4 h-4" />
      case "reddit":
        return <MessageCircle className="w-4 h-4" />
      default:
        return <Hash className="w-4 h-4" />
    }
  }

  const getPlatformColor = (platform: string) => {
    switch (platform) {
      case "twitter":
        return "text-blue-400 border-blue-500/30"
      case "tiktok":
        return "text-pink-400 border-pink-500/30"
      case "instagram":
        return "text-purple-400 border-purple-500/30"
      case "youtube":
        return "text-red-400 border-red-500/30"
      case "reddit":
        return "text-orange-400 border-orange-500/30"
      default:
        return "text-gray-400 border-gray-500/30"
    }
  }

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return <ThumbsUp className="w-4 h-4 text-green-400" />
      case "negative":
        return <ThumbsDown className="w-4 h-4 text-red-400" />
      case "controversial":
        return <AlertTriangle className="w-4 h-4 text-yellow-400" />
      default:
        return <Meh className="w-4 h-4 text-gray-400" />
    }
  }

  const getAuthorTypeIcon = (type: string) => {
    switch (type) {
      case "influencer":
        return <Star className="w-3 h-3 text-yellow-400" />
      case "critic":
        return <BarChart3 className="w-3 h-3 text-blue-400" />
      case "celebrity":
        return <Verified className="w-3 h-3 text-purple-400" />
      case "bot":
        return <Bot className="w-3 h-3 text-gray-400" />
      default:
        return <Users className="w-3 h-3 text-gray-400" />
    }
  }

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
    return num.toString()
  }

  const filteredPosts = selectedPlatform === "all" ? posts : posts.filter((post) => post.platform === selectedPlatform)

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card className="bg-black/20 border-purple-500/30">
          <CardContent className="p-8 text-center">
            <div className="animate-spin w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-white">Analyzing social media buzz...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Social Media Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-black/20 border-blue-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-blue-400 flex items-center gap-2 text-sm">
              <MessageCircle className="w-4 h-4" />
              Total Mentions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{formatNumber(metrics?.totalMentions || 0)}</div>
            <p className="text-xs text-gray-300">Across all platforms</p>
          </CardContent>
        </Card>

        <Card className="bg-black/20 border-green-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-green-400 flex items-center gap-2 text-sm">
              <Heart className="w-4 h-4" />
              Sentiment Score
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {metrics?.sentimentScore ? Math.round(metrics.sentimentScore) : 0}%
            </div>
            <Progress value={Math.max(0, (metrics?.sentimentScore || 0) + 100) / 2} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="bg-black/20 border-purple-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-purple-400 flex items-center gap-2 text-sm">
              <Zap className="w-4 h-4" />
              Virality Index
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {metrics?.viralityIndex ? Math.round(metrics.viralityIndex) : 0}/100
            </div>
            <Progress value={metrics?.viralityIndex || 0} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="bg-black/20 border-yellow-500/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-yellow-400 flex items-center gap-2 text-sm">
              <AlertTriangle className="w-4 h-4" />
              Controversy Level
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {metrics?.controversyLevel ? Math.round(metrics.controversyLevel) : 0}%
            </div>
            <Progress value={metrics?.controversyLevel || 0} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Platform Breakdown */}
      <Card className="bg-black/20 border-gray-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Platform Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {Object.entries(metrics?.platformBreakdown || {}).map(([platform, count]) => (
              <div key={platform} className="text-center">
                <div
                  className={`w-12 h-12 mx-auto mb-2 rounded-lg bg-white/5 flex items-center justify-center ${getPlatformColor(platform)}`}
                >
                  {getPlatformIcon(platform)}
                </div>
                <div className="text-lg font-bold text-white">{count as number}</div>
                <div className="text-xs text-gray-300 capitalize">{platform}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Trending Topics */}
      <Card className="bg-black/20 border-orange-500/30">
        <CardHeader>
          <CardTitle className="text-orange-400 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Trending Topics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {trending.slice(0, 5).map((topic) => (
              <div key={topic.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center ${getPlatformColor(topic.platform)}`}
                  >
                    {getPlatformIcon(topic.platform)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">{topic.hashtag}</h3>
                    <p className="text-sm text-gray-300">{formatNumber(topic.posts)} posts</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`flex items-center gap-1 ${topic.growth > 0 ? "text-green-400" : "text-red-400"}`}>
                    {topic.growth > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                    <span className="text-sm font-medium">{Math.abs(Math.round(topic.growth))}%</span>
                  </div>
                  <Badge variant="outline" className="mt-1 capitalize">
                    {topic.category}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Social Media Posts */}
      <Card className="bg-black/20 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            Recent Posts
          </CardTitle>
          <CardDescription className="text-gray-300">
            AI-generated social media content about {movieData.title}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedPlatform} onValueChange={setSelectedPlatform}>
            <TabsList className="grid w-full grid-cols-6 mb-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="twitter">Twitter</TabsTrigger>
              <TabsTrigger value="tiktok">TikTok</TabsTrigger>
              <TabsTrigger value="instagram">Instagram</TabsTrigger>
              <TabsTrigger value="youtube">YouTube</TabsTrigger>
              <TabsTrigger value="reddit">Reddit</TabsTrigger>
            </TabsList>

            <ScrollArea className="h-[600px]">
              <div className="space-y-4">
                {filteredPosts.slice(0, 20).map((post) => (
                  <div key={post.id} className="p-4 bg-white/5 rounded-lg border border-white/10">
                    {/* Post Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={post.author.avatar || "/placeholder.svg"}
                          alt={post.author.name}
                          className="w-10 h-10 rounded-full"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-white">{post.author.name}</span>
                            {post.author.verified && <Verified className="w-4 h-4 text-blue-400" />}
                            {getAuthorTypeIcon(post.author.type)}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-gray-400">
                            <span>{post.author.handle}</span>
                            <span>•</span>
                            <span>{formatNumber(post.author.followers)} followers</span>
                            <span>•</span>
                            <span>{post.timestamp.toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-6 h-6 rounded flex items-center justify-center ${getPlatformColor(post.platform)}`}
                        >
                          {getPlatformIcon(post.platform)}
                        </div>
                        {getSentimentIcon(post.sentiment)}
                      </div>
                    </div>

                    {/* Post Content */}
                    <div className="mb-3">
                      <p className="text-white leading-relaxed">{post.content}</p>

                      {/* Hashtags and Mentions */}
                      {(post.hashtags.length > 0 || post.mentions.length > 0) && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {post.hashtags.map((hashtag, index) => (
                            <Badge key={index} variant="outline" className="text-blue-400">
                              {hashtag}
                            </Badge>
                          ))}
                          {post.mentions.map((mention, index) => (
                            <Badge key={index} variant="outline" className="text-purple-400">
                              {mention}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Engagement Stats */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-6 text-sm text-gray-400">
                        <div className="flex items-center gap-1">
                          <Heart className="w-4 h-4" />
                          <span>{formatNumber(post.engagement.likes)}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MessageCircle className="w-4 h-4" />
                          <span>{formatNumber(post.engagement.comments)}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Share className="w-4 h-4" />
                          <span>{formatNumber(post.engagement.shares)}</span>
                        </div>
                        {post.engagement.views && (
                          <div className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            <span>{formatNumber(post.engagement.views)}</span>
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          Virality: {Math.round(post.viralityScore)}
                        </Badge>
                        {post.isSponsored && (
                          <Badge variant="secondary" className="text-xs">
                            Sponsored
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Replies */}
                    {post.replies && post.replies.length > 0 && (
                      <div className="mt-3 pl-4 border-l-2 border-white/10">
                        <div className="space-y-2">
                          {post.replies.slice(0, 2).map((reply) => (
                            <div key={reply.id} className="p-2 bg-white/5 rounded text-sm">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium text-white">{reply.author.name}</span>
                                <span className="text-gray-400">{reply.author.handle}</span>
                              </div>
                              <p className="text-gray-300">{reply.content}</p>
                            </div>
                          ))}
                          {post.replies.length > 2 && (
                            <p className="text-xs text-gray-400">+{post.replies.length - 2} more replies</p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </Tabs>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-4">
        <Button onClick={generateBuzz} className="bg-gradient-to-r from-purple-500 to-blue-500">
          <Zap className="w-4 h-4 mr-2" />
          Refresh Social Buzz
        </Button>
        <Button variant="outline" className="border-yellow-500/30 text-yellow-400">
          <AlertTriangle className="w-4 h-4 mr-2" />
          Crisis Management
        </Button>
        <Button variant="outline" className="border-green-500/30 text-green-400">
          <TrendingUp className="w-4 h-4 mr-2" />
          Boost Campaign
        </Button>
      </div>
    </div>
  )
}
