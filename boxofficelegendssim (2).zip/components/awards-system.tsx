"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "sonner"
import { Trophy, Star, Target, Award, Crown } from "lucide-react"
import { awardShows } from "@/lib/movie-data"

interface AwardsSystemProps {
  studioData: any
  onUpdateStudio: (updates: any) => void
}

export function AwardsSystem({ studioData, onUpdateStudio }: AwardsSystemProps) {
  const [selectedMovie, setSelectedMovie] = useState("")
  const [selectedAward, setSelectedAward] = useState("")

  const formatMoney = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`
    return `$${amount.toLocaleString()}`
  }

  const eligibleMovies =
    studioData.projects?.filter(
      (project: any) =>
        project.status === "Released" && (project.totalBoxOffice || 0) > 0 && (project.weeksSinceRelease || 0) >= 4,
    ) || []

  const submitForAward = (awardId: string, movieId: string) => {
    const award = awardShows.find((a) => a.id === awardId)
    const movie = studioData.projects.find((p: any) => p.id === movieId)

    if (!award || !movie) return

    // Check eligibility
    if (movie.budget < award.requirements.minBudget) {
      toast.error(`Movie budget too low for ${award.name}. Minimum: ${formatMoney(award.requirements.minBudget)}`)
      return
    }

    if ((movie.rating || 50) < award.requirements.minRating) {
      toast.error(`Movie rating too low for ${award.name}. Minimum: ${award.requirements.minRating}`)
      return
    }

    const submissionCost = 50000 // $50k submission fee
    if (studioData.money < submissionCost) {
      toast.error("Insufficient funds for award submission!")
      return
    }

    // Calculate nomination chances
    const nominationChance = calculateNominationChance(movie, award)
    const isNominated = Math.random() < nominationChance / 100

    // Update movie with award submission
    const updatedProjects = studioData.projects.map((p: any) => {
      if (p.id === movieId) {
        return {
          ...p,
          awardSubmissions: [
            ...(p.awardSubmissions || []),
            {
              awardId,
              awardName: award.name,
              submitted: true,
              nominated: isNominated,
              nominationChance,
            },
          ],
        }
      }
      return p
    })

    onUpdateStudio({
      money: studioData.money - submissionCost,
      projects: updatedProjects,
    })

    if (isNominated) {
      toast.success(`"${movie.title}" has been nominated for ${award.name}!`)

      // Schedule award ceremony (simulate)
      setTimeout(() => {
        const winChance = nominationChance * 0.3 // 30% of nomination chance
        const isWinner = Math.random() < winChance / 100

        if (isWinner) {
          const updatedProjectsWithWin = studioData.projects.map((p: any) => {
            if (p.id === movieId) {
              return {
                ...p,
                awards: [
                  ...(p.awards || []),
                  {
                    awardId,
                    awardName: award.name,
                    category: "Best Picture", // Simplified
                    year: 2024,
                  },
                ],
              }
            }
            return p
          })

          onUpdateStudio({
            projects: updatedProjectsWithWin,
            reputation: studioData.reputation + award.prestige / 10,
            money: studioData.money + 1000000, // Award bonus
          })

          toast.success(`🏆 "${movie.title}" won ${award.name}! +${award.prestige / 10} reputation, +$1M bonus!`)
        } else {
          toast.info(`"${movie.title}" didn't win ${award.name}, but the nomination boosted your reputation!`)
        }
      }, 2000)
    } else {
      toast.error(`"${movie.title}" was not nominated for ${award.name}. Better luck next time!`)
    }
  }

  const calculateNominationChance = (movie: any, award: any) => {
    let chance = 20 // Base 20% chance

    // Movie quality factors
    const rating = movie.rating || 50
    chance += (rating - 50) * 0.8 // Rating above 50 helps

    // Box office success
    const roi = (movie.totalBoxOffice || 0) / movie.budget - 1
    if (roi > 1) chance += 20 // Profitable movies get boost
    if (roi > 2) chance += 10 // Very profitable get more

    // Marketing boost
    chance += (movie.marketingBoost || 0) * 0.3

    // Studio reputation
    chance += (studioData.reputation - 50) * 0.4

    // Award prestige penalty (harder to win prestigious awards)
    chance -= (award.prestige - 50) * 0.2

    // Genre factors for different awards
    if (award.id === "oscars" && ["drama", "biography"].includes(movie.genre)) chance += 15
    if (award.id === "cannes" && ["drama", "art"].includes(movie.genre)) chance += 20
    if (award.id === "sundance" && movie.budget < 5000000) chance += 25 // Indie bonus

    return Math.max(5, Math.min(95, chance))
  }

  const getTotalAwards = () => {
    return studioData.projects?.reduce((total: number, project: any) => total + (project.awards?.length || 0), 0) || 0
  }

  const getAwardsByPrestige = () => {
    const allAwards: any[] = []
    studioData.projects?.forEach((project: any) => {
      if (project.awards) {
        project.awards.forEach((award: any) => {
          const awardShow = awardShows.find((a) => a.id === award.awardId)
          allAwards.push({
            ...award,
            movieTitle: project.title,
            prestige: awardShow?.prestige || 0,
          })
        })
      }
    })
    return allAwards.sort((a, b) => b.prestige - a.prestige)
  }

  if (!studioData.projects.length) {
    return (
      <div className="text-center py-12 text-gray-400">Produce or release a movie first to become award-eligible.</div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Awards & Recognition</h2>
        <p className="text-gray-300">Submit your movies for prestigious awards and festivals</p>
      </div>

      <Tabs defaultValue="submit" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="submit">Submit for Awards</TabsTrigger>
          <TabsTrigger value="nominations">Nominations</TabsTrigger>
          <TabsTrigger value="wins">Award Wins</TabsTrigger>
          <TabsTrigger value="calendar">Award Calendar</TabsTrigger>
        </TabsList>

        <TabsContent value="submit" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-black/20 border-yellow-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Trophy className="w-8 h-8 text-yellow-400" />
                  <div>
                    <p className="text-sm text-gray-400">Total Awards</p>
                    <p className="text-xl font-bold text-yellow-400">{getTotalAwards()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Star className="w-8 h-8 text-blue-400" />
                  <div>
                    <p className="text-sm text-gray-400">Eligible Movies</p>
                    <p className="text-xl font-bold text-blue-400">{eligibleMovies.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Target className="w-8 h-8 text-green-400" />
                  <div>
                    <p className="text-sm text-gray-400">Submission Fee</p>
                    <p className="text-xl font-bold text-green-400">$50K</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-purple-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Crown className="w-8 h-8 text-purple-400" />
                  <div>
                    <p className="text-sm text-gray-400">Studio Reputation</p>
                    <p className="text-xl font-bold text-purple-400">{studioData.reputation}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-black/20 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400">Select Movie</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {eligibleMovies.map((movie: any) => (
                  <Card
                    key={movie.id}
                    className={`cursor-pointer transition-all ${
                      selectedMovie === movie.id
                        ? "border-blue-400 bg-blue-500/10"
                        : "border-white/10 hover:border-blue-500/50"
                    }`}
                    onClick={() => setSelectedMovie(movie.id)}
                  >
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-white mb-2">{movie.title}</h3>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Rating:</span>
                          <span className="text-yellow-400">{movie.rating || 50}/100</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Box Office:</span>
                          <span className="text-green-400">{formatMoney(movie.totalBoxOffice || 0)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">ROI:</span>
                          <span
                            className={`${((movie.totalBoxOffice || 0) / movie.budget) >= 1 ? "text-green-400" : "text-red-400"}`}
                          >
                            {(((movie.totalBoxOffice || 0) / movie.budget - 1) * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Submissions:</span>
                          <span className="text-blue-400">{movie.awardSubmissions?.length || 0}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {eligibleMovies.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  <Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No eligible movies for award submission.</p>
                  <p className="text-sm">Movies must be released and have been in theaters for at least 4 weeks.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {selectedMovie && (
            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Available Awards</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {awardShows.map((award) => {
                    const movie = eligibleMovies.find((m: any) => m.id === selectedMovie)
                    const nominationChance = movie ? calculateNominationChance(movie, award) : 0
                    const alreadySubmitted = movie?.awardSubmissions?.some((s: any) => s.awardId === award.id)
                    const meetsRequirements =
                      movie &&
                      movie.budget >= award.requirements.minBudget &&
                      (movie.rating || 50) >= award.requirements.minRating

                    return (
                      <Card key={award.id} className="border-white/10">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-center mb-3">
                            <h3 className="font-semibold text-white">{award.name}</h3>
                            <Badge variant="outline" className="text-yellow-400">
                              Prestige: {award.prestige}
                            </Badge>
                          </div>

                          <div className="space-y-2 mb-4">
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">Min Budget:</span>
                              <span className="text-white">{formatMoney(award.requirements.minBudget)}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">Min Rating:</span>
                              <span className="text-white">{award.requirements.minRating}/100</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-400">Categories:</span>
                              <span className="text-white">{award.categories.length}</span>
                            </div>
                          </div>

                          {movie && (
                            <div className="mb-4">
                              <div className="flex justify-between text-sm mb-2">
                                <span className="text-gray-400">Nomination Chance</span>
                                <span className="text-purple-400">{nominationChance.toFixed(1)}%</span>
                              </div>
                              <Progress value={nominationChance} className="h-2" />
                            </div>
                          )}

                          <div className="space-y-2">
                            {!meetsRequirements && (
                              <p className="text-red-400 text-sm">❌ Does not meet requirements</p>
                            )}
                            {alreadySubmitted && <p className="text-blue-400 text-sm">✅ Already submitted</p>}
                          </div>

                          <Button
                            onClick={() => submitForAward(award.id, selectedMovie)}
                            disabled={!meetsRequirements || alreadySubmitted || studioData.money < 50000}
                            className="w-full mt-3 bg-yellow-500 hover:bg-yellow-600 text-black"
                          >
                            <Award className="w-4 h-4 mr-2" />
                            Submit ($50K)
                          </Button>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="nominations" className="space-y-6">
          <Card className="bg-black/20 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-purple-400">Current Nominations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {studioData.projects
                  ?.map((project: any) => {
                    const nominations = project.awardSubmissions?.filter((s: any) => s.nominated) || []
                    if (nominations.length === 0) return null

                    return (
                      <div key={project.id} className="p-4 bg-white/5 rounded border border-purple-500/30">
                        <h3 className="font-semibold text-white mb-2">{project.title}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {nominations.map((nomination: any, index: number) => (
                            <div key={index} className="flex items-center gap-2 p-2 bg-white/5 rounded">
                              <Star className="w-4 h-4 text-yellow-400" />
                              <span className="text-white">{nomination.awardName}</span>
                              <Badge variant="outline" className="text-purple-400 ml-auto">
                                {nomination.nominationChance.toFixed(1)}%
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )
                  })
                  .filter(Boolean)}

                {!studioData.projects?.some((p: any) => p.awardSubmissions?.some((s: any) => s.nominated)) && (
                  <div className="text-center py-8 text-gray-400">
                    <Star className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No current nominations.</p>
                    <p className="text-sm">Submit movies for awards to get nominations!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="wins" className="space-y-6">
          <Card className="bg-black/20 border-yellow-500/30">
            <CardHeader>
              <CardTitle className="text-yellow-400">Award Wins</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {getAwardsByPrestige().map((award: any, index: number) => (
                  <div
                    key={index}
                    className="flex items-center gap-4 p-4 bg-white/5 rounded border border-yellow-500/30"
                  >
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-yellow-500 to-orange-500">
                      <Trophy className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{award.awardName}</h3>
                      <p className="text-sm text-gray-400">
                        "{award.movieTitle}" - {award.category}
                      </p>
                      <p className="text-xs text-gray-500">{award.year}</p>
                    </div>
                    <Badge variant="outline" className="text-yellow-400">
                      Prestige: {award.prestige}
                    </Badge>
                  </div>
                ))}

                {getAwardsByPrestige().length === 0 && (
                  <div className="text-center py-8 text-gray-400">
                    <Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No awards won yet.</p>
                    <p className="text-sm">Keep making great movies and submitting them for awards!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar" className="space-y-6">
          <Card className="bg-black/20 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-400">Award Calendar</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {awardShows.map((award, index) => (
                  <div key={award.id} className="p-4 bg-white/5 rounded border border-green-500/30">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-semibold text-white">{award.name}</h3>
                      <Badge variant="outline" className="text-green-400">
                        {award.prestige} Prestige
                      </Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-gray-400">Submission Deadline</p>
                        <p className="text-white">December 31, 2024</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Ceremony Date</p>
                        <p className="text-white">March {15 + index}, 2025</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Categories</p>
                        <p className="text-white">{award.categories.length} categories</p>
                      </div>
                    </div>
                    <div className="mt-3">
                      <p className="text-sm text-gray-400">Categories:</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {award.categories.map((category: string) => (
                          <Badge key={category} variant="outline" className="text-xs">
                            {category}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
