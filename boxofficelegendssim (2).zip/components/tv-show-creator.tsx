"use client"

import React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { Tv, Users, Calendar, Play, ImageIcon, Sparkles, Target, Edit, Eye, Share } from "lucide-react"

interface TVShow {
  id: string
  title: string
  genre: string
  format: "Series" | "Limited Series" | "Anthology" | "Reality" | "Documentary" | "Talk Show"
  seasons: number
  episodesPerSeason: number
  episodeLength: number
  budget: number
  cast: string[]
  network: string
  status: "In Development" | "Pre-Production" | "Filming" | "Post-Production" | "Airing" | "Completed" | "Cancelled"
  poster: string
  description: string
  targetAudience: string
  rating: number
  viewership: number
  criticalScore: number
  socialBuzz: number
}

export function TVShowCreator() {
  const [currentStep, setCurrentStep] = useState(0)
  const [showData, setShowData] = useState<Partial<TVShow>>({
    title: "",
    genre: "",
    format: "Series",
    seasons: 1,
    episodesPerSeason: 10,
    episodeLength: 45,
    budget: 5000000,
    cast: [],
    network: "",
    status: "In Development",
    description: "",
    targetAudience: "",
  })

  const [selectedPoster, setSelectedPoster] = useState("")

  const genres = [
    "Drama",
    "Comedy",
    "Action",
    "Thriller",
    "Sci-Fi",
    "Fantasy",
    "Horror",
    "Romance",
    "Crime",
    "Mystery",
    "Documentary",
    "Reality",
    "Talk Show",
    "News",
    "Sports",
    "Kids",
    "Animation",
    "Musical",
    "Historical",
    "Medical",
    "Legal",
    "Police",
    "Superhero",
    "Western",
    "War",
  ]

  const networks = [
    "Netflix",
    "HBO Max",
    "Disney+",
    "Amazon Prime",
    "Apple TV+",
    "Hulu",
    "Paramount+",
    "NBC",
    "ABC",
    "CBS",
    "FOX",
    "The CW",
    "FX",
    "AMC",
    "Showtime",
    "Starz",
    "BBC",
    "ITV",
    "Channel 4",
    "Sky",
  ]

  const posterStyles = [
    {
      id: "dramatic_dark",
      name: "Dramatic Dark",
      preview: "🎭",
      style: "bg-gradient-to-b from-gray-900 to-black",
      description: "Moody and intense for dramas and thrillers",
    },
    {
      id: "bright_comedy",
      name: "Bright Comedy",
      preview: "😄",
      style: "bg-gradient-to-br from-yellow-400 to-orange-500",
      description: "Vibrant and fun for comedies and family shows",
    },
    {
      id: "sci_fi_neon",
      name: "Sci-Fi Neon",
      preview: "🚀",
      style: "bg-gradient-to-r from-cyan-500 to-purple-600",
      description: "Futuristic and electric for sci-fi content",
    },
    {
      id: "romantic_sunset",
      name: "Romantic Sunset",
      preview: "💕",
      style: "bg-gradient-to-br from-pink-400 to-red-500",
      description: "Warm and passionate for romance shows",
    },
    {
      id: "action_explosion",
      name: "Action Explosion",
      preview: "💥",
      style: "bg-gradient-to-r from-red-600 to-orange-700",
      description: "High-energy for action and adventure",
    },
    {
      id: "mystery_noir",
      name: "Mystery Noir",
      preview: "🔍",
      style: "bg-gradient-to-b from-purple-900 to-gray-900",
      description: "Dark and mysterious for crime shows",
    },
    {
      id: "fantasy_magic",
      name: "Fantasy Magic",
      preview: "✨",
      style: "bg-gradient-to-br from-purple-500 to-indigo-600",
      description: "Magical and enchanting for fantasy series",
    },
    {
      id: "horror_blood",
      name: "Horror Blood",
      preview: "🩸",
      style: "bg-gradient-to-b from-red-900 to-black",
      description: "Terrifying and ominous for horror content",
    },
    {
      id: "documentary_earth",
      name: "Documentary Earth",
      preview: "🌍",
      style: "bg-gradient-to-br from-green-600 to-blue-700",
      description: "Natural and informative for documentaries",
    },
    {
      id: "reality_gold",
      name: "Reality Gold",
      preview: "👑",
      style: "bg-gradient-to-r from-yellow-500 to-yellow-700",
      description: "Glamorous and exciting for reality TV",
    },
  ]

  const steps = [
    { id: "basic", title: "Basic Info", icon: Tv },
    { id: "format", title: "Format & Structure", icon: Calendar },
    { id: "cast", title: "Cast & Crew", icon: Users },
    { id: "poster", title: "Poster Design", icon: ImageIcon },
    { id: "marketing", title: "Marketing", icon: Target },
    { id: "review", title: "Review", icon: Eye },
  ]

  const formatMoney = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const calculateBudgetPerEpisode = () => {
    const totalEpisodes = (showData.seasons || 1) * (showData.episodesPerSeason || 10)
    return (showData.budget || 0) / totalEpisodes
  }

  const generateShowTitle = () => {
    const prefixes = [
      "The",
      "Dark",
      "Lost",
      "Secret",
      "Hidden",
      "Last",
      "First",
      "New",
      "Old",
      "Young",
      "Wild",
      "Strange",
      "Broken",
      "Golden",
      "Silver",
      "Blood",
      "Shadow",
      "Light",
      "Fire",
      "Ice",
      "Storm",
      "Night",
      "Day",
      "Rising",
      "Falling",
    ]

    const nouns = [
      "Chronicles",
      "Mysteries",
      "Secrets",
      "Stories",
      "Tales",
      "Legends",
      "Heroes",
      "Villains",
      "Kingdom",
      "Empire",
      "City",
      "Island",
      "Mountain",
      "Valley",
      "River",
      "Ocean",
      "Forest",
      "Desert",
      "Castle",
      "Tower",
      "Bridge",
      "Gate",
      "Path",
      "Journey",
      "Quest",
      "Adventure",
      "Mission",
      "War",
      "Peace",
      "Love",
      "Hate",
      "Hope",
      "Fear",
      "Dream",
      "Nightmare",
      "Vision",
      "Prophecy",
      "Destiny",
      "Fate",
      "Legacy",
      "Heritage",
      "Tradition",
      "Revolution",
      "Evolution",
      "Genesis",
      "Exodus",
      "Revelation",
      "Awakening",
      "Resurrection",
    ]

    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)]
    const noun = nouns[Math.floor(Math.random() * nouns.length)]

    setShowData({ ...showData, title: `${prefix} ${noun}` })
  }

  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // Basic Info
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Show Title</label>
                <div className="flex gap-2">
                  <Input
                    value={showData.title || ""}
                    onChange={(e) => setShowData({ ...showData, title: e.target.value })}
                    placeholder="Enter show title..."
                    className="flex-1"
                  />
                  <Button onClick={generateShowTitle} variant="outline" className="border-purple-500/30">
                    <Sparkles className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Genre</label>
                  <Select
                    value={showData.genre || ""}
                    onValueChange={(value) => setShowData({ ...showData, genre: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose genre..." />
                    </SelectTrigger>
                    <SelectContent>
                      {genres.map((genre) => (
                        <SelectItem key={genre} value={genre}>
                          {genre}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Network/Platform</label>
                  <Select
                    value={showData.network || ""}
                    onValueChange={(value) => setShowData({ ...showData, network: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose network..." />
                    </SelectTrigger>
                    <SelectContent>
                      {networks.map((network) => (
                        <SelectItem key={network} value={network}>
                          {network}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Description</label>
                <Textarea
                  value={showData.description || ""}
                  onChange={(e) => setShowData({ ...showData, description: e.target.value })}
                  placeholder="Describe your show's plot, themes, and unique elements..."
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Target Audience</label>
                <Select
                  value={showData.targetAudience || ""}
                  onValueChange={(value) => setShowData({ ...showData, targetAudience: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose target audience..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="kids">Kids (6-12)</SelectItem>
                    <SelectItem value="teens">Teens (13-17)</SelectItem>
                    <SelectItem value="young_adults">Young Adults (18-34)</SelectItem>
                    <SelectItem value="adults">Adults (35-54)</SelectItem>
                    <SelectItem value="seniors">Seniors (55+)</SelectItem>
                    <SelectItem value="family">Family (All Ages)</SelectItem>
                    <SelectItem value="mature">Mature Audiences Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )

      case 1: // Format & Structure
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Show Format</label>
                <Select
                  value={showData.format || "Series"}
                  onValueChange={(value: TVShow["format"]) => setShowData({ ...showData, format: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Series">Series - Ongoing storyline across multiple seasons</SelectItem>
                    <SelectItem value="Limited Series">Limited Series - Single season with complete story</SelectItem>
                    <SelectItem value="Anthology">Anthology - Different story/cast each season</SelectItem>
                    <SelectItem value="Reality">Reality TV - Unscripted real-life situations</SelectItem>
                    <SelectItem value="Documentary">Documentary - Educational/informational content</SelectItem>
                    <SelectItem value="Talk Show">Talk Show - Interview and discussion format</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Number of Seasons</label>
                  <div className="space-y-2">
                    <Slider
                      value={[showData.seasons || 1]}
                      onValueChange={(value) => setShowData({ ...showData, seasons: value[0] })}
                      max={10}
                      min={1}
                      step={1}
                      className="w-full"
                    />
                    <div className="text-center text-white font-semibold">{showData.seasons || 1} Season(s)</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Episodes per Season</label>
                  <div className="space-y-2">
                    <Slider
                      value={[showData.episodesPerSeason || 10]}
                      onValueChange={(value) => setShowData({ ...showData, episodesPerSeason: value[0] })}
                      max={24}
                      min={4}
                      step={1}
                      className="w-full"
                    />
                    <div className="text-center text-white font-semibold">
                      {showData.episodesPerSeason || 10} Episodes
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Episode Length (minutes)</label>
                  <div className="space-y-2">
                    <Slider
                      value={[showData.episodeLength || 45]}
                      onValueChange={(value) => setShowData({ ...showData, episodeLength: value[0] })}
                      max={120}
                      min={15}
                      step={5}
                      className="w-full"
                    />
                    <div className="text-center text-white font-semibold">{showData.episodeLength || 45} Minutes</div>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Total Budget</label>
                <div className="space-y-2">
                  <Slider
                    value={[showData.budget || 5000000]}
                    onValueChange={(value) => setShowData({ ...showData, budget: value[0] })}
                    max={200000000}
                    min={1000000}
                    step={1000000}
                    className="w-full"
                  />
                  <div className="text-center space-y-1">
                    <div className="text-2xl font-bold text-green-400">{formatMoney(showData.budget || 0)}</div>
                    <div className="text-sm text-gray-400">{formatMoney(calculateBudgetPerEpisode())} per episode</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-white/5 rounded-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">
                    {(showData.seasons || 1) * (showData.episodesPerSeason || 10)}
                  </div>
                  <div className="text-sm text-gray-400">Total Episodes</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-400">
                    {Math.round(
                      ((showData.seasons || 1) * (showData.episodesPerSeason || 10) * (showData.episodeLength || 45)) /
                        60,
                    )}
                    h
                  </div>
                  <div className="text-sm text-gray-400">Total Runtime</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">
                    {Math.round((showData.seasons || 1) * (showData.episodesPerSeason || 10) * 0.5)}
                  </div>
                  <div className="text-sm text-gray-400">Est. Production Weeks</div>
                </div>
              </div>
            </div>
          </div>
        )

      case 2: // Cast & Crew
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Cast & Crew Selection</h3>
              <p className="text-gray-400">Choose your talent (affects budget and audience appeal)</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-purple-400">Lead Cast</CardTitle>
                  <CardDescription>Main characters and stars</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { role: "Lead Actor", cost: "$2M/season", appeal: "High" },
                    { role: "Lead Actress", cost: "$1.8M/season", appeal: "High" },
                    { role: "Supporting Actor", cost: "$500K/season", appeal: "Medium" },
                    { role: "Supporting Actress", cost: "$450K/season", appeal: "Medium" },
                  ].map((actor, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <div>
                        <div className="font-semibold text-white">{actor.role}</div>
                        <div className="text-sm text-gray-400">{actor.cost}</div>
                      </div>
                      <div className="text-right">
                        <Badge
                          variant="outline"
                          className={actor.appeal === "High" ? "text-green-400" : "text-yellow-400"}
                        >
                          {actor.appeal} Appeal
                        </Badge>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-400">Key Crew</CardTitle>
                  <CardDescription>Behind-the-scenes talent</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { role: "Showrunner", cost: "$1M/season", impact: "Story Quality" },
                    { role: "Director", cost: "$200K/episode", impact: "Visual Style" },
                    { role: "Writer", cost: "$100K/episode", impact: "Script Quality" },
                    { role: "Producer", cost: "$500K/season", impact: "Overall Production" },
                  ].map((crew, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <div>
                        <div className="font-semibold text-white">{crew.role}</div>
                        <div className="text-sm text-gray-400">{crew.cost}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-blue-400">{crew.impact}</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/20 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-green-400">Budget Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-white/5 rounded-lg">
                    <div className="text-lg font-bold text-purple-400">40%</div>
                    <div className="text-sm text-gray-400">Cast Salaries</div>
                    <div className="text-xs text-green-400">{formatMoney((showData.budget || 0) * 0.4)}</div>
                  </div>
                  <div className="text-center p-4 bg-white/5 rounded-lg">
                    <div className="text-lg font-bold text-blue-400">25%</div>
                    <div className="text-sm text-gray-400">Production</div>
                    <div className="text-xs text-green-400">{formatMoney((showData.budget || 0) * 0.25)}</div>
                  </div>
                  <div className="text-center p-4 bg-white/5 rounded-lg">
                    <div className="text-lg font-bold text-yellow-400">20%</div>
                    <div className="text-sm text-gray-400">Post-Production</div>
                    <div className="text-xs text-green-400">{formatMoney((showData.budget || 0) * 0.2)}</div>
                  </div>
                  <div className="text-center p-4 bg-white/5 rounded-lg">
                    <div className="text-lg font-bold text-red-400">15%</div>
                    <div className="text-sm text-gray-400">Marketing</div>
                    <div className="text-xs text-green-400">{formatMoney((showData.budget || 0) * 0.15)}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 3: // Poster Design
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Design Your Show Poster</h3>
              <p className="text-gray-400">Create eye-catching artwork that represents your show</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {posterStyles.map((poster) => (
                <Card
                  key={poster.id}
                  className={`cursor-pointer transition-all ${
                    selectedPoster === poster.id
                      ? "border-blue-400 bg-blue-500/10"
                      : "border-white/10 hover:border-blue-500/50"
                  }`}
                  onClick={() => setSelectedPoster(poster.id)}
                >
                  <CardContent className="p-4 text-center">
                    <div
                      className={`w-full aspect-[2/3] rounded-lg flex items-center justify-center text-4xl ${poster.style} mb-3`}
                    >
                      {poster.preview}
                    </div>
                    <h4 className="font-semibold text-white text-sm">{poster.name}</h4>
                    <p className="text-xs text-gray-400 mt-1">{poster.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {selectedPoster && (
              <Card className="bg-black/20 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-400">Poster Preview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-6">
                    <div
                      className={`w-48 aspect-[2/3] rounded-lg flex flex-col items-center justify-center text-6xl ${
                        posterStyles.find((p) => p.id === selectedPoster)?.style
                      } relative overflow-hidden`}
                    >
                      <div className="absolute inset-0 bg-black/20"></div>
                      <div className="relative z-10 text-center">
                        {posterStyles.find((p) => p.id === selectedPoster)?.preview}
                        <div className="mt-4 text-white text-lg font-bold">{showData.title || "Your Show"}</div>
                        <div className="text-white/80 text-sm">
                          {showData.genre} • {showData.network}
                        </div>
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-white mb-2">
                        {posterStyles.find((p) => p.id === selectedPoster)?.name}
                      </h3>
                      <p className="text-gray-300 mb-4">
                        {posterStyles.find((p) => p.id === selectedPoster)?.description}
                      </p>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Style:</span>
                          <span className="text-white">{posterStyles.find((p) => p.id === selectedPoster)?.name}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Genre Match:</span>
                          <Badge variant="outline" className="text-green-400">
                            Excellent
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Market Appeal:</span>
                          <Badge variant="outline" className="text-blue-400">
                            High
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="bg-black/20 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-purple-400">Poster Customization</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Tagline</label>
                    <Input placeholder="Enter a catchy tagline..." />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-white">Release Date</label>
                    <Input placeholder="Coming Soon / Fall 2024" />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-purple-500/30">
                    <Edit className="w-4 h-4 mr-2" />
                    Advanced Editor
                  </Button>
                  <Button variant="outline" className="border-green-500/30">
                    <Sparkles className="w-4 h-4 mr-2" />
                    AI Generate
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 4: // Marketing
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Marketing Strategy</h3>
              <p className="text-gray-400">Plan your promotional campaign to maximize viewership</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-black/20 border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-green-400">Social Media Campaign</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { platform: "TikTok", reach: "15M", cost: "$500K", engagement: "High" },
                    { platform: "Instagram", reach: "12M", cost: "$400K", engagement: "Medium" },
                    { platform: "Twitter", reach: "8M", cost: "$300K", engagement: "High" },
                    { platform: "YouTube", reach: "20M", cost: "$800K", engagement: "Medium" },
                  ].map((campaign, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                          <Share className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <div className="font-semibold text-white">{campaign.platform}</div>
                          <div className="text-sm text-gray-400">{campaign.reach} potential reach</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-green-400 font-semibold">{campaign.cost}</div>
                        <Badge
                          variant="outline"
                          className={campaign.engagement === "High" ? "text-green-400" : "text-yellow-400"}
                        >
                          {campaign.engagement}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-black/20 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-400">Traditional Marketing</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { method: "TV Commercials", reach: "25M", cost: "$2M", effectiveness: "High" },
                    { method: "Billboard Campaign", reach: "5M", cost: "$800K", effectiveness: "Medium" },
                    { method: "Press Interviews", reach: "10M", cost: "$200K", effectiveness: "High" },
                    { method: "Comic-Con Presence", reach: "2M", cost: "$500K", effectiveness: "Very High" },
                  ].map((campaign, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                          <Tv className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <div className="font-semibold text-white">{campaign.method}</div>
                          <div className="text-sm text-gray-400">{campaign.reach} potential reach</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-blue-400 font-semibold">{campaign.cost}</div>
                        <Badge variant="outline" className="text-green-400">
                          {campaign.effectiveness}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <Card className="bg-black/20 border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-yellow-400">Marketing Budget Allocation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-white/5 rounded-lg">
                      <div className="text-2xl font-bold text-green-400">40%</div>
                      <div className="text-sm text-gray-400">Digital/Social</div>
                      <div className="text-xs text-white">{formatMoney((showData.budget || 0) * 0.15 * 0.4)}</div>
                    </div>
                    <div className="text-center p-4 bg-white/5 rounded-lg">
                      <div className="text-2xl font-bold text-blue-400">35%</div>
                      <div className="text-sm text-gray-400">Traditional</div>
                      <div className="text-xs text-white">{formatMoney((showData.budget || 0) * 0.15 * 0.35)}</div>
                    </div>
                    <div className="text-center p-4 bg-white/5 rounded-lg">
                      <div className="text-2xl font-bold text-purple-400">15%</div>
                      <div className="text-sm text-gray-400">Events</div>
                      <div className="text-xs text-white">{formatMoney((showData.budget || 0) * 0.15 * 0.15)}</div>
                    </div>
                    <div className="text-center p-4 bg-white/5 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-400">10%</div>
                      <div className="text-sm text-gray-400">Influencers</div>
                      <div className="text-xs text-white">{formatMoney((showData.budget || 0) * 0.15 * 0.1)}</div>
                    </div>
                  </div>

                  <div className="p-4 bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-lg border border-green-500/30">
                    <h4 className="font-semibold text-white mb-2">Projected Impact</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-green-400">45M</div>
                        <div className="text-sm text-gray-400">Total Reach</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-blue-400">12M</div>
                        <div className="text-sm text-gray-400">Expected Viewers</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-400">8.5</div>
                        <div className="text-sm text-gray-400">Projected Rating</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )

      case 5: // Review
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Show Summary</h3>
              <p className="text-gray-400">Review your TV show before production begins</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <Card className="bg-black/20 border-purple-500/30">
                  <CardHeader>
                    <CardTitle className="text-purple-400">Show Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Title:</span>
                      <span className="text-white font-semibold">{showData.title || "Untitled Show"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Genre:</span>
                      <Badge variant="outline">{showData.genre || "TBD"}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Format:</span>
                      <span className="text-white">{showData.format}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Network:</span>
                      <span className="text-white">{showData.network || "TBD"}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Target Audience:</span>
                      <span className="text-white capitalize">
                        {showData.targetAudience?.replace("_", " ") || "TBD"}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-black/20 border-blue-500/30">
                  <CardHeader>
                    <CardTitle className="text-blue-400">Production Info</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Seasons:</span>
                      <span className="text-white">{showData.seasons}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Episodes per Season:</span>
                      <span className="text-white">{showData.episodesPerSeason}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Episode Length:</span>
                      <span className="text-white">{showData.episodeLength} minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Episodes:</span>
                      <span className="text-white">{(showData.seasons || 1) * (showData.episodesPerSeason || 10)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Budget:</span>
                      <span className="text-green-400 font-semibold">{formatMoney(showData.budget || 0)}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                {selectedPoster && (
                  <Card className="bg-black/20 border-green-500/30">
                    <CardHeader>
                      <CardTitle className="text-green-400">Show Poster</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div
                        className={`w-full aspect-[2/3] rounded-lg flex flex-col items-center justify-center text-4xl ${
                          posterStyles.find((p) => p.id === selectedPoster)?.style
                        } relative overflow-hidden`}
                      >
                        <div className="absolute inset-0 bg-black/20"></div>
                        <div className="relative z-10 text-center">
                          {posterStyles.find((p) => p.id === selectedPoster)?.preview}
                          <div className="mt-4 text-white text-lg font-bold">{showData.title || "Your Show"}</div>
                          <div className="text-white/80 text-sm">
                            {showData.genre} • {showData.network}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <Card className="bg-black/20 border-yellow-500/30">
                  <CardHeader>
                    <CardTitle className="text-yellow-400">Projected Performance</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-white/5 rounded-lg">
                        <div className="text-xl font-bold text-blue-400">8.2M</div>
                        <div className="text-sm text-gray-400">Est. Premiere Viewers</div>
                      </div>
                      <div className="text-center p-3 bg-white/5 rounded-lg">
                        <div className="text-xl font-bold text-green-400">7.8</div>
                        <div className="text-sm text-gray-400">Projected Rating</div>
                      </div>
                      <div className="text-center p-3 bg-white/5 rounded-lg">
                        <div className="text-xl font-bold text-purple-400">85%</div>
                        <div className="text-sm text-gray-400">Renewal Chance</div>
                      </div>
                      <div className="text-center p-3 bg-white/5 rounded-lg">
                        <div className="text-xl font-bold text-yellow-400">3.2x</div>
                        <div className="text-sm text-gray-400">ROI Potential</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Success Probability</span>
                        <span className="text-white">78%</span>
                      </div>
                      <Progress value={78} className="h-2" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="flex gap-4">
              <Button
                onClick={() => setCurrentStep(currentStep - 1)}
                variant="outline"
                className="flex-1 border-gray-500/30"
              >
                Back
              </Button>
              <Button className="flex-1 bg-gradient-to-r from-green-500 to-blue-500">
                <Play className="w-4 h-4 mr-2" />
                Start Production
              </Button>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      {/* Progress Header */}
      <Card className="bg-black/20 border-purple-500/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-white">Create TV Show</h2>
            <Badge variant="outline" className="text-purple-400">
              Step {currentStep + 1} of {steps.length}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            {steps.map((step, index) => {
              const Icon = step.icon
              return (
                <div key={step.id} className="flex items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      index <= currentStep
                        ? "bg-gradient-to-r from-purple-500 to-blue-500 text-white"
                        : "bg-gray-700 text-gray-400"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  {index < steps.length - 1 && (
                    <div
                      className={`w-8 h-1 mx-2 ${
                        index < currentStep ? "bg-gradient-to-r from-purple-500 to-blue-500" : "bg-gray-700"
                      }`}
                    />
                  )}
                </div>
              )
            })}
          </div>
          <div className="mt-2">
            <Progress value={((currentStep + 1) / steps.length) * 100} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Step Content */}
      <Card className="bg-black/20 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-blue-400 flex items-center gap-2">
            {React.createElement(steps[currentStep].icon, { className: "w-5 h-5" })}
            {steps[currentStep].title}
          </CardTitle>
        </CardHeader>
        <CardContent>{renderStepContent()}</CardContent>
      </Card>

      {/* Navigation */}
      {currentStep < steps.length - 1 && (
        <div className="flex gap-4">
          {currentStep > 0 && (
            <Button onClick={() => setCurrentStep(currentStep - 1)} variant="outline" className="border-gray-500/30">
              Previous
            </Button>
          )}
          <Button
            onClick={() => setCurrentStep(currentStep + 1)}
            className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500"
          >
            Next Step
          </Button>
        </div>
      )}
    </div>
  )
}
