"use client"

import { useState, useEffect } from "react"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"

interface AppLoadingScreenProps {
  onLoadingComplete: () => void
}

const loadingSteps = [
  "Initializing Box Office Legends Sim...",
  "Loading studio assets...",
  "Preparing movie database...",
  "Setting up talent agency...",
  "Configuring award systems...",
  "Loading social media engine...",
  "Initializing AI competitors...",
  "Preparing streaming platforms...",
  "Loading box office algorithms...",
  "Finalizing game engine...",
]

export function AppLoadingScreen({ onLoadingComplete }: AppLoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(0)
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + Math.random() * 15 + 5

        if (newProgress >= 100) {
          setIsComplete(true)
          clearInterval(interval)
          setTimeout(() => {
            onLoadingComplete()
          }, 1000)
          return 100
        }

        // Update step based on progress
        const stepIndex = Math.floor((newProgress / 100) * loadingSteps.length)
        setCurrentStep(Math.min(stepIndex, loadingSteps.length - 1))

        return newProgress
      })
    }, 200)

    return () => clearInterval(interval)
  }, [onLoadingComplete])

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-black/40 border-purple-500/30 backdrop-blur-sm">
        <CardContent className="p-8 text-center space-y-6">
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <Image
              src="/box-office-logo.png"
              alt="Box Office Legends Sim"
              width={120}
              height={120}
              className="animate-pulse drop-shadow-2xl"
            />
          </div>

          {/* Title */}
          <div className="space-y-2">
            <h1 className="text-3xl font-bold text-white">BOX OFFICE</h1>
            <h2 className="text-2xl font-bold text-blue-400">LEGENDS SIM</h2>
            <p className="text-sm text-gray-300 font-medium tracking-wider">LOADING YOUR EMPIRE</p>
          </div>

          {/* Progress Bar */}
          <div className="space-y-3">
            <Progress value={progress} className="w-full h-3 bg-gray-800" />
            <div className="flex justify-between text-xs text-gray-400">
              <span>{Math.round(progress)}%</span>
              <span>{isComplete ? "Complete!" : "Loading..."}</span>
            </div>
          </div>

          {/* Current Step */}
          <div className="min-h-[2rem] flex items-center justify-center">
            <p className="text-sm text-gray-300 animate-pulse">{loadingSteps[currentStep]}</p>
          </div>

          {/* Loading Animation */}
          <div className="flex justify-center space-x-2">
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></div>
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></div>
            <div className="w-2 h-2 bg-green-500 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></div>
          </div>

          {/* Version Info */}
          <div className="text-xs text-gray-500 pt-4">
            <p>Version 2.0 Beta</p>
            <p>© 2024 Box Office Legends</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
