"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"
import { TrendingUp, DollarSign, Calendar, Trophy, Target } from "lucide-react"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface BoxOfficeSimulationProps {
  studioData: any
  onUpdateStudio: (updates: any) => void
}

export function BoxOfficeSimulation({ studioData, onUpdateStudio }: BoxOfficeSimulationProps) {
  const [selectedMovie, setSelectedMovie] = useState("")
  const [simulationWeek, setSimulationWeek] = useState(1)
  const [data, setData] = useState<{ week: number; revenue: number }[]>([])

  const formatMoney = (amount: number) => {
    if (amount >= 1000000000) return `$${(amount / 1000000000).toFixed(1)}B`
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(1)}K`
    return `$${amount.toLocaleString()}`
  }

  const releasedMovies = studioData.projects?.filter((p: any) => p.status === "Released") || []
  const inTheatersMovies = releasedMovies.filter((m: any) => (m.weeksSinceRelease || 0) < 12)

  const calculateWeeklyRevenue = (movie: any, week: number) => {
    const baseRevenue = movie.budget * 0.15 // 15% of budget as opening week potential
    const weekDecay = Math.max(0.1, 1 - (week - 1) * 0.2) // 20% decay per week
    const marketingBoost = 1 + (movie.marketingBoost || 0) / 100
    const genreMultiplier = getGenreMultiplier(movie.genre)
    const seasonalMultiplier = getSeasonalMultiplier()
    const randomFactor = 0.8 + Math.random() * 0.4 // ±20% randomness

    return baseRevenue * weekDecay * marketingBoost * genreMultiplier * seasonalMultiplier * randomFactor
  }

  const getGenreMultiplier = (genre: string) => {
    const multipliers: Record<string, number> = {
      action: 1.3,
      comedy: 1.1,
      drama: 0.9,
      horror: 1.4,
      romance: 0.8,
      scifi: 1.2,
      fantasy: 1.3,
      thriller: 1.0,
      animation: 1.5,
      documentary: 0.6,
    }
    return multipliers[genre] || 1.0
  }

  const getSeasonalMultiplier = () => {
    // Simulate seasonal effects (summer = higher, winter = lower)
    const season = Math.floor(Math.random() * 4)
    const multipliers = [0.8, 1.0, 1.4, 1.1] // Winter, Spring, Summer, Fall
    return multipliers[season]
  }

  const generateBoxOfficeData = (movie: any) => {
    const data = []
    let totalRevenue = 0

    for (let week = 1; week <= 12; week++) {
      const weeklyRevenue = calculateWeeklyRevenue(movie, week)
      totalRevenue += weeklyRevenue

      data.push({
        week,
        weeklyRevenue: Math.round(weeklyRevenue),
        totalRevenue: Math.round(totalRevenue),
        weeklyFormatted: formatMoney(weeklyRevenue),
        totalFormatted: formatMoney(totalRevenue),
      })
    }

    return data
  }

  const simulateBoxOfficeWeek = () => {
    const updatedProjects = studioData.projects.map((project: any) => {
      if (project.status === "Released" && (project.weeksSinceRelease || 0) < 12) {
        const weeklyRevenue = calculateWeeklyRevenue(project, (project.weeksSinceRelease || 0) + 1)
        const newTotalRevenue = (project.totalBoxOffice || 0) + weeklyRevenue
        const studioShare = weeklyRevenue * 0.5 // Studio gets 50% of box office

        return {
          ...project,
          weeksSinceRelease: (project.weeksSinceRelease || 0) + 1,
          totalBoxOffice: newTotalRevenue,
          lastWeekRevenue: weeklyRevenue,
        }
      }
      return project
    })

    const totalWeeklyEarnings = updatedProjects
      .filter((p: any) => p.lastWeekRevenue)
      .reduce((sum: number, p: any) => sum + p.lastWeekRevenue * 0.5, 0)

    onUpdateStudio({
      projects: updatedProjects,
      money: studioData.money + totalWeeklyEarnings,
    })

    setSimulationWeek((prev) => prev + 1)
  }

  const getTopPerformers = () => {
    return releasedMovies.sort((a: any, b: any) => (b.totalBoxOffice || 0) - (a.totalBoxOffice || 0)).slice(0, 5)
  }

  const getTotalBoxOffice = () => {
    return releasedMovies.reduce((sum: number, movie: any) => sum + (movie.totalBoxOffice || 0), 0)
  }

  const getAverageROI = () => {
    if (releasedMovies.length === 0) return 0
    const totalInvestment = releasedMovies.reduce((sum: number, movie: any) => sum + movie.budget, 0)
    const totalRevenue = getTotalBoxOffice()
    return (totalRevenue / totalInvestment - 1) * 100
  }

  const simulate = () => {
    // quick fake sim: revenue decays each week
    const start = Math.round(Math.random() * 60 + 40) // 40-100M opening
    const weeks: { week: number; revenue: number }[] = []
    for (let w = 1; w <= 12; w++) {
      const rev = Math.round(start * Math.pow(0.6, w - 1))
      weeks.push({ week: w, revenue: rev })
    }
    setData(weeks)
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Box Office Simulation</h2>
        <p className="text-gray-300">Track your movies' theatrical performance</p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="current">Current Releases</TabsTrigger>
          <TabsTrigger value="detailed">Detailed Analysis</TabsTrigger>
          <TabsTrigger value="simulation">Simulation</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-black/20 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-8 h-8 text-green-400" />
                  <div>
                    <p className="text-sm text-gray-400">Total Box Office</p>
                    <p className="text-xl font-bold text-green-400">{formatMoney(getTotalBoxOffice())}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Trophy className="w-8 h-8 text-blue-400" />
                  <div>
                    <p className="text-sm text-gray-400">Movies Released</p>
                    <p className="text-xl font-bold text-blue-400">{releasedMovies.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-purple-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-8 h-8 text-purple-400" />
                  <div>
                    <p className="text-sm text-gray-400">Average ROI</p>
                    <p className={`text-xl font-bold ${getAverageROI() >= 0 ? "text-green-400" : "text-red-400"}`}>
                      {getAverageROI().toFixed(1)}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-yellow-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Calendar className="w-8 h-8 text-yellow-400" />
                  <div>
                    <p className="text-sm text-gray-400">In Theaters</p>
                    <p className="text-xl font-bold text-yellow-400">{inTheatersMovies.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Top Performers</CardTitle>
              <CardDescription>Your highest-grossing movies</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {getTopPerformers().map((movie: any, index: number) => (
                  <div key={movie.id} className="flex items-center gap-4 p-3 bg-white/5 rounded">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-bold">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{movie.title}</h3>
                      <p className="text-sm text-gray-400">{movie.genre}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-400">{formatMoney(movie.totalBoxOffice || 0)}</p>
                      <p className="text-sm text-gray-400">
                        ROI: {(((movie.totalBoxOffice || 0) / movie.budget - 1) * 100).toFixed(1)}%
                      </p>
                    </div>
                  </div>
                ))}
                {getTopPerformers().length === 0 && (
                  <div className="text-center py-8 text-gray-400">
                    <Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No released movies yet.</p>
                    <p className="text-sm">Release some movies to see box office performance!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="current" className="space-y-6">
          <Card className="bg-black/20 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-400">Movies Currently in Theaters</CardTitle>
              <CardDescription>Track weekly performance of your current releases</CardDescription>
            </CardHeader>
            <CardContent>
              {inTheatersMovies.length > 0 ? (
                <div className="space-y-4">
                  {inTheatersMovies.map((movie: any) => (
                    <div key={movie.id} className="p-4 bg-white/5 rounded border border-green-500/30">
                      <div className="flex justify-between items-center mb-3">
                        <div>
                          <h3 className="font-semibold text-white">{movie.title}</h3>
                          <p className="text-sm text-gray-400">Week {(movie.weeksSinceRelease || 0) + 1} in theaters</p>
                        </div>
                        <Badge variant="outline" className="text-green-400">
                          {movie.genre}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="text-center">
                          <p className="text-sm text-gray-400">Total Box Office</p>
                          <p className="font-bold text-green-400">{formatMoney(movie.totalBoxOffice || 0)}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-gray-400">Last Week</p>
                          <p className="font-bold text-blue-400">{formatMoney(movie.lastWeekRevenue || 0)}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-gray-400">Budget</p>
                          <p className="font-bold text-purple-400">{formatMoney(movie.budget)}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-gray-400">ROI</p>
                          <p
                            className={`font-bold ${((movie.totalBoxOffice || 0) / movie.budget) >= 1 ? "text-green-400" : "text-red-400"}`}
                          >
                            {(((movie.totalBoxOffice || 0) / movie.budget - 1) * 100).toFixed(1)}%
                          </p>
                        </div>
                      </div>

                      <div className="mt-3">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-400">Theater Run Progress</span>
                          <span className="text-white">{movie.weeksSinceRelease || 0}/12 weeks</span>
                        </div>
                        <Progress value={((movie.weeksSinceRelease || 0) / 12) * 100} className="h-2" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No movies currently in theaters.</p>
                  <p className="text-sm">Release some movies to track their box office performance!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="detailed" className="space-y-6">
          <Card className="bg-black/20 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400">Select Movie for Analysis</CardTitle>
              <CardDescription>Choose a movie to see detailed box office projections</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {releasedMovies.map((movie: any) => (
                  <Card
                    key={movie.id}
                    className={`cursor-pointer transition-all ${
                      selectedMovie === movie.id
                        ? "border-blue-400 bg-blue-500/10"
                        : "border-white/10 hover:border-blue-500/50"
                    }`}
                    onClick={() => setSelectedMovie(movie.id)}
                  >
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-white mb-2">{movie.title}</h3>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Genre:</span>
                          <span className="text-white">{movie.genre}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Budget:</span>
                          <span className="text-blue-400">{formatMoney(movie.budget)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Box Office:</span>
                          <span className="text-green-400">{formatMoney(movie.totalBoxOffice || 0)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {selectedMovie && (
            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Box Office Performance Chart</CardTitle>
                <CardDescription>Weekly revenue breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={generateBoxOfficeData(releasedMovies.find((m: any) => m.id === selectedMovie))}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="week" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" tickFormatter={formatMoney} />
                      <Tooltip
                        contentStyle={{ backgroundColor: "#1F2937", border: "1px solid #374151" }}
                        labelStyle={{ color: "#F3F4F6" }}
                        formatter={(value: any, name: string) => [
                          name === "weeklyRevenue" ? formatMoney(value) : formatMoney(value),
                          name === "weeklyRevenue" ? "Weekly Revenue" : "Total Revenue",
                        ]}
                      />
                      <Line type="monotone" dataKey="weeklyRevenue" stroke="#10B981" strokeWidth={2} />
                      <Line type="monotone" dataKey="totalRevenue" stroke="#3B82F6" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="simulation" className="space-y-6">
          <Card className="bg-black/20 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-purple-400">Box Office Simulation</CardTitle>
              <CardDescription>Simulate weekly box office performance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <h3 className="text-xl font-bold text-white mb-2">Week {simulationWeek}</h3>
                <p className="text-gray-400 mb-4">Click to advance to the next week and see box office results</p>

                <Button
                  onClick={simulateBoxOfficeWeek}
                  disabled={inTheatersMovies.length === 0}
                  className="bg-purple-500 hover:bg-purple-600"
                >
                  <Target className="w-4 h-4 mr-2" />
                  Advance Week
                </Button>
              </div>

              {inTheatersMovies.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No movies in theaters to simulate.</p>
                  <p className="text-sm">Release some movies first!</p>
                </div>
              )}
            </CardContent>
          </Card>

          {inTheatersMovies.length > 0 && (
            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Weekly Box Office Results</CardTitle>
                <CardDescription>Revenue breakdown by movie</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={inTheatersMovies.map((movie: any) => ({
                        title: movie.title,
                        revenue: movie.lastWeekRevenue || 0,
                        total: movie.totalBoxOffice || 0,
                      }))}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="title" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" tickFormatter={formatMoney} />
                      <Tooltip
                        contentStyle={{ backgroundColor: "#1F2937", border: "1px solid #374151" }}
                        labelStyle={{ color: "#F3F4F6" }}
                        formatter={(value: any) => [formatMoney(value), "Revenue"]}
                      />
                      <Bar dataKey="revenue" fill="#8B5CF6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Run 12-week Simulation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={simulate} className="bg-gradient-to-r from-green-500 to-blue-500">
                Run 12-week simulation
              </Button>

              {data.length > 0 && (
                <ChartContainer
                  config={{ revenue: { label: "Revenue ($M)", color: "hsl(var(--chart-1))" } }}
                  className="h-[300px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={data}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="week" />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line type="monotone" dataKey="revenue" stroke="var(--color-revenue)" name="Revenue" />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
