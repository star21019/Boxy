"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { toast } from "sonner"
import { DollarSign, TrendingUp, TrendingDown, PiggyBank, CreditCard, CheckCircle, BarChart3 } from "lucide-react"

interface FinancesDashboardProps {
  studioData: any
  onUpdateStudio: (data: any) => void
}

export function FinancesDashboard({ studioData, onUpdateStudio }: FinancesDashboardProps) {
  const [loanAmount, setLoanAmount] = useState(1000000)
  const [investmentAmount, setInvestmentAmount] = useState(500000)

  const formatMoney = (amount: number) => {
    if (amount >= 1000000000) return `$${(amount / 1000000000).toFixed(1)}B`
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(1)}K`
    return `$${amount.toLocaleString()}`
  }

  const projects = studioData?.projects || []
  const totalRevenue = projects.reduce((sum: number, project: any) => sum + (project.revenue || 0), 0)
  const totalExpenses = projects.reduce(
    (sum: number, project: any) => sum + (project.budget || 0) + (project.marketingBudget || 0),
    0,
  )
  const monthlyIncome = totalRevenue * 0.1 // Simulate monthly income
  const monthlyExpenses = (studioData?.staff?.length || 0) * 50000 + 100000 // Staff salaries + overhead

  const takeLoan = () => {
    const interest = loanAmount * 0.05 // 5% interest
    const totalDebt = loanAmount + interest

    onUpdateStudio({
      money: studioData.money + loanAmount,
      debt: (studioData.debt || 0) + totalDebt,
    })

    toast.success(`Loan approved! +${formatMoney(loanAmount)} (${formatMoney(interest)} interest)`)
  }

  const makeInvestment = () => {
    if (studioData.money < investmentAmount) {
      toast.error("Insufficient funds!")
      return
    }

    const returns = investmentAmount * (0.8 + Math.random() * 0.4) // 80-120% returns

    onUpdateStudio({
      money: studioData.money - investmentAmount,
      investments: (studioData.investments || 0) + returns,
    })

    toast.success(`Investment made! Expected returns: ${formatMoney(returns)}`)
  }

  const payDebt = () => {
    const debtToPay = Math.min(studioData.money, studioData.debt || 0)

    onUpdateStudio({
      money: studioData.money - debtToPay,
      debt: (studioData.debt || 0) - debtToPay,
    })

    toast.success(`Paid ${formatMoney(debtToPay)} in debt!`)
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-white">Financial Management</h2>
        <p className="text-gray-300">Manage your studio's finances and investments</p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="cash-flow">Cash Flow</TabsTrigger>
          <TabsTrigger value="investments">Investments</TabsTrigger>
          <TabsTrigger value="loans">Loans & Debt</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-black/20 border-green-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-8 h-8 text-green-400" />
                  <div>
                    <p className="text-sm text-gray-400">Available Cash</p>
                    <p className="text-xl font-bold text-green-400">{formatMoney(studioData?.money || 0)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-blue-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-8 h-8 text-blue-400" />
                  <div>
                    <p className="text-sm text-gray-400">Total Revenue</p>
                    <p className="text-xl font-bold text-blue-400">{formatMoney(totalRevenue)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-red-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <TrendingDown className="w-8 h-8 text-red-400" />
                  <div>
                    <p className="text-sm text-gray-400">Total Expenses</p>
                    <p className="text-xl font-bold text-red-400">{formatMoney(totalExpenses)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-purple-500/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <BarChart3 className="w-8 h-8 text-purple-400" />
                  <div>
                    <p className="text-sm text-gray-400">Net Profit</p>
                    <p
                      className={`text-xl font-bold ${totalRevenue - totalExpenses >= 0 ? "text-green-400" : "text-red-400"}`}
                    >
                      {formatMoney(totalRevenue - totalExpenses)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Financial Health</CardTitle>
                <CardDescription>Key financial indicators</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Cash Reserves</span>
                    <span className="text-white">{(((studioData?.money || 0) / 10000000) * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={Math.min(100, ((studioData?.money || 0) / 10000000) * 100)} className="h-2" />
                  <p className="text-xs text-gray-500 mt-1">Target: $10M reserves</p>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Debt-to-Asset Ratio</span>
                    <span className="text-white">
                      {(((studioData?.debt || 0) / Math.max(studioData?.money || 1, 1)) * 100).toFixed(1)}%
                    </span>
                  </div>
                  <Progress
                    value={Math.min(100, ((studioData?.debt || 0) / Math.max(studioData?.money || 1, 1)) * 100)}
                    className="h-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">Lower is better</p>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-400">Profitability</span>
                    <span className="text-white">
                      {totalExpenses > 0 ? ((totalRevenue / totalExpenses) * 100).toFixed(1) : 0}%
                    </span>
                  </div>
                  <Progress
                    value={totalExpenses > 0 ? Math.min(100, (totalRevenue / totalExpenses) * 50) : 0}
                    className="h-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">Revenue vs Expenses</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Quick Actions</CardTitle>
                <CardDescription>Manage your finances</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {(studioData?.debt || 0) > 0 && (
                  <div className="p-3 bg-red-500/10 rounded border border-red-500/30">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-red-400 font-semibold">Outstanding Debt</span>
                      <span className="text-red-400">{formatMoney(studioData.debt)}</span>
                    </div>
                    <Button
                      onClick={payDebt}
                      disabled={studioData.money <= 0}
                      className="w-full bg-red-500 hover:bg-red-600"
                    >
                      Pay Debt
                    </Button>
                  </div>
                )}

                <div className="p-3 bg-green-500/10 rounded border border-green-500/30">
                  <h4 className="text-green-400 font-semibold mb-2">Emergency Fund</h4>
                  <p className="text-sm text-gray-400 mb-2">Recommended: {formatMoney(monthlyExpenses * 6)}</p>
                  <Progress
                    value={Math.min(100, ((studioData?.money || 0) / (monthlyExpenses * 6)) * 100)}
                    className="h-2"
                  />
                </div>

                <div className="p-3 bg-blue-500/10 rounded border border-blue-500/30">
                  <h4 className="text-blue-400 font-semibold mb-2">Monthly Cash Flow</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Income:</span>
                      <span className="text-green-400">+{formatMoney(monthlyIncome)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Expenses:</span>
                      <span className="text-red-400">-{formatMoney(monthlyExpenses)}</span>
                    </div>
                    <div className="flex justify-between border-t border-gray-600 pt-1">
                      <span className="text-white font-semibold">Net:</span>
                      <span
                        className={`font-semibold ${monthlyIncome - monthlyExpenses >= 0 ? "text-green-400" : "text-red-400"}`}
                      >
                        {formatMoney(monthlyIncome - monthlyExpenses)}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cash-flow" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-black/20 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-green-400">Income Sources</CardTitle>
                <CardDescription>Where your money comes from</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-white">Movie Revenue</span>
                    <span className="text-green-400">{formatMoney(totalRevenue * 0.7)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Streaming Rights</span>
                    <span className="text-green-400">{formatMoney(totalRevenue * 0.2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Merchandise</span>
                    <span className="text-green-400">{formatMoney(totalRevenue * 0.1)}</span>
                  </div>
                  <div className="border-t border-gray-600 pt-2">
                    <div className="flex justify-between items-center font-semibold">
                      <span className="text-white">Total Income</span>
                      <span className="text-green-400">{formatMoney(totalRevenue)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-red-500/30">
              <CardHeader>
                <CardTitle className="text-red-400">Expense Breakdown</CardTitle>
                <CardDescription>Where your money goes</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-white">Production Costs</span>
                    <span className="text-red-400">{formatMoney(totalExpenses * 0.6)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Marketing</span>
                    <span className="text-red-400">{formatMoney(totalExpenses * 0.2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Staff Salaries</span>
                    <span className="text-red-400">{formatMoney(totalExpenses * 0.15)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white">Operations</span>
                    <span className="text-red-400">{formatMoney(totalExpenses * 0.05)}</span>
                  </div>
                  <div className="border-t border-gray-600 pt-2">
                    <div className="flex justify-between items-center font-semibold">
                      <span className="text-white">Total Expenses</span>
                      <span className="text-red-400">{formatMoney(totalExpenses)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Cash Flow Forecast</CardTitle>
              <CardDescription>Projected finances for next 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[1, 2, 3, 4, 5, 6].map((month) => {
                  const projectedIncome = monthlyIncome * (0.9 + Math.random() * 0.2)
                  const projectedExpenses = monthlyExpenses * (0.95 + Math.random() * 0.1)
                  const netFlow = projectedIncome - projectedExpenses

                  return (
                    <div key={month} className="p-3 bg-white/5 rounded border border-white/10">
                      <h4 className="font-semibold text-white mb-2">Month {month}</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Income:</span>
                          <span className="text-green-400">+{formatMoney(projectedIncome)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Expenses:</span>
                          <span className="text-red-400">-{formatMoney(projectedExpenses)}</span>
                        </div>
                        <div className="flex justify-between border-t border-gray-600 pt-1">
                          <span className="text-white">Net:</span>
                          <span className={`${netFlow >= 0 ? "text-green-400" : "text-red-400"}`}>
                            {formatMoney(netFlow)}
                          </span>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="investments" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-black/20 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-blue-400">Make Investment</CardTitle>
                <CardDescription>Grow your wealth through smart investments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-white mb-2 block">Investment Amount</label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      value={investmentAmount}
                      onChange={(e) => setInvestmentAmount(Number(e.target.value))}
                      min={100000}
                      max={studioData?.money || 0}
                      step={100000}
                    />
                    <span className="text-gray-400 self-center">{formatMoney(investmentAmount)}</span>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-white mb-2 block">Investment Type</label>
                  <Select defaultValue="stocks">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="stocks">Stock Market (High Risk/Reward)</SelectItem>
                      <SelectItem value="bonds">Government Bonds (Low Risk)</SelectItem>
                      <SelectItem value="real-estate">Real Estate (Medium Risk)</SelectItem>
                      <SelectItem value="crypto">Cryptocurrency (Very High Risk)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="p-3 bg-blue-500/10 rounded border border-blue-500/30">
                  <h4 className="text-blue-400 font-semibold mb-1">Expected Returns</h4>
                  <p className="text-sm text-gray-400">80% - 120% returns over 12 months</p>
                  <p className="text-sm text-gray-400">
                    Potential: {formatMoney(investmentAmount * 0.8)} - {formatMoney(investmentAmount * 1.2)}
                  </p>
                </div>

                <Button
                  onClick={makeInvestment}
                  disabled={studioData?.money < investmentAmount}
                  className="w-full bg-blue-500 hover:bg-blue-600"
                >
                  <PiggyBank className="w-4 h-4 mr-2" />
                  Invest {formatMoney(investmentAmount)}
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Investment Portfolio</CardTitle>
                <CardDescription>Your current investments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {(studioData?.investments || 0) > 0 ? (
                  <div className="space-y-3">
                    <div className="p-3 bg-green-500/10 rounded border border-green-500/30">
                      <div className="flex justify-between items-center">
                        <span className="text-white">Total Portfolio Value</span>
                        <span className="text-green-400 font-bold">{formatMoney(studioData.investments)}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between items-center p-2 bg-white/5 rounded">
                        <span className="text-gray-400">Stock Market</span>
                        <span className="text-green-400">+12.5%</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-white/5 rounded">
                        <span className="text-gray-400">Real Estate</span>
                        <span className="text-green-400">+8.2%</span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-white/5 rounded">
                        <span className="text-gray-400">Government Bonds</span>
                        <span className="text-green-400">+3.1%</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <PiggyBank className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No investments yet. Start building your portfolio!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="loans" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="bg-black/20 border-yellow-500/30">
              <CardHeader>
                <CardTitle className="text-yellow-400">Take Loan</CardTitle>
                <CardDescription>Get immediate funding for your projects</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-white mb-2 block">Loan Amount</label>
                  <div className="space-y-2">
                    <Slider
                      value={[loanAmount]}
                      onValueChange={([value]) => setLoanAmount(value)}
                      min={500000}
                      max={10000000}
                      step={100000}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-gray-400">
                      <span>$500K</span>
                      <span className="text-white font-bold">{formatMoney(loanAmount)}</span>
                      <span>$10M</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Interest Rate:</span>
                    <span className="text-white">5.0% APR</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total Interest:</span>
                    <span className="text-yellow-400">{formatMoney(loanAmount * 0.05)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total Repayment:</span>
                    <span className="text-red-400">{formatMoney(loanAmount * 1.05)}</span>
                  </div>
                </div>

                <div className="p-3 bg-yellow-500/10 rounded border border-yellow-500/30">
                  <h4 className="text-yellow-400 font-semibold mb-1">Loan Terms</h4>
                  <ul className="text-sm text-gray-400 space-y-1">
                    <li>• 12 month repayment period</li>
                    <li>• 5% annual interest rate</li>
                    <li>• No early repayment penalties</li>
                    <li>• Instant approval for qualified studios</li>
                  </ul>
                </div>

                <Button onClick={takeLoan} className="w-full bg-yellow-500 hover:bg-yellow-600 text-black">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Apply for Loan
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Debt Management</CardTitle>
                <CardDescription>Track and manage your debts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {(studioData?.debt || 0) > 0 ? (
                  <div className="space-y-4">
                    <div className="p-3 bg-red-500/10 rounded border border-red-500/30">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-red-400 font-semibold">Total Debt</span>
                        <span className="text-red-400 text-xl font-bold">{formatMoney(studioData.debt)}</span>
                      </div>
                      <Progress
                        value={Math.min(100, (studioData.debt / (studioData.money + studioData.debt)) * 100)}
                        className="h-2"
                      />
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-white font-semibold">Repayment Options</h4>
                      <div className="space-y-2">
                        <Button
                          onClick={payDebt}
                          disabled={studioData.money <= 0}
                          className="w-full bg-red-500 hover:bg-red-600"
                        >
                          Pay Full Amount ({formatMoney(Math.min(studioData.money, studioData.debt))})
                        </Button>
                        <Button
                          onClick={() => {
                            const partialPayment = Math.min(studioData.money * 0.5, studioData.debt)
                            onUpdateStudio({
                              money: studioData.money - partialPayment,
                              debt: studioData.debt - partialPayment,
                            })
                            toast.success(`Paid ${formatMoney(partialPayment)} towards debt`)
                          }}
                          disabled={studioData.money <= 0}
                          variant="outline"
                          className="w-full"
                        >
                          Pay 50% of Available Cash
                        </Button>
                      </div>
                    </div>

                    <div className="p-3 bg-white/5 rounded">
                      <h4 className="text-white font-semibold mb-2">Debt Impact</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Credit Rating:</span>
                          <span className={`${studioData.debt > studioData.money ? "text-red-400" : "text-green-400"}`}>
                            {studioData.debt > studioData.money ? "Poor" : "Good"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Interest Burden:</span>
                          <span className="text-yellow-400">{formatMoney(studioData.debt * 0.05)}/year</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-400" />
                    <p className="text-green-400 font-semibold">Debt Free!</p>
                    <p>Your studio has no outstanding debts.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
