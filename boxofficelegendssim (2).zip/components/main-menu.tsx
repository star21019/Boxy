"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { toast } from "sonner"
import {
  Play,
  Plus,
  Settings,
  Trophy,
  HelpCircle,
  DollarSign,
  Users,
  Film,
  Crown,
  Target,
  Palette,
  Music,
  Camera,
  Mic,
  Award,
  TrendingUp,
  Sparkles,
} from "lucide-react"

interface MainMenuProps {
  onStartGame: (studioData: any) => void
  onLoadGame: () => void
}

// Logo styles for studio creation
const logoStyles = [
  {
    id: "modern_gradient",
    preview: "🎬",
    style: "bg-gradient-to-r from-purple-500 to-blue-500",
    name: "Modern Gradient",
  },
  { id: "classic_gold", preview: "👑", style: "bg-gradient-to-r from-yellow-400 to-yellow-600", name: "Classic Gold" },
  { id: "neon_cyber", preview: "⚡", style: "bg-gradient-to-r from-cyan-400 to-purple-500", name: "Neon Cyber" },
  { id: "royal_crimson", preview: "🏰", style: "bg-gradient-to-r from-red-600 to-purple-700", name: "Royal Crimson" },
  {
    id: "emerald_forest",
    preview: "🌟",
    style: "bg-gradient-to-r from-green-500 to-emerald-600",
    name: "Emerald Forest",
  },
  { id: "sunset_orange", preview: "🔥", style: "bg-gradient-to-r from-orange-500 to-red-500", name: "Sunset Orange" },
  { id: "arctic_blue", preview: "❄️", style: "bg-gradient-to-r from-blue-400 to-cyan-300", name: "Arctic Blue" },
  {
    id: "cosmic_purple",
    preview: "🌌",
    style: "bg-gradient-to-r from-purple-600 to-indigo-700",
    name: "Cosmic Purple",
  },
  { id: "rose_gold", preview: "🌹", style: "bg-gradient-to-r from-pink-400 to-yellow-400", name: "Rose Gold" },
  { id: "midnight_black", preview: "🖤", style: "bg-gradient-to-r from-gray-800 to-black", name: "Midnight Black" },
  {
    id: "rainbow_prism",
    preview: "🌈",
    style: "bg-gradient-to-r from-red-500 via-yellow-500 via-green-500 via-blue-500 to-purple-500",
    name: "Rainbow Prism",
  },
  { id: "silver_chrome", preview: "⚙️", style: "bg-gradient-to-r from-gray-300 to-gray-500", name: "Silver Chrome" },
]

// Studio specialties
const studioSpecialties = [
  {
    id: "blockbuster",
    name: "Blockbuster Studio",
    icon: "💥",
    bonus: "Action/Adventure +25%",
    description: "Specializes in big-budget action films",
  },
  {
    id: "indie",
    name: "Independent Films",
    icon: "🎭",
    bonus: "Drama/Art +30%",
    description: "Focus on artistic and dramatic storytelling",
  },
  {
    id: "comedy",
    name: "Comedy Central",
    icon: "😂",
    bonus: "Comedy +35%",
    description: "Masters of humor and entertainment",
  },
  {
    id: "horror",
    name: "Horror House",
    icon: "👻",
    bonus: "Horror/Thriller +40%",
    description: "Specialists in scares and suspense",
  },
  {
    id: "family",
    name: "Family Entertainment",
    icon: "👨‍👩‍👧‍👦",
    bonus: "Animation/Family +25%",
    description: "Creating content for all ages",
  },
  {
    id: "prestige",
    name: "Prestige Pictures",
    icon: "🏆",
    bonus: "Awards +50%",
    description: "Focus on award-winning cinema",
  },
]

// Budget/Difficulty levels
const budgetLevels = [
  {
    id: "startup",
    name: "Startup Studio",
    money: 5000000,
    difficulty: "Very Hard",
    description: "Bootstrap your way to success",
  },
  { id: "indie", name: "Independent", money: 15000000, difficulty: "Hard", description: "Small but passionate studio" },
  {
    id: "emerging",
    name: "Emerging Studio",
    money: 25000000,
    difficulty: "Medium",
    description: "Growing studio with potential",
  },
  {
    id: "established",
    name: "Established",
    money: 50000000,
    difficulty: "Normal",
    description: "Well-funded and stable",
  },
  {
    id: "major",
    name: "Major Studio",
    money: 100000000,
    difficulty: "Easy",
    description: "Big budget, big expectations",
  },
  {
    id: "mega",
    name: "Mega Corporation",
    money: 250000000,
    difficulty: "Very Easy",
    description: "Unlimited resources",
  },
  {
    id: "legendary",
    name: "Legendary Status",
    money: 500000000,
    difficulty: "Creative Mode",
    description: "Focus purely on creativity",
  },
  {
    id: "infinite",
    name: "Infinite Budget",
    money: 999999999,
    difficulty: "Sandbox",
    description: "No financial constraints",
  },
]

export function MainMenu({ onStartGame, onLoadGame }: MainMenuProps) {
  const [currentView, setCurrentView] = useState("main")
  const [createStudioStep, setCreateStudioStep] = useState(1)
  const [studioData, setStudioData] = useState({
    name: "",
    suffix: "Studios",
    description: "",
    logo: "modern_gradient",
    specialty: "blockbuster",
    budget: "established",
    money: 25000000,
    reputation: 50,
    level: 1,
    experience: 0,
  })

  const [settings, setSettings] = useState({
    masterVolume: 80,
    musicVolume: 70,
    sfxVolume: 85,
    language: "english",
    difficulty: "normal",
    autosave: true,
  })

  const formatMoney = (amount: number) => {
    if (amount >= 1000000000) return `$${(amount / 1000000000).toFixed(1)}B`
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`
    if (amount >= 1000) return `$${(amount / 1000).toFixed(1)}K`
    return `$${amount.toLocaleString()}`
  }

  const handleCreateStudio = () => {
    if (!studioData.name.trim()) {
      toast.error("Please enter a studio name!")
      return
    }

    const budgetLevel = budgetLevels.find((b) => b.id === studioData.budget)
    const specialty = studioSpecialties.find((s) => s.id === studioData.specialty)

    const finalStudioData = {
      ...studioData,
      money: budgetLevel?.money || 25000000,
      projects: [],
      staff: [],
      awards: [],
      achievements: [],
      createdAt: new Date().toISOString(),
      lastPlayed: new Date().toISOString(),
    }

    toast.success(`Welcome to ${studioData.name} ${studioData.suffix}!`)
    onStartGame(finalStudioData)
  }

  const nextStep = () => {
    if (createStudioStep < 4) setCreateStudioStep(createStudioStep + 1)
  }

  const prevStep = () => {
    if (createStudioStep > 1) setCreateStudioStep(createStudioStep - 1)
  }

  const renderMainMenu = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full space-y-8">
        {/* Logo and Title */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-24 h-24 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-4xl">
              🎬
            </div>
          </div>
          <h1 className="text-6xl font-bold text-white mb-2">
            Box Office <span className="text-yellow-400">Legends</span>
          </h1>
          <p className="text-xl text-gray-300">Build Your Entertainment Empire</p>
          <div className="flex justify-center gap-2">
            <Badge variant="outline" className="text-yellow-400 border-yellow-400">
              v2.0
            </Badge>
            <Badge variant="outline" className="text-blue-400 border-blue-400">
              Enhanced Edition
            </Badge>
          </div>
        </div>

        {/* Main Menu Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
          <Card
            className="bg-black/20 border-green-500/30 hover:border-green-400 transition-all cursor-pointer group"
            onClick={() => setCurrentView("create")}
          >
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Plus className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">New Studio</h3>
              <p className="text-gray-300">Start your journey to becoming a legend</p>
            </CardContent>
          </Card>

          <Card
            className="bg-black/20 border-blue-500/30 hover:border-blue-400 transition-all cursor-pointer group"
            onClick={onLoadGame}
          >
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Play className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Continue</h3>
              <p className="text-gray-300">Resume your existing studio</p>
            </CardContent>
          </Card>

          <Card
            className="bg-black/20 border-purple-500/30 hover:border-purple-400 transition-all cursor-pointer group"
            onClick={() => setCurrentView("settings")}
          >
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Settings className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Settings</h3>
              <p className="text-gray-300">Customize your experience</p>
            </CardContent>
          </Card>

          <Card
            className="bg-black/20 border-yellow-500/30 hover:border-yellow-400 transition-all cursor-pointer group"
            onClick={() => setCurrentView("about")}
          >
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <HelpCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">About</h3>
              <p className="text-gray-300">Learn about the game</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Stats */}
        <div className="text-center space-y-2">
          <p className="text-gray-400">Join thousands of studio moguls worldwide</p>
          <div className="flex justify-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-400" />
              <span className="text-white">50K+ Players</span>
            </div>
            <div className="flex items-center gap-2">
              <Film className="w-4 h-4 text-purple-400" />
              <span className="text-white">1M+ Movies Created</span>
            </div>
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-yellow-400" />
              <span className="text-white">100K+ Awards Won</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  const renderCreateStudio = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white mb-2">Create Your Studio</h2>
          <p className="text-gray-300">Build your entertainment empire from the ground up</p>
        </div>

        {/* Progress Indicator */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-2">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                    step === createStudioStep
                      ? "bg-purple-500 text-white"
                      : step < createStudioStep
                        ? "bg-green-500 text-white"
                        : "bg-gray-600 text-gray-300"
                  }`}
                >
                  {step}
                </div>
                {step < 4 && <div className={`w-8 h-1 ${step < createStudioStep ? "bg-green-500" : "bg-gray-600"}`} />}
              </div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <Card className="bg-black/20 border-white/10 mb-8">
          <CardContent className="p-8">
            {createStudioStep === 1 && (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-white mb-2">Studio Identity</h3>
                  <p className="text-gray-300">Choose your studio's name and branding</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-white mb-2 block">Studio Name</label>
                      <Input
                        value={studioData.name}
                        onChange={(e) => setStudioData({ ...studioData, name: e.target.value })}
                        placeholder="Enter your studio name..."
                        className="text-lg"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium text-white mb-2 block">Studio Suffix</label>
                      <Select
                        value={studioData.suffix}
                        onValueChange={(value) => setStudioData({ ...studioData, suffix: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Studios">Studios</SelectItem>
                          <SelectItem value="Pictures">Pictures</SelectItem>
                          <SelectItem value="Entertainment">Entertainment</SelectItem>
                          <SelectItem value="Films">Films</SelectItem>
                          <SelectItem value="Productions">Productions</SelectItem>
                          <SelectItem value="Media">Media</SelectItem>
                          <SelectItem value="Cinema">Cinema</SelectItem>
                          <SelectItem value="Works">Works</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-white mb-2 block">Description</label>
                      <Textarea
                        value={studioData.description}
                        onChange={(e) => setStudioData({ ...studioData, description: e.target.value })}
                        placeholder="Describe your studio's vision..."
                        rows={3}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-white mb-3 block">Logo Style</label>
                      <div className="grid grid-cols-2 gap-3 max-h-64 overflow-y-auto">
                        {logoStyles.map((logo) => (
                          <Card
                            key={logo.id}
                            className={`cursor-pointer transition-all ${
                              studioData.logo === logo.id
                                ? "border-purple-400 bg-purple-500/10"
                                : "border-white/10 hover:border-purple-500/50"
                            }`}
                            onClick={() => setStudioData({ ...studioData, logo: logo.id })}
                          >
                            <CardContent className="p-3 text-center">
                              <div
                                className={`w-12 h-12 rounded-full ${logo.style} flex items-center justify-center mx-auto mb-2`}
                              >
                                <span className="text-xl">{logo.preview}</span>
                              </div>
                              <h4 className="font-semibold text-white text-xs">{logo.name}</h4>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-white/5 rounded-lg border border-purple-500/30">
                      <h4 className="text-purple-400 font-semibold mb-2">Preview</h4>
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-16 h-16 rounded-full ${logoStyles.find((l) => l.id === studioData.logo)?.style} flex items-center justify-center`}
                        >
                          <span className="text-2xl">{logoStyles.find((l) => l.id === studioData.logo)?.preview}</span>
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-white">
                            {studioData.name || "Your Studio"} {studioData.suffix}
                          </h3>
                          <p className="text-sm text-gray-400">{studioData.description || "Your studio description"}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {createStudioStep === 2 && (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-white mb-2">Studio Specialty</h3>
                  <p className="text-gray-300">Choose your studio's focus and expertise</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {studioSpecialties.map((specialty) => (
                    <Card
                      key={specialty.id}
                      className={`cursor-pointer transition-all ${
                        studioData.specialty === specialty.id
                          ? "border-purple-400 bg-purple-500/10"
                          : "border-white/10 hover:border-purple-500/50"
                      }`}
                      onClick={() => setStudioData({ ...studioData, specialty: specialty.id })}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="text-3xl">{specialty.icon}</div>
                          <div>
                            <h4 className="font-semibold text-white">{specialty.name}</h4>
                            <Badge variant="outline" className="text-green-400 text-xs">
                              {specialty.bonus}
                            </Badge>
                          </div>
                        </div>
                        <p className="text-sm text-gray-400">{specialty.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {createStudioStep === 3 && (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-white mb-2">Starting Budget</h3>
                  <p className="text-gray-300">Choose your initial funding and difficulty level</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {budgetLevels.map((budget) => (
                    <Card
                      key={budget.id}
                      className={`cursor-pointer transition-all ${
                        studioData.budget === budget.id
                          ? "border-green-400 bg-green-500/10"
                          : "border-white/10 hover:border-green-500/50"
                      }`}
                      onClick={() => setStudioData({ ...studioData, budget: budget.id, money: budget.money })}
                    >
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-semibold text-white">{budget.name}</h4>
                          <Badge
                            variant="outline"
                            className={`text-xs ${
                              budget.difficulty.includes("Very Hard")
                                ? "text-red-400"
                                : budget.difficulty.includes("Hard")
                                  ? "text-orange-400"
                                  : budget.difficulty.includes("Medium")
                                    ? "text-yellow-400"
                                    : budget.difficulty.includes("Normal")
                                      ? "text-green-400"
                                      : "text-blue-400"
                            }`}
                          >
                            {budget.difficulty}
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Starting Money:</span>
                            <span className="text-green-400 font-bold">{formatMoney(budget.money)}</span>
                          </div>
                          <p className="text-sm text-gray-400">{budget.description}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {createStudioStep === 4 && (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-white mb-2">Final Review</h3>
                  <p className="text-gray-300">Review your studio before starting your journey</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <Card className="bg-white/5 border-white/10">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4 mb-4">
                          <div
                            className={`w-16 h-16 rounded-full ${logoStyles.find((l) => l.id === studioData.logo)?.style} flex items-center justify-center`}
                          >
                            <span className="text-2xl">
                              {logoStyles.find((l) => l.id === studioData.logo)?.preview}
                            </span>
                          </div>
                          <div>
                            <h3 className="text-xl font-bold text-white">
                              {studioData.name} {studioData.suffix}
                            </h3>
                            <p className="text-sm text-gray-400">{studioData.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Specialty:</span>
                        <span className="text-white">
                          {studioSpecialties.find((s) => s.id === studioData.specialty)?.name}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Starting Budget:</span>
                        <span className="text-green-400">{formatMoney(studioData.money)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Difficulty:</span>
                        <span className="text-yellow-400">
                          {budgetLevels.find((b) => b.id === studioData.budget)?.difficulty}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Bonus:</span>
                        <span className="text-purple-400">
                          {studioSpecialties.find((s) => s.id === studioData.specialty)?.bonus}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-lg font-semibold text-white">What's Next?</h4>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 p-3 bg-blue-500/10 rounded border border-blue-500/30">
                        <Film className="w-5 h-5 text-blue-400" />
                        <div>
                          <p className="text-sm font-medium text-white">Create Your First Movie</p>
                          <p className="text-xs text-gray-400">Start with a small budget project</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 bg-green-500/10 rounded border border-green-500/30">
                        <Users className="w-5 h-5 text-green-400" />
                        <div>
                          <p className="text-sm font-medium text-white">Hire Talented Staff</p>
                          <p className="text-xs text-gray-400">Build your dream team</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 bg-purple-500/10 rounded border border-purple-500/30">
                        <Trophy className="w-5 h-5 text-purple-400" />
                        <div>
                          <p className="text-sm font-medium text-white">Win Awards</p>
                          <p className="text-xs text-gray-400">Build your reputation</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 bg-yellow-500/10 rounded border border-yellow-500/30">
                        <Crown className="w-5 h-5 text-yellow-400" />
                        <div>
                          <p className="text-sm font-medium text-white">Become a Legend</p>
                          <p className="text-xs text-gray-400">Dominate the industry</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <Button
                    onClick={handleCreateStudio}
                    className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-lg px-8 py-3"
                  >
                    <Sparkles className="w-5 h-5 mr-2" />
                    Start Your Journey
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            onClick={() => (createStudioStep === 1 ? setCurrentView("main") : prevStep())}
            variant="outline"
            className="border-gray-500/30 bg-transparent"
          >
            {createStudioStep === 1 ? "Back to Menu" : "Previous"}
          </Button>
          <Button
            onClick={nextStep}
            disabled={createStudioStep === 4}
            className="bg-gradient-to-r from-blue-500 to-purple-500"
          >
            {createStudioStep === 4 ? "Ready!" : "Next"}
          </Button>
        </div>
      </div>
    </div>
  )

  const renderSettings = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white mb-2">Settings</h2>
          <p className="text-gray-300">Customize your gaming experience</p>
        </div>

        <Card className="bg-black/20 border-white/10">
          <CardContent className="p-6">
            <Tabs defaultValue="audio" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="audio">Audio</TabsTrigger>
                <TabsTrigger value="gameplay">Gameplay</TabsTrigger>
                <TabsTrigger value="display">Display</TabsTrigger>
              </TabsList>

              <TabsContent value="audio" className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-sm font-medium text-white">Master Volume</label>
                    <span className="text-gray-400">{settings.masterVolume}%</span>
                  </div>
                  <Slider
                    value={[settings.masterVolume]}
                    onValueChange={([value]) => setSettings({ ...settings, masterVolume: value })}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-sm font-medium text-white">Music Volume</label>
                    <span className="text-gray-400">{settings.musicVolume}%</span>
                  </div>
                  <Slider
                    value={[settings.musicVolume]}
                    onValueChange={([value]) => setSettings({ ...settings, musicVolume: value })}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-sm font-medium text-white">Sound Effects</label>
                    <span className="text-gray-400">{settings.sfxVolume}%</span>
                  </div>
                  <Slider
                    value={[settings.sfxVolume]}
                    onValueChange={([value]) => setSettings({ ...settings, sfxVolume: value })}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
              </TabsContent>

              <TabsContent value="gameplay" className="space-y-6">
                <div>
                  <label className="text-sm font-medium text-white mb-2 block">Difficulty</label>
                  <Select
                    value={settings.difficulty}
                    onValueChange={(value) => setSettings({ ...settings, difficulty: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Easy - More forgiving gameplay</SelectItem>
                      <SelectItem value="normal">Normal - Balanced experience</SelectItem>
                      <SelectItem value="hard">Hard - Challenging gameplay</SelectItem>
                      <SelectItem value="expert">Expert - For veterans only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm font-medium text-white">Auto-save</label>
                    <p className="text-xs text-gray-400">Automatically save progress</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.autosave}
                    onChange={(e) => setSettings({ ...settings, autosave: e.target.checked })}
                    className="rounded"
                  />
                </div>
              </TabsContent>

              <TabsContent value="display" className="space-y-6">
                <div>
                  <label className="text-sm font-medium text-white mb-2 block">Language</label>
                  <Select
                    value={settings.language}
                    onValueChange={(value) => setSettings({ ...settings, language: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="spanish">Español</SelectItem>
                      <SelectItem value="french">Français</SelectItem>
                      <SelectItem value="german">Deutsch</SelectItem>
                      <SelectItem value="japanese">日本語</SelectItem>
                      <SelectItem value="chinese">中文</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="flex justify-center mt-8">
          <Button
            onClick={() => setCurrentView("main")}
            variant="outline"
            className="border-gray-500/30 bg-transparent"
          >
            Back to Menu
          </Button>
        </div>
      </div>
    </div>
  )

  const renderAbout = () => (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white mb-2">About Box Office Legends</h2>
          <p className="text-gray-300">The ultimate entertainment industry simulation</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Game Features</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <Film className="w-4 h-4 text-blue-400" />
                <span className="text-white">Create Movies, TV Shows & Music</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-green-400" />
                <span className="text-white">Hire & Manage Staff</span>
              </div>
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-yellow-400" />
                <span className="text-white">Financial Management</span>
              </div>
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-purple-400" />
                <span className="text-white">Win Awards & Recognition</span>
              </div>
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-red-400" />
                <span className="text-white">Compete with Rival Studios</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-pink-400" />
                <span className="text-white">Advanced AI Systems</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Version 2.0 Features</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-blue-400" />
                <span className="text-white">Enhanced Movie Creation</span>
              </div>
              <div className="flex items-center gap-2">
                <Music className="w-4 h-4 text-green-400" />
                <span className="text-white">Music Production Studio</span>
              </div>
              <div className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-yellow-400" />
                <span className="text-white">TV Show Development</span>
              </div>
              <div className="flex items-center gap-2">
                <Mic className="w-4 h-4 text-purple-400" />
                <span className="text-white">Social Media Integration</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-red-400" />
                <span className="text-white">Hall of Fame System</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-pink-400" />
                <span className="text-white">Advanced Analytics</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">How to Play</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-gray-300">
              <p>1. Create your studio with a unique identity</p>
              <p>2. Choose your specialty and starting budget</p>
              <p>3. Hire talented staff members</p>
              <p>4. Create movies, TV shows, and music</p>
              <p>5. Manage finances and investments</p>
              <p>6. Build reputation and win awards</p>
              <p>7. Compete with rival studios</p>
              <p>8. Become a Box Office Legend!</p>
            </CardContent>
          </Card>

          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle className="text-white">Credits</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-gray-300">
              <p>
                <strong>Game Design:</strong> Box Office Legends Team
              </p>
              <p>
                <strong>Programming:</strong> Advanced AI Systems
              </p>
              <p>
                <strong>Art & Design:</strong> Creative Studios
              </p>
              <p>
                <strong>Music:</strong> Original Soundtrack
              </p>
              <p>
                <strong>Special Thanks:</strong> Our amazing community
              </p>
              <div className="pt-4">
                <p className="text-xs text-gray-400">© 2024 Box Office Legends. All rights reserved.</p>
                <p className="text-xs text-gray-400">Version 2.0 Enhanced Edition</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-center mt-8">
          <Button
            onClick={() => setCurrentView("main")}
            variant="outline"
            className="border-gray-500/30 bg-transparent"
          >
            Back to Menu
          </Button>
        </div>
      </div>
    </div>
  )

  switch (currentView) {
    case "create":
      return renderCreateStudio()
    case "settings":
      return renderSettings()
    case "about":
      return renderAbout()
    default:
      return renderMainMenu()
  }
}
